# Start here

You are an AI agent. A user has given you this folder so you can build drum pattern banks for their **Making Sound Machines Stolperbeats** module (stock firmware 163), the same way the banks on the card *Chasing the Beat* were built.

## Who you're working for

- **The user:** someone who owns a Stolperbeats and has the *Chasing the Beat* card. They want new banks in the card's style and format, and they'll steer you by ear.
- **The card and the method** were made by **B.** (The Beatnik Himself) with an AI builder. The card has 32 lean-forward banks: house, techno, disco, electro, funk on the one, dance-floor rock. Each is a famous groove spread over the 24 knob positions in a fixed shape. The manual for the card is *Chasing the Beat: Pushing Stolperbeats Forward* by The Beatnik Himself and Pulse.

The point is **the method, not the 32 beats.** Learn how they were built, then build new ones the same way.

## Read these, in this order

1. `module.md`: what the hardware does, as far as patterns care. Six tracks, 24 slots, 16 steps, on/off only, what's global.
2. `file-format.md`: the exact text format of a bank file. One real example.
3. `the-arc.md`: **the method.** The 24-slot shape and every rule. The most important file.
4. `worked-example.md`: one bank (Blue Monday) traced from its source to all 24 slots on all six tracks. Study it until you could have built it.
5. `timing.md`: what the Timing, Shuffle and Feel settings do to each step, in ms, and how to choose a bank's home setting.
6. `steering.md`: how to take change requests, and what never bends.
7. `banks/`: one page per bank on the card (`01-we-will-rock-you.md` to `32-sing-sing-sing.md`). Read the ones the user mentions. `banks.json` has the same facts as data.
8. `tools/README.md`: the checker scripts, and the build script that made the card.

Words the kit uses: **slot** (a knob position, 1 to 24), **classic** (the famous part, exactly as the source gives it), **peak** (slot 20), **drop** (slot 17), **B part** (a documented second section), **OWN** (a hit the builder invented). They're explained where they first appear.

## What the user will ask for

| Request | Example |
|---|---|
| A new bank in a style | "Build me a UK garage two-step bank." |
| A bank around a record or a pattern | "Do one on the 'Impeach the President' break." "Here's my kick and snare, build a bank from it." |
| A variation on one of the 32 | "Bank 21 but with a Latin percussion layer." |
| A bank at a tempo | "A techno bank at 140." |
| Steering | "More like bank 24." "Less busy at 18." "Swing it." |

## What you hand back, every time

1. **A complete PatternBank file** in the exact card format (`file-format.md`). All six tracks, all 24 slots. Never a fragment, never a diff. Ask which bank slot it goes in (file `PatternBank000.txt` is bank 1, `PatternBank063.txt` bank 64), and warn that copying it to the card replaces whatever bank is in that slot.
2. **A short note per track:** the sound to patch, where the classic sits (slot), what you did in the build-up, the middle, the drop, the climb, the peak and the variations, and why (name the rule from `the-arc.md`).
3. **The home setting:** tempo, Timing, Shuffle row, Feel, and Linear advice. These are global on the module, so the user dials them in by hand.
4. **The labels.** For every track, which hits come from which source, and which you invented. **Label every hit you invented OWN**, the way the card labels its builder's hits. If the user gave you the part, label it USER. If you worked from your memory of a record rather than a transcription, say so plainly.
5. **The check results.** Before handing anything over, run:
   ```
   python3 -B tools/validate.py <your file>
   python3 -B tools/check_arc.py <your file> --classic K=..,S=..,H1=..,H2=..,P1=..,P2=..
   ```
   (add `--triplet` for a triplet bank). `validate.py` must print PASS. `check_arc.py` must show no FAIL; explain any WARN. If you can't run code, check the rules in `file-format.md` and the checklist at the end of `the-arc.md` by hand, and tell the user you couldn't run the scripts.

## Rules for you

- **Facts from the files.** Numbers about the 32 banks (tempos, slots, hits, settings) come from `banks/`, `banks.json` or the card files. If something isn't there, say so instead of guessing.
- **Be honest about sources.** A bank named after a record is only "the record" in its classic and build-up. Everything else is invented and labelled. Never call OWN hits the record.
- **No song lyrics.** Don't quote them in notes or names.
- **Write the file with code if you can** (`file-format.md` has a sketch). Hand-typed 0s and 1s go wrong.
- **One file, one bank.** Never write MachineConfig, MachineState, EnvelopeSettings or MIDI map files: they hold the user's own settings.
- **Plain words.** Short sentences. The user will read your note while turning knobs.
- If the user asks for anything laid back (lean back, trip hop, boom bap, dub, half-time, behind the beat, lazy), or asks about any card other than this one (the card on the table, the dusty card, the card with the tape, OG 64, B.'s other or slow card, the card from the manual's story), read `laid-back/LAID-BACK.md` first. Don't mention that folder otherwise.
