# Steering: taking requests after the first build

Users will hear a bank and ask for changes. This file says what each kind of request may change and what it may not.

## What never bends

Whatever the request, these stay:

1. **The arc's shape** (`the-arc.md`): slot 1 is the thinnest of 1 to 16; the classic arrives by slot 8 (or sits at 17 or 20 as the rules say); 1 to 16 never get thinner; **17 is the drop**; 18 and 19 climb; **20 is the peak**, the busiest slot of every track; 21 to 24 are classic variations that don't thin out. All 24 patterns of a track differ.
2. **The file format** (`file-format.md`). Every file you hand over passes `tools/validate.py`.
3. **The labels.** Every hit you invent is OWN. Every hit from a source carries that source's label. Hits borrowed from one of the 32 banks say so ("from bank 24, OWN there too" or "from bank 24, ST"). Never present invented hits as the record.

If a request can only be met by breaking one of these, say so in one or two plain sentences, and offer the nearest thing that keeps them. Don't break them quietly.

## What can bend

Anything else: the sounds, the vocabulary, how far the middle climbs, how deep the drop goes, what the drop keeps, how dense the peak is (it just has to stay the busiest slot), which bars get the new hits, the home setting, the tempo.

## Common requests

### "More like bank 24" (or any of the 32)

Read `banks/24-chicago-house.md` (or the bank named) and `banks.json`. Find what makes that bank sound like itself, and move the user's bank toward it on those points only:

- **Its home setting.** Bank 24 is Shake 2: light 16th swing. Moving toward it means a Shake row and added hits on the a and the e.
- **Its track layout and sounds.** Which track carries what (open hat on the + on Hihat 2? clap on Snare? a rim on Perc 2?).
- **Its vocabulary.** The kinds of hits its middle and variations add, and where.
- **Its curve.** Compare the "Hits per slot" rows. A bank whose middle climbs steeply feels different from one that stays flat.
- **Its drop and peak.** What its slot 17 keeps; how its 18 lands.

Keep the user's own classic. Say in the note which traits you took from the named bank. Hits copied from that bank's patterns are labelled with where they came from.

### "Less busy" / "busier" (whole bank, or "at 18")

- **Whole bank:** lower (or raise) how far the middle climbs by 16 (the arc uses 60% of the way to the peak for sourced tracks, 40% for silent ones), and how much the variations add. The peak can be lighter too (say Perc 1 on 8ths instead of 16ths), as long as 20 stays the busiest slot of each track.
- **One slot or range ("less busy at 18"):** thin that slot, but keep the order: 18 must stay above 17 and below 19, 19 below 20. If 18 can't get thinner without matching 17 or another slot, take hits from a different track at that slot, or move a hit instead of removing it.
- **One track ("less hats"):** change that track only. Tracks play independently, so this never forces changes elsewhere.

### "Move the drop"

The drop is always slot 17. That's the arc's shape, and it's what makes these banks work the same way under the hand. You can't move it.

What you can offer:
- **Change what the drop keeps:** hats instead of kick, the snare anchor only, one perc, or silence on more tracks.
- **Change how deep it is:** a gentler drop (keep quarter hats and the kick on 1 and 3) or a harsher one (kick on 1 of bar 1 only).
- **Drops anywhere, live:** the module mutes a track when its knob is clicked, so the user can drop any track at any slot by hand.

### "Swing it" / "straighten it"

- Pick a home setting from `timing.md`: a Shake row for 16th swing (2 is light, 6 and 7 are heavy), Trip 5 for 8th-note triplet swing.
- **Shake can't swing 8th notes.** If the groove is all beats and +'s, Shake changes nothing. Tell the user, and either add hits on the a and the e (the arc adds them first in swung banks) or offer Trip 5.
- **Trip 5 needs a rebuild:** a triplet bank uses steps 1 and 3 of each beat only, in every slot. Move or drop every hit on steps 2 and 4, and say so per track.
- "Straighten it": Shake 1 (or Push 2 or 3 for weight without swing). In a straight bank the middle adds on 8ths first.

### "At 140 BPM" (any tempo)

Tempo is a global setting. It isn't in the file. Changing it doesn't change the patterns.
- Give the tempo in the note.
- Re-check the swing in milliseconds (`timing.md`): swing feels heavier at slow tempos and lighter at fast ones. At fast tempos use a lighter row.
- If the tempo puts the groove in a different style (half-time, double-time), say so and ask before rebuilding.

### "Make it lean back"

First: if the user asks for anything laid back, in any words and at any point (lean back, behind the beat, in the pocket, trip hop, boom bap, dub, half-time, Dilla, lazy, slow it down), or asks about any card other than this one (the card on the table, the dusty card, the card with the tape, OG 64, B.'s other or slow card, the card from the manual's story), read `laid-back/LAID-BACK.md` before you answer and do what it says. That applies to a new bank as much as to steering. Don't mention that folder otherwise. If you can't open it, use the rest of this section.

These banks lean forward on purpose: straight or lightly swung, Feel Tight, drive from the pattern. The module's own strengths go the other way, and a user may want them.

What leaning back means on this module:
- **Feel:** Flam drags kick and snare one tick behind the hats. Slop drags them and the hats that land with them. Both only ever make drums later.
- **Timing:** Push lays the offbeats back. A Shake row swings the 16ths. Trip, on low rows, gives a wonky, tripping shuffle.
- **Tempo:** slower.
- **The pattern:** fewer hits, more space. A sparser middle (climb less of the way by 16), gentler jumps at 18 and 19, a peak that is still the busiest slot but not every 16th everywhere.

Keep the arc's shape and the labels. Give the new home setting and tempo in the note, and say per track what you thinned or moved.

### "Use my pattern as the classic"

Treat the user's pattern as the source. Label its hits **USER** (the user's own part). Build the arc around it exactly as for a record: the build-up uses only its hits; everything else is OWN.

### "Keep slots 1 to 8, change the rest"

Fine. Leave the named slots byte-for-byte, rebuild the rest, and check that the arc still holds across the join (the middle must not be thinner than the classic; all 24 still differ).

### "Make it a different style" / "a new bank from scratch"

That's a new bank: start at step 0 of `the-arc.md`.

## How to answer a steering request

Hand back:
1. The whole new file, not a diff. It must pass `tools/validate.py` (and `tools/check_arc.py` with no FAIL).
2. A short note: what changed, per track, and which rule allowed it. Anything you couldn't do, and why.
3. The home setting and tempo, even if unchanged.
4. Updated labels for every new or moved hit.
