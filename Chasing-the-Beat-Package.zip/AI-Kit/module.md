# The module, as far as patterns care

The module is the **Making Sound Machines Stolperbeats**, a eurorack drum sequencer, on **stock firmware 163**. It plays six drum tracks from pattern banks stored as text files on an SD card. It makes no sound itself: each track sends a trigger to whatever drum voice the user patches.

Where each fact comes from:

- **[Manual p1 "Section"]**: the module's own manual, *Stolperbeats – Manual* by Making Sound Machines (the web manual saved as a 3-page PDF, last updated 2 Sep 2025, changelog up to firmware 162). Cited by PDF page and section heading. The manual calls Feel "Feeling"; this kit says Feel.
- **[Firmware]**: the firmware 163 timing tables (the manual doesn't give them), read out of the firmware by the unofficial *Stolperbeats Visualiser v2*. The same tables are in `tools/hw.py`.
- **[Card]**: read from the 64 card files in this package.

## The six tracks

| Track | Line name in the file | Length | Usual sound |
|---|---|---|---|
| Kick | `KICK` | 4 bars (64 steps) | kick drum |
| Snare | `SNARE` | 4 bars (64 steps) | snare or clap |
| Hihat 1 | `HIHAT1` | 1 bar (16 steps) | closed hat |
| Hihat 2 | `HIHAT2` | 1 bar (16 steps) | open hat |
| Perc 1 | `PERC1` | 1 bar (16 steps) | any percussion |
| Perc 2 | `PERC2` | 1 bar (16 steps) | any percussion |

- **Kick and Snare run 4 bars. The other four run 1 bar**, so whatever is on a hat or perc track plays every bar. [Manual p1 "Select Pattern"] A hat part that changes from bar to bar can't be held: pick one bar.
- **Each track has its own knob** (an encoder). Turning it picks one of the 24 patterns in the bank for that track. Clicking it mutes the track. [Manual p1 "Select Pattern"]
- **Tracks are independent.** Any kick pattern plays with any snare pattern. The user can have Kick on slot 5 and Hihat 1 on slot 20. [Manual p1 "Select Pattern"] This is why every track in a bank must make sense on its own at every slot.

## Banks, slots and steps

- **A bank** is one file: 24 patterns for each of the six tracks. [Manual p1 "Select Pattern", Card]
- **A slot** (also "knob position") is one of the 24 patterns of a track, numbered 1 to 24 here. In the file they're `PTN0` to `PTN23`, so slot 1 is `PTN0` and slot 24 is `PTN23`. [Card]
- **64 banks** fit on a card: files `PatternBank000.txt` to `PatternBank063.txt`. File N is bank N+1. [Manual p2 "Pattern Banks" and "SD Card contents"]
- **16 steps a bar.** Before any timing setting, each step is a straight 16th note. Step 1 is beat 1, step 5 beat 2, step 9 beat 3, step 13 beat 4. [Manual p1 "Select Pattern"]

Names used for the steps inside a beat, all through this kit:

| Step in the beat | 1st | 2nd | 3rd | 4th |
|---|---|---|---|---|
| Name | the beat | the **e** | the **+** ("and") | the **a** |
| Steps in a bar | 1, 5, 9, 13 | 2, 6, 10, 14 | 3, 7, 11, 15 | 4, 8, 12, 16 |

The + is the 8th note between beats. The e and the a are the 16ths either side of it.

## On or off, nothing in between

- **Every step is on (1) or off (0).** There is no loud or soft per hit, and no accent. [Card] (Accents exist only in the MIDI out and envelope settings, not in patterns: Manual p2 "Envelope and LFO Out", "Edit MIDI Out mapping".)
- A ghost note only sounds quieter if it sits on a track patched to a quieter sound. That's why the card puts quiet hits on a Perc track. [Card]
- **No 32nd notes, no ratchets** on firmware 163. [Firmware] The only way past 16ths is Rolls (below).

## What is global, not stored in the bank

The bank file holds patterns only. These are global settings, the same for every bank, and changing bank does not change them: [Manual p2 "MachineState.txt", Card]

- **Tempo** (15 to 250 BPM; Manual p1 "Press Play").
- **Timing**: one of four buttons, Trip, Shake, Push or Clave.
- **Shuffle row**: 1 to 7. Row 1 is straight in every Timing.
- **Feel**: Tight, Rolls, Flam or Slop (press the Timing button again to step through them).
- **Linear**: on or off.
- **Mutes.**

So a bank's "home setting" (its tempo, Timing, Shuffle row and Feel) is advice for the user to dial in by hand. It never goes in the file. Write it in your note.

A Shuffle or Timing change takes over at the next beat. Pattern, Feel and tempo changes happen at once. [Firmware]

## Nothing plays early

**Beats 1 and 3 always land on time, and no Feel setting ever makes a drum earlier.** [Firmware; Manual p1 "Timing and Feeling" describes Flam and Slop as delays] Shake and Push only ever delay a step. Flam and Slop only ever delay kick and snare. So the module can lean back (drag behind the beat) but it can't push ahead of it.

One exception to know about: the **Trip** Timing pulls the e (the 2nd step of a beat) a little earlier than a straight 16th on rows 3 to 7, while it pushes the + and the a late. The e still lands after the beat. Details and numbers: `timing.md`. [Firmware]

What this means for writing: forward drive has to come from the pattern and the tempo, not from a timing setting.

## Linear's pecking order

Linear is a button. When it's on and two tracks hit the same step, the lower one is silent: [Manual p1 "Linear + Reset In"; the full order is in p3 "Changelog", firmware 157]

- **Snare > Kick > Hihat 2 > Hihat 1**
- **Snare > Kick > Perc 2 > Perc 1**

So a hat or perc under a kick or snare drops out, the way a drummer's hand lifts. A kick on the same step as the snare drops too. Hats and percs never silence each other across the two chains. [Manual p3 "Changelog" 157, Firmware]

What this means for writing:
- Put the open hat on **Hihat 2** and the closed hat on **Hihat 1**. With Linear on, the open hat then cuts the closed one, like a drummer's foot.
- Put the **dense** perc part on **Perc 1** and the **sparse, important** one on **Perc 2**. Linear then trims the dense part, not the important one.
- At a busy peak (kick on every 8th), Linear empties most hats. That's why every bank says "Linear off for the climb".

## Rolls

Rolls is one of the Feel settings. With Feel on Rolls, after every Hihat 2 hit the module re-fires Hihat 2 until the next step. [Manual p1 "Timing and Feeling": Hihat 2 becomes a trigger burst; Firmware for the detail] On Shuffle rows 1 and 4 it re-fires on every tick; on the other rows on every second tick. [Firmware] On a straight grid (row 1) that's 4 hits inside one 16th. (The exact count is still to be checked by ear on a module.)

What this means for writing: Hihat 2 is the Rolls track. Keep it **empty or one hit at the drop (slot 17)**, and **on 8ths, not 16ths, at the peak (slot 20)**, so each burst has room.

## Triplets

The grid is 16ths. There is no triplet grid. On **Trip row 5**, step 3 of each beat lands exactly on the last triplet (67% of the beat), so steps 1 and 3 together make a clean triplet shuffle. Steps 2 and 4 land at 17% and 83%: not triplets. [Firmware] A triplet-feel bank uses **steps 1 and 3 of each beat only**.

## Saving to the card

The module writes patterns and settings to the SD card when the sequencer is **stopped**. Press stop before powering down. [Manual p2 "SD Card"] After copying new files to a card, press play then stop once so the module saves its state.

## Other files on the card (never write these)

The card also holds `MachineConfig.txt`, `MachineState.txt`, `EnvelopeSettings.txt` and MIDI maps. They hold the owner's own settings. [Manual p2-3 "SD Card contents", Card] A bank you write is one `PatternBankNNN.txt` file and nothing else.
