# Credits for this folder

The eight banks, the slow method and the tools here are B.'s work (The Beatnik Himself), shared under the same license as the rest of the package: CC BY 4.0, credit "Chasing the Beat by The Beatnik Himself and Pulse" (see `../../LICENSE`).

The sources below are cited, not relicensed. They belong to their owners. Each bank page says which hits came from where, with the labels used across the kit, plus one more:

| Label | Source |
|---|---|
| THESIS | Wragg, *The High Art of Trip Hop* (PhD thesis, University of Waikato, 2018). Bank 6. |
| BOOK | *The Greatest Drum Beats*: p. 59 (bank 2's kick) and p. 10 (bank 3's kick and snare). |
| ST | SuperTime Ultra groove studies: Dilla neo-soul, Funky Drummer, Amen break, Dilla drunk swing, hip-hop jazz, dubstep half-step. |
| ARCHIVE | Bank 7, Wave: a proposed grid from the project's own style research. |
| OWN | The builder's own programming, in the style. |

Also drawn on: Ethan Hein's step-by-step Funky Drummer build and Amen listening guide; BAP Studio's hip-hop pattern notes; Dan Charnas, *Dilla Time* (2022).

Bank names here are plain style names. Where a bank is drawn from a record, its page names the record so you can find it. No audio, lyrics or recordings are included, and nothing here is endorsed by the artists or labels.
