"""Checks a laid-back bank against the slow arc's rules. Needs only engine/core.py.
usage: python3 -B check_laidback.py <bank file> --knobs K=8,S=9,H1=10,H2=6,P1=6,P2=6 [--triplet]
       python3 -B check_laidback.py <bank file> --notes <bank file>.notes.json     (lb_build.py writes this)
Prints PASS or FAIL lines. FAIL breaks a rule; WARN is worth a listen, not wrong."""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'engine'))
from core import *

a = sys.argv[1:]; f = a[0]; trip = '--triplet' in a
if '--notes' in a:
    m = json.load(open(a[a.index('--notes') + 1])); K = {t: m['classic_knob'][t.lower()] for t in NAMES}; trip = m['triplet']
else:
    kv = dict(x.split('=') for x in a[a.index('--knobs') + 1].split(','))
    short = {'K': 'KICK', 'S': 'SNARE', 'H1': 'HIHAT1', 'H2': 'HIHAT2', 'P1': 'PERC1', 'P2': 'PERC2'}
    K = {short[k]: int(v) for k, v in kv.items()}
fail, warn = [], []
raw = open(f, newline='').read()
if not (len(raw.encode()) == 7462 and raw.count('\r\n') == 149): fail.append('format: must be 7,462 bytes and 149 CRLF lines')
by = load(f)
for t in NAMES:
    ps = by[t]; L = K[t]
    if len(ps) != 24: fail.append(f'{t}: {len(ps)} patterns, needs 24'); continue
    if len(set(ps)) != 24: fail.append(f'{t}: the 24 patterns are not all different')
    if hits(ps[0]) == 0: fail.append(f'{t}: slot 1 is empty')
    for i in range(L - 1):
        if not (subset(ps[i], ps[i + 1]) and hits(ps[i]) < hits(ps[i + 1])): fail.append(f'{t}: build-up does not climb at slot {i + 1} to {i + 2}')
    for i in range(L, 15):
        if energy(ps[i + 1]) < energy(ps[i]): warn.append(f'{t}: middle energy dips at slot {i + 2}')
    for i in range(16, 19):
        if not (subset(ps[i], ps[i + 1]) and hits(ps[i]) < hits(ps[i + 1])): fail.append(f'{t}: B part (17-20) does not climb at slot {i + 2}')
    for i in range(20, 23):
        if hits(ps[i + 1]) > hits(ps[i]) + 1: fail.append(f'{t}: donor tail rises by more than one hit at slot {i + 2}')
    if hits(ps[16]) >= hits(ps[L - 1]): warn.append(f'{t}: slot 17 is not thinner than the classic (17 should be the groove with a hole in it)')
    if trip and not all(on_trip(p) for p in ps): fail.append(f'{t}: off the triplet grid (step 4 of a beat used)')
    if sum(1 for p in ps if hits(p) == 0) > 1: fail.append(f'{t}: more than one empty pattern')
    if any(hits(p) == 0 for i, p in enumerate(ps) if i != 16): fail.append(f'{t}: an empty pattern outside slot 17')
if '--notes' in a:   # the builder's own record of the anchor (steps every draft pattern from the classic on shares)
    SA, bucket = tuple(frozenset(x) for x in m['snare_anchor']), fail
else:                # no record: estimate it from the finished bank, so only warn
    SA, bucket = anchors(by['SNARE'][:16], K['SNARE']), warn
for i in range(K['SNARE'] - 1, 20):
    if not subset(SA, by['SNARE'][i]): bucket.append(f'snare anchor missing at slot {i + 1}')
T = [sum(hits(by[t][i]) for t in NAMES) for i in range(24)]
if not (T[16] < T[17] < T[18] < T[19]): fail.append(f'bank total must rise 17 to 20: {T[16:20]}')
if not (T[20] > T[21] > T[22] > T[23]): fail.append(f'bank total must fall 21 to 24: {T[20:24]}')
for t in LONG:
    for i in range(K[t] - 1, 16):
        if by[t][i][0] != by[t][i][2]: warn.append(f'{t}: bars 1 and 3 differ at slot {i + 1} (fine only if the source itself has a different bar 3)')
print('bank totals per slot:', ' '.join(map(str, T)))
for x in fail: print('FAIL', x)
for x in warn: print('WARN', x)
print('PASS' if not fail else f'{len(fail)} FAIL')
