"""Laid-back bank builder: the exact build logic of B.'s laid-back banks, wrapped for one new bank.

usage:
  python3 -B lb_build.py --rebuild-egg <out dir>      rebuild the 8 egg banks from their drafts (proves the engine: must match Card Files)
  python3 -B lb_build.py <spec.json> <out file>        build one new bank from a spec (see the-slow-arc.md, "The spec")

The engine (engine/build6.py, engine/core.py) is the card's own builder, unchanged. This wrapper only feeds it:
the 8 egg drafts (drafts/) plus, for a new bank, a draft made from your spec. Writes the bank file and <out file>.notes.json."""
import sys, os, json, types, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'engine'))
from core import *

TRACKS = NAMES                                   # KICK SNARE HIHAT1 HIHAT2 PERC1 PERC2
MOVES = ('HALF', 'OFF', 'HEMI', 'ROCK', 'DROP', 'OPEN', 'SAIDI', 'TUMBAO', 'BELL')
DRAFTS = os.path.join(HERE, 'drafts')
EGG = json.load(open(os.path.join(DRAFTS, 'drafts.json')))

def die(msg): sys.exit('SPEC PROBLEM: ' + msg)

def prefix(classic, n, T, trip):
    """slots before the classic in a draft. The engine never reads these; it makes the real build-up itself."""
    us = units(classic); us.sort(key=lambda u: (rank(u[0][1], T, trip), group_rank(u), u[0][1]))
    st, cur = [], empty_like(classic)
    for u in us: cur = apply(cur, u); st.append(cur)
    st = st[:-1] or [empty_like(classic)]
    return [st[min(i, len(st) - 1)] for i in range(n)]

def pat(x, bars, where):
    if not isinstance(x, list) or len(x) != bars: die(f'{where}: needs {bars} bar(s), each a list of steps 1-16')
    for b in x:
        if not isinstance(b, list) or any((not isinstance(s, int)) or s < 1 or s > 16 for s in b): die(f'{where}: steps must be whole numbers 1-16')
    return tuple(frozenset(b) for b in x)

def draft_from_spec(spec, tmp):
    for k in ('name', 'bpm', 'timing', 'shuffle_row', 'feel', 'move', 'donor', 'tracks'):
        if k not in spec: die(f'missing "{k}"')
    if spec['timing'] not in ('Trip', 'Shake', 'Push', 'Clave'): die('timing must be Trip, Shake, Push or Clave')
    if spec['move'] not in MOVES: die('move must be one of ' + ', '.join(MOVES))
    trip = bool(spec.get('triplet', False))
    lanes, ck = [], {}
    for t in TRACKS:
        tr = spec['tracks'].get(t)
        if tr is None: die(f'track {t} missing')
        bars = 4 if t in LONG else 1
        c = pat(tr['classic'], bars, f'{t} classic'); k = int(tr['knob'])
        if hits(c) == 0: die(f'{t}: the classic is empty (give it at least one hit)')
        if not 1 <= k <= 16: die(f'{t}: knob must be 1-16')
        var = [pat(v, bars, f'{t} variation {i + 1}') for i, v in enumerate(tr['variations'])]
        if len(var) != 24 - k: die(f'{t}: needs exactly {24 - k} variations (24 minus the knob), got {len(var)}')
        if len(set(var)) != len(var) or c in var: die(f'{t}: variations must all differ from each other and from the classic')
        if trip and not all(on_trip(p) for p in [c] + var): die(f'{t}: triplet bank, so only steps 1-2-3 of each beat (never 4, 8, 12, 16)')
        lanes.append(prefix(c, k - 1, spec['timing'], trip) + [c] + var)
        ck[t.lower()] = k
    open(os.path.join(tmp, 'draft-new.txt'), 'w', newline='').write(write_bank(lanes))
    return {'bank': 9, 'file': 'draft-new.txt', 'name': spec['name'], 'bpm': spec['bpm'], 'timing': spec['timing'],
            'shuffle_row': spec['shuffle_row'], 'feel': spec['feel'], 'triplet_grid': trip, 'classic_knob': ck,
            'move': spec['move'], 'element': spec.get('element'), 'donor': spec['donor'],
            'donor_reason': spec.get('donor_reason', 'chosen for this bank')}

def engine(entries, tmp):
    for e in EGG: shutil.copyfile(os.path.join(DRAFTS, e['file']), os.path.join(tmp, e['file']))
    idx = os.path.join(tmp, 'index.json'); json.dump(entries, open(idx, 'w'))
    plan = types.ModuleType('plan')
    plan.DONOR = {e['bank']: (e['donor'], e['donor_reason']) for e in entries}
    plan.MOVE = {e['bank']: e['move'] for e in entries}
    plan.ELEMENT = {e['bank']: e['element'] for e in entries if e.get('element')}
    plan.DONOR_SWAP_PERCS = set()
    sys.modules['plan'] = plan
    sys.argv = ['build6.py', tmp, idx, tmp]
    import build6
    return build6

def save(b6, b, out):
    lanes, meta = b6.build_bank(b)
    txt = write_bank(lanes)
    assert len(txt.encode()) == 7462 and txt.count('\r\n') == 149
    open(out, 'w', newline='').write(txt)
    json.dump(meta, open(out + '.notes.json', 'w'), indent=1)
    return meta

if __name__ == '__main__':
    a = sys.argv[1:]
    tmp = tempfile.mkdtemp()
    try:
        if a and a[0] == '--rebuild-egg':
            os.makedirs(a[1], exist_ok=True)
            b6 = engine(EGG, tmp)
            for e in EGG:
                save(b6, e['bank'], os.path.join(a[1], f"bank-{e['bank']}.txt")); print('built egg bank', e['bank'], e['name'])
        elif len(a) == 2:
            spec = json.load(open(a[0]))
            new = draft_from_spec(spec, tmp)
            if new['donor'] not in [e['bank'] for e in EGG]: die('donor must be an egg bank number, 1-8')
            b6 = engine(EGG + [new], tmp)
            m = save(b6, 9, a[1])
            print('built', a[1]); print('classic knobs:', m['classic_knob']); print('B part move:', m['move'], '| donor at 21-24:', m['donor'], m['donor_name'])
        else:
            print(__doc__)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
