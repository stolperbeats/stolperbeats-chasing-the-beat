"""Laid-back builder core helpers: read/write bank files, step classes, anchors, triplet grid.
A pattern is a tuple of bars (4 for Kick/Snare, 1 for hats/percs); each bar is a frozenset of steps 1-16."""
import json, os

NAMES = ['KICK', 'SNARE', 'HIHAT1', 'HIHAT2', 'PERC1', 'PERC2']
LONG = ('KICK', 'SNARE')
TRIPSET = frozenset(s for s in range(1, 17) if s % 4 != 0)   # steps 1-2-3 of each beat
CLAVE_AXIS = frozenset({1, 4, 7, 9, 12, 15})                  # steps Clave timing keeps on time

def F(*bars): return tuple(frozenset(b) for b in bars)
def hits(p): return sum(len(b) for b in p)
def empty_like(p): return tuple(frozenset() for _ in p)
def union(p, q): return tuple(a | b for a, b in zip(p, q))
def minus(p, q): return tuple(a - b for a, b in zip(p, q))
def subset(p, q): return all(a <= b for a, b in zip(p, q))
def dist(p, q): return sum(len(a ^ b) for a, b in zip(p, q))
def bstr(p): return ', '.join(''.join('1' if i in b else '0' for i in range(1, 17)) for b in p)
def row(p): return ' '.join(''.join('x' if s in b else '.' for s in range(1, 17)) for b in p)

def load(path):
    t = open(path, newline='').read()
    by = {}
    for r in t.split('\r\n'):
        if not r: continue
        nm, rest = r.split(' > PTN'); i, p = rest.split(': ')
        by.setdefault(nm, []).append(tuple(frozenset(k + 1 for k, c in enumerate(b) if c == '1') for b in p.rstrip(';').split(', ')))
    return by

def write_bank(lanes):
    lines = []
    for nm, pats in zip(NAMES, lanes):
        assert len(pats) == 24, (nm, len(pats))
        for i, p in enumerate(pats):
            lines.append(f"{nm} > PTN{i}: {bstr(p)};")
        lines.append('')
    return '\r\n'.join(lines[:-1]) + '\r\n'

def sub(step):
    """0 = beat, 1 = e, 2 = +, 3 = a"""
    return (step - 1) % 4

def trip_remap(p):
    """put a pattern on the triplet grid: the a (step 4 of a beat) moves to the + (step 3), as the drafts do."""
    return tuple(frozenset(s - 1 if s % 4 == 0 else s for s in b) for b in p)

def on_trip(p): return all(s in TRIPSET for b in p for s in b)

def rank(step, timing, triplet):
    """how early a step belongs in a build (lower = more basic).
    Shake/Push: beat, +, a, e (Shake swings the e and a, so the swing arrives last).
    Trip: beat, +, e, a (the a rushes toward the next beat, so it comes last).
    Triplet grid: beat, last triplet (step 3), middle triplet (step 2).
    Clave: 1 and 3, then the 3-3-2 points Clave keeps on time, then 2 and 4 (which drag), then the rest."""
    r = sub(step)
    strong = {1: 0, 9: 1, 5: 2, 13: 3}.get(step, 4)
    if triplet:
        cls = {0: 0, 2: 1, 1: 2, 3: 3}[r]
    elif timing == 'Trip':
        cls = {0: 0, 2: 1, 1: 2, 3: 3}[r]
    elif timing == 'Clave':
        cls = 0 if step in (1, 9) else 1 if step in CLAVE_AXIS else 2 if r == 0 else 3 if r == 2 else 4
    else:
        cls = {0: 0, 2: 1, 3: 2, 1: 3}[r]
    return cls * 10 + strong + step / 100

def anchors(pats, start):
    """per bar: steps that every pattern from slot `start` (1-based) to 24 shares - the bank's anchor as built."""
    out = None
    for p in pats[start - 1:]:
        out = list(p) if out is None else [a & b for a, b in zip(out, p)]
    return tuple(frozenset(b) for b in out)

def units(target, base=None):
    """split target-minus-base into units: a step in bars 1&3 (or 2&4) together, else single bars."""
    base = base or empty_like(target)
    add = [set(y - x) for x, y in zip(base, target)]
    out = []
    if len(add) == 4:
        for (i, j) in ((0, 2), (1, 3)):
            both = add[i] & add[j]
            for s in both: out.append(((i, s), (j, s)))
            for k in (i, j):
                for s in add[k] - both: out.append(((k, s),))
    else:
        out = [((0, s),) for s in add[0]]
    return out

def apply(p, u):
    bars = [set(b) for b in p]
    for (k, s) in u: bars[k].add(s)
    return tuple(frozenset(b) for b in bars)

def group_rank(u):
    """bars 1&3 together first, then 2&4 together, then single bars 1/3, then 2, then 4"""
    ks = sorted(k for k, _ in u)
    if ks == [0, 2]: return 0
    if ks == [1, 3]: return 1
    if ks[0] in (0, 2): return 2
    return 3 if ks[0] == 1 else 4

def maxrun(bar):
    best = run = 0
    for i in range(1, 17):
        run = run + 1 if i in bar else 0; best = max(best, run)
    return best

def energy(p):
    """density plus syncopation: off-beat 16ths count extra"""
    return hits(p) + 0.5 * sum(1 for b in p for s in b if s % 2 == 0)
