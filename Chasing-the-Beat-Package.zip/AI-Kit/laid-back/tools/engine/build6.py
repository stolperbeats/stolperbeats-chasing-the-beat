"""Laid-back builder: the full 24-slot arc for every track of every bank.
usage: python3 build6.py <draft Card Files dir> <bank-index.json> <output dir>

Slots 1..L      build-up, thinnest first, strictly climbing, ending on the classic (L = the classic knob)
Slots L+1..16   middle: the bank's own variations, chosen and ordered as a gradual rise, one small change at a time
Slots 17..20    B part: the host groove with one main element changed (plan.MOVE), stripped at 17, full at 20
Slots 21..24    donor tail: a new classic from one other bank (plan.DONOR), easing off a little each slot
"""
import sys, os, json, shutil
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from core import *
from plan import DONOR, MOVE, ELEMENT, DONOR_SWAP_PERCS

IN, IDXF, OUT = sys.argv[1:4]
IDX = {m['bank']: m for m in json.load(open(IDXF))}
DATA = {b: load(os.path.join(IN, m['file'])) for b, m in IDX.items()}
SMALL = ('HIHAT2', 'PERC1', 'PERC2')

def info(b):
    m = IDX[b]
    ck = {t: m['classic_knob'][t.lower()] for t in NAMES}
    by = DATA[b]
    return dict(T=m['timing'], row=m['shuffle_row'], trip=m['triplet_grid'], ck=ck, by=by,
                classic={t: by[t][ck[t] - 1] for t in NAMES},
                SA=anchors(by['SNARE'], ck['SNARE']), KA=anchors(by['KICK'], ck['KICK']),
                pool={t: by[t][ck[t]:] for t in NAMES})

def donor_info(host):
    """the donor bank as the host will play it: Perc 1 and Perc 2 trade places where plan.DONOR_SWAP_PERCS says so"""
    d = info(DONOR[host][0])
    if host in DONOR_SWAP_PERCS:
        for k in ('classic', 'pool'):
            d[k] = dict(d[k], PERC1=d[k]['PERC2'], PERC2=d[k]['PERC1'])
    return d

# ---------------------------------------------------------------- build-up
def buildup(classic, L, T, trip, protect, avoid=frozenset()):
    """thinnest first, anchors first, then by how basic each step is under this Timing; ends on the classic.
    avoid: patterns that must not appear as a build-up step (the donor's classic at slot 21)"""
    us = units(classic)
    def key(u):
        s = u[0][1]
        prot = all(st in protect[k] for k, st in u)
        return (0 if prot else 1, rank(s, T, trip), group_rank(u), s)
    us.sort(key=key)
    # keep the slow build B. liked: if there are fewer additions than knob positions,
    # let paired bars arrive one bar at a time (bar 1 before bar 3, bar 2 before bar 4), earliest additions first
    i = 0
    while len(us) < L and i < len(us):
        if len(us[i]) == 2:
            us[i:i + 1] = [(us[i][0],), (us[i][1],)]
        i += 1
    def states(order):
        fine, cur = [], empty_like(classic)
        for u in order:
            cur = apply(cur, u); fine.append(cur)
        return fine
    fine = states(us)
    L = max(1, min(L, len(fine)))
    ix = sorted(set(round(i * (len(fine) - 1) / (L - 1)) for i in range(L))) if L > 1 else [len(fine) - 1]
    for n, k in enumerate(ix[:-1]):
        if fine[k] not in avoid: continue
        lo = ix[n - 1] + 1 if n else 0; hi = ix[n + 1] - 1
        alt = [j for j in range(lo, hi + 1) if fine[j] not in avoid]
        if alt: ix[n] = min(alt, key=lambda j: abs(j - k)); continue
        if k + 1 < len(us):   # no slack: let the next two additions arrive in the other order
            us[k], us[k + 1] = us[k + 1], us[k]; fine = states(us)
    out = [fine[k] for k in ix]
    assert out[-1] == classic
    return out

def build_len(t, old, classic):
    n = hits(classic)
    if t in SMALL and n >= 3: return min(n, max(old, 3))   # percussion colour now builds in over at least 3 slots
    return old

# ---------------------------------------------------------------- B part (slots 17-20)
def halve(bar, minimum=2):
    s = set(bar)
    if any(sub(x) in (1, 3) for x in s): out = {x for x in s if sub(x) in (0, 2)}
    elif any(sub(x) == 2 for x in s): out = {x for x in s if sub(x) == 0}
    else: out = s & {1, 9}
    if len(out) < minimum: out |= {1, 9}
    return frozenset(out)

def hemi(trip): return frozenset({1, 3, 6, 9, 11, 14}) if trip else frozenset({1, 4, 7, 10, 13})

def element_track(c, choices):
    return min(choices, key=lambda t: (hits(c['classic'][t]), choices.index(t)))

def b_full(b, base=None):
    """slot 20 per track, the B element tracks, and the per-track 'keep first' sets.
    base: the host pattern each track's B is made from (default: the classic)"""
    c = info(b); mv = MOVE[b]; T, trip = c['T'], c['trip']
    P = dict(base or c['classic']); core = {t: empty_like(P[t]) for t in NAMES}; elem = set()
    K = [set(x) for x in P['KICK']]
    if mv == 'HALF':
        K = [{s for s in bar if sub(s) in (0, 2) and s not in (5, 13)} | set(ka) for bar, ka in zip(K, c['KA'])]
        for bar in K:
            if not bar: bar.add(1)
        h = halve(P['HIHAT1'][0])
        if h <= {1, 5, 9, 13}: h = h | {15}   # quarter-note hats get a + of 4 pickup, so they never match a build-up step
        P['HIHAT1'] = (h,)
        h2 = {s for s in P['HIHAT2'][0] if sub(s) in (0, 2)} or {15}
        P['HIHAT2'] = (frozenset(h2),); elem.add('HIHAT1')
        core['HIHAT1'] = P['HIHAT1']
    elif mv == 'OFF':
        newK = []
        for i, bar in enumerate(K):
            nb = set()
            for s in bar:
                if s == 1 and i in (1, 3): nb.add(3)
                elif s == 9: nb.add(11)
                elif s in (5, 13): nb.add(s + 2)
                else: nb.add(s)
            newK.append(nb)
        K = newK
        core['KICK'] = tuple(frozenset(x for x in bar if (i in (0, 2) and x in (1, 11)) or (i in (1, 3) and x == 3)) for i, bar in enumerate(K))
    elif mv == 'HEMI':
        e = ELEMENT.get(b) or element_track(c, ['HIHAT2', 'PERC1', 'PERC2'])
        P[e] = (hemi(trip),); elem.add(e); core[e] = P[e]
        h = P['HIHAT1'][0]
        if any(sub(s) in (1, 3) for s in h):
            keep = frozenset(s for s in h if sub(s) in (0, 2))
            if len(keep) >= 3: P['HIHAT1'] = (keep,)
    elif mv == 'ROCK':
        K = [{1, 9} | ({s for s in bar if s >= 14} if i == 3 else set()) for i, bar in enumerate(K)]
        core['KICK'] = tuple(frozenset({1, 9}) for _ in K)
    elif mv == 'DROP':
        K = [(set(bar) - {1}) | {9} for bar in K]
        core['KICK'] = tuple(frozenset({9}) for _ in K)
    elif mv == 'OPEN':
        P['HIHAT2'] = (frozenset({3, 7, 11, 15}),); elem.add('HIHAT2'); core['HIHAT2'] = P['HIHAT2']
        h = P['HIHAT1'][0] - {3, 7, 11, 15}
        P['HIHAT1'] = (h if len(h) >= 3 else h | {1, 5, 9, 13},)
    elif mv == 'SAIDI':
        K = [{s for s in bar if sub(s) in (0, 2)} | {1, 7, 9} for bar in K]
        core['KICK'] = tuple(frozenset({1, 7, 9}) for _ in K)
    elif mv == 'TUMBAO':
        K = [{1, 7, 13} | ((set(bar) - {1, 9}) if i == 3 else set()) for i, bar in enumerate(K)]
        core['KICK'] = tuple(frozenset({1, 7, 13}) for _ in K)
    elif mv == 'BELL':
        e = ELEMENT.get(b) or element_track(c, ['PERC1', 'PERC2'])
        P[e] = (frozenset({1, 5, 7, 9, 13, 15}),); elem.add(e); core[e] = P[e]
    P['KICK'] = tuple(frozenset(x) for x in K)
    # slot 20 lift: one new pickup hit late in bar 4 of snare and kick, leading into whatever comes next (no fill).
    # snare on the a of 4, kick on the a of 3 (or near it), so they never land together and Linear has nothing to cut
    lifts = {'SNARE': (15, 14, 11) if trip else (16, 14, 15), 'KICK': (11, 14, 10) if trip else (12, 14, 11)}
    late = {t: empty_like(P[t]) for t in NAMES}
    for t in ('SNARE', 'KICK'):
        bars = [set(x) for x in P[t]]
        taken = set(c['classic'][t][3]) | (set(P['SNARE'][3]) if t == 'KICK' else set())
        for s in lifts[t]:
            if s not in bars[3] and s not in taken and maxrun(bars[3] | {s}) <= 2:   # a pickup, never a roll
                bars[3].add(s); late[t] = tuple(frozenset({s}) if i == 3 else frozenset() for i in range(4)); break
        P[t] = tuple(frozenset(x) for x in bars)
    if not any(15 in bar for t in LONG for bar in P[t]):   # an open hat on the + of 4 previews the change, if the drums leave it room
        if 15 not in P['HIHAT2'][0]: late['HIHAT2'] = (frozenset({15}),)
        P['HIHAT2'] = (P['HIHAT2'][0] | {15},)
    if trip:
        P = {t: trip_remap(p) for t, p in P.items()}; core = {t: trip_remap(p) for t, p in core.items()}
        late = {t: trip_remap(p) for t, p in late.items()}
    core['LATE'] = late
    core['SNARE'] = union(core['SNARE'], c['SA'])
    if MOVE[b] in ('HALF', 'HEMI', 'OPEN', 'BELL'):
        k13 = tuple(frozenset({1} & bar) if i in (0, 2) else frozenset() for i, bar in enumerate(P['KICK']))
        core['KICK'] = union(core['KICK'], k13)
    return P, elem, core

def b_chain(t, P20, core, elem, used, T, trip):
    """slots 17-19 as a climbing chain inside slot 20: anchors and the B's own character first, time-keeping fillers last"""
    us = units(P20)
    def crank(s):
        r = sub(s)
        return {2: 0, 3: 1, 1: 2, 0: 3}[r]   # off-beat character first, plain beats last: a groove with a hole, not a count-in
    lift = core['LATE'][t]
    def key(u):
        s = u[0][1]
        prot = all(st in core[t][k] for k, st in u)
        islift = any(st in lift[k] for k, st in u)
        if t in LONG:   # answer bars and bar-4 pickups first, bars 1 and 3 last: the reverse of the build-up's order
            return (2 if islift else 0 if prot else 1, -group_rank(u), crank(s), s)
        return (2 if islift else 0 if prot else 1, crank(s), group_rank(u), s)
    us.sort(key=key)
    states, cur = [empty_like(P20)], empty_like(P20)
    for u in us:
        cur = apply(cur, u); states.append(cur)
    N = hits(P20); pc = hits(core[t])
    if t in elem: tg = [max(1, round(.6 * N)), round(.8 * N), round(.9 * N)]
    elif t == 'SNARE': tg = [pc, pc + round(.33 * (N - pc)), pc + round(.66 * (N - pc))]
    elif t in ('KICK', 'HIHAT1'): tg = [max(pc, round(.3 * N), 1), round(.55 * N), round(.8 * N)]
    else: tg = [0, round(.35 * N), round(.7 * N)]
    lo = 0 if (t in SMALL and t not in elem) else 1
    need = core[t] if t in LONG else empty_like(P20)   # kick and snare: the anchor and the B's own kick are there from slot 17
    ok = [k for k in range(lo, len(states) - 1) if states[k] not in used and subset(need, states[k])]
    best = None
    for i1 in range(len(ok)):
        for i2 in range(i1 + 1, len(ok)):
            for i3 in range(i2 + 1, len(ok)):
                ks = (ok[i1], ok[i2], ok[i3])
                cost = sum(abs(hits(states[k]) - a) for k, a in zip(ks, tg))
                if best is None or cost < best[0]: best = (cost, ks)
    if best is None: return None
    return [states[k] for k in best[1]]

def grow(p, extra):
    return tuple(frozenset(a | b) for a, b in zip(p, extra))

# ---------------------------------------------------------------- donor tail (slots 21-24)
def removable(p, protect, trip):
    """hits that can go, least needed first: 16ths, then +'s, then beats (never the protected anchor)"""
    out = []
    for i, bar in enumerate(p):
        for s in bar:
            if s in protect[i]: continue
            r = sub(s)
            out.append(({1: 0, 3: 1, 2: 2, 0: 3}[r], 0 if i == 3 else 1, -s, i, s))
    out.sort()
    return [(i, s) for *_, i, s in out]

def settle_moves(p, protect, trip):
    """move a rushing 16th onto the 8th before it (the a to the +, the e to the beat): same hits, more in the pocket"""
    mv = []
    for i, bar in enumerate(p):
        for s in sorted(bar):
            if s in protect[i] or sub(s) not in (1, 3): continue
            d = s - 1
            if d not in bar and (not trip or d in TRIPSET): mv.append((i, s, d))
    return mv

def drop(p, i, s): bars = [set(x) for x in p]; bars[i].discard(s); return tuple(frozenset(x) for x in bars)
def move(p, i, s, d): bars = [set(x) for x in p]; bars[i].discard(s); bars[i].add(d); return tuple(frozenset(x) for x in bars)

def ease(p, target, protect, trip, used):
    q = _ease(p, target, protect, trip, used)
    if q is None: raise RuntimeError(f"ease failed {row(p)} target {target}")
    return q

def _ease(p, target, protect, trip, used, lean=True, strict_plain=True):
    cur = p
    while hits(cur) > target:
        rm = removable(cur, protect, trip)
        if not rm: break
        cur = drop(cur, *rm[0])
    if cur not in used and cur != p: return cur
    for base in ([cur, p] if cur != p else [p]):
        for (i, s, d) in settle_moves(base, protect, trip):
            q = move(base, i, s, d)
            if q not in used and q != p: return q
        for (i, s) in removable(base, protect, trip):
            q = drop(base, i, s)
            if q not in used and q != p and hits(q) > 0: return q
        if not lean: continue
        # last resort for small parts: lean a hit back onto a nearby, plainer step
        for i, bar in enumerate(base):
            for s in sorted(bar, key=lambda x: -sub(x)):
                if s in protect[i]: continue
                for d in (s - 1, s - 2, s + 2, s - 4, s + 4):
                    plain = {0: 0, 2: 1, 3: 2, 1: 3}
                    if strict_plain and len(base) == 4 and plain[sub(d)] >= plain[sub(s)]: continue   # kick/snare: only lean onto a plainer step
                    if 1 <= d <= 16 and d not in bar and (not trip or d in TRIPSET):
                        q = move(base, i, s, d)
                        if q not in used and q != p: return q
    return None

def donor_tail(host, donor, used):
    c, d = info(host), donor_info(host)
    prot = {}
    for t in NAMES:
        pr = d['SA'] if t == 'SNARE' else d['KA'] if t == 'KICK' else (frozenset(),)
        pr = tuple(frozenset(x for x in bar if sub(x) == 0) for bar in pr)   # the donor's anchor beats; its shared ghosts may ease
        prot[t] = trip_remap(pr) if c['trip'] else pr
    fix = (lambda p: trip_remap(p)) if c['trip'] else (lambda p: p)
    out = {}
    for t in NAMES:
        u = used[t]
        c21 = fix(d['classic'][t])
        if c21 in u:   # the donor's classic already sits in this track: add its most common variation hit
            vocab = Counter((i, s) for v in d['pool'][t] for i, bar in enumerate(fix(v)) for s in bar if s not in c21[i])
            for (i, s), _ in vocab.most_common():
                q = apply(c21, ((i, s),))
                if q not in u: c21 = q; break
            else:
                c21 = ease(c21, hits(c21), prot[t], c['trip'], u)
        n = hits(c21)
        vocab = [fix(v) for v in d['pool'][t]]
        def step(prev, target, avoid):
            q = _ease(prev, target, prot[t], c['trip'], avoid, lean=False)
            if q is not None: return q
            alts = [v for v in vocab if v not in avoid and hits(v) <= hits(prev) and subset(prot[t], v)]   # the donor's own thinner variations
            if alts: return min(alts, key=lambda v: (-hits(v), dist(v, prev)))
            for sp in (True, False):
                q = _ease(prev, target, prot[t], c['trip'], avoid, lean=True, strict_plain=sp)
                if q is not None: return q
            alts = [v for v in vocab if v not in avoid and hits(v) <= hits(prev) + 1]
            if alts: return min(alts, key=lambda v: (hits(v) > hits(prev), dist(v, prev)))
            # nothing thinner is left that is new: add one of the donor's own ghost/pickup hits (bar 4 first)
            steps = Counter((i, s) for v in vocab for i, bar in enumerate(v) for s in bar)
            for (i, s2), _ in sorted(steps.items(), key=lambda kv: (-(kv[0][0] == len(prev) - 1), -kv[1])):
                if s2 in prev[i]: continue
                q = apply(prev, ((i, s2),))
                if q not in avoid: return q
            raise RuntimeError(f'donor tail stuck: host {host} {t} {row(prev)}')
        cands = [v for v in vocab if v not in u and v != c21 and subset(prot[t], v) and .8 * n <= hits(v) <= n]
        c22 = min(cands, key=lambda v: (hits(v) < .9 * n, dist(v, c21), -hits(v))) if cands else step(c21, n - 1 if n > 3 else n, u | {c21})
        n22 = hits(c22)
        small = n22 <= 3
        floor = lambda p: hits(tuple(a & b for a, b in zip(p, prot[t]))) + (1 if hits(p) > hits(tuple(a & b for a, b in zip(p, prot[t]))) else 0)
        c23 = step(c22, max(floor(c22), n22 if small else min(n22, round(.93 * n22))), u | {c21, c22})
        n23 = hits(c23)
        c24 = step(c23, max(floor(c23), n23 if small else min(n23, round(.85 * n22))), u | {c21, c22, c23})
        out[t] = [c21, c22, c23, c24]
    # whole-bank energy must step down each slot: thin the busiest track that can still give a hit
    for k in (1, 2, 3):
        while sum(hits(out[t][k]) for t in NAMES) >= sum(hits(out[t][k - 1]) for t in NAMES):
            done = False
            for t in sorted(NAMES, key=lambda t: -hits(out[t][k])):
                q = _ease(out[t][k], hits(out[t][k]) - 1, prot[t], c['trip'], used[t] | set(out[t][:k]) | set(out[t][k + 1:]))
                if q is not None and hits(q) < hits(out[t][k]):
                    out[t][k] = q; done = True; break
            if not done: raise RuntimeError(f'cannot ease host {host} slot {21 + k}')
    return out, prot

# ---------------------------------------------------------------- middle (after the classic, to slot 16)
def middle(pool, M, classic, exclude, protect):
    seen, cand = set(), []
    for p in pool:
        if p in exclude or p == classic or p in seen or not subset(protect, p): continue
        seen.add(p); cand.append(p)
    e0 = energy(classic)
    if len(cand) > M:   # leave out the busiest (headroom for slot 20), then take an even spread from calm to lively
        cand.sort(key=lambda p: (energy(p), dist(p, classic)))
        while len(cand) > M and energy(cand[-1]) > 1.15 * e0: cand.pop()
        if len(cand) > M:
            ix = sorted(set(round(i * (len(cand) - 1) / (M - 1)) for i in range(M))) if M > 1 else [len(cand) - 1]
            cand = [cand[i] for i in ix]
    assert len(cand) == M, (len(cand), M)
    # a gradual rise, one small change at a time: energy never falls; within the same level, step to the nearest neighbour
    cand.sort(key=energy)
    path = []
    while cand:
        lvl = energy(cand[0])
        group = [p for p in cand if energy(p) == lvl]
        prev = path[-1] if path else classic
        nxt = min(group, key=lambda p: dist(prev, p))
        path.append(nxt); cand.remove(nxt)
    return path

# ---------------------------------------------------------------- one bank
def build_bank(b):
    c = info(b); T, trip = c['T'], c['trip']
    lanes, meta = {}, {'bank': b, 'file': IDX[b]['file'], 'name': IDX[b]['name'], 'bpm': IDX[b]['bpm'], 'timing': T,
                       'row': c['row'], 'feel': IDX[b]['feel'], 'triplet': trip, 'move': MOVE[b], 'donor': DONOR[b][0],
                       'donor_name': IDX[DONOR[b][0]]['name'], 'donor_reason': DONOR[b][1]}
    bu, L = {}, {}
    dn = donor_info(b)
    for t in NAMES:
        prot = c['SA'] if t == 'SNARE' else c['KA'] if t == 'KICK' else (frozenset(),)
        L[t] = build_len(t, c['ck'][t], c['classic'][t])
        dcl = trip_remap(dn['classic'][t]) if trip else dn['classic'][t]
        bu[t] = buildup(c['classic'][t], L[t], T, trip, prot, avoid={dcl})
        L[t] = len(bu[t])
    used = {t: set(bu[t]) for t in NAMES}
    # the donor tail goes in first, so its classic at slot 21 only has to step around the build-up
    dt, dprot = donor_tail(b, DONOR[b][0], used)
    for t in NAMES: used[t] |= set(dt[t])
    P20, elem, core = b_full(b)
    bp = {}
    def off_snare(p20):   # a B kick that lands on a B snare hit is moved off it (Linear would cut it), unless the classic does the same
        sn = bp['SNARE'][3]; cl = tuple(a & b for a, b in zip(c['classic']['KICK'], c['classic']['SNARE']))
        out = []
        for i, bar in enumerate(p20):
            nb = set(bar)
            for s in bar & sn[i]:
                if s in cl[i] or s in core['KICK'][i]: continue
                nb.discard(s)
                for d in (s - 1, s + 1, s - 2, s + 2):
                    if 1 <= d <= 16 and d not in sn[i] and d not in nb and (not trip or d in TRIPSET): nb.add(d); break
            out.append(frozenset(nb))
        return tuple(out)
    for t in ['SNARE', 'KICK', 'HIHAT1', 'HIHAT2', 'PERC1', 'PERC2']:
        # the B is made from the classic; a track the move leaves alone (or whose B can't climb in four new steps)
        # is made from the bank's busiest variations instead, so slot 20 is full and still new
        ch = None
        for bs in [None] + sorted(c['pool'][t], key=lambda p: -energy(p)):
            if bs is None: p20, cr = P20[t], core
            else:
                p2, _, c2 = b_full(b, dict(c['classic'], **{t: bs}))
                p20, cr = p2[t], dict(core, LATE=dict(core['LATE'], **{t: c2['LATE'][t]}))
            if t == 'KICK': p20 = off_snare(p20)
            if p20 in used[t] or p20 == c['classic'][t]: continue
            ch = b_chain(t, p20, cr, elem, used[t] | {p20}, T, trip)
            if ch: break
        if not ch:   # last resort: add the bank's own most common extra hits to the classic-based B
            p20 = P20[t]
            vocab = Counter((i, s) for v in c['pool'][t] for i, bar in enumerate(v) for s in bar if s not in p20[i])
            for (i, s), _ in vocab.most_common():
                if maxrun(p20[i] | {s}) > 2: continue   # ghosts, never a roll
                p20 = apply(p20, ((i, s),))
                if p20 in used[t]: continue
                ch = b_chain(t, p20, core, elem, used[t] | {p20}, T, trip)
                if ch: break
        if not ch: raise RuntimeError(f'B chain failed: bank {b} {t}')
        bp[t] = ch + [p20]
        used[t] |= set(bp[t])
    mid = {}
    for t in NAMES:
        prot = c['SA'] if t == 'SNARE' else c['KA'] if t == 'KICK' else (frozenset(),)
        mid[t] = middle(c['pool'][t], 16 - L[t], c['classic'][t], used[t], prot)
        lanes[t] = bu[t] + mid[t] + bp[t] + dt[t]
        assert len(lanes[t]) == 24 and len(set(lanes[t])) == 24, (b, t)
    meta.update(classic_knob={t.lower(): L[t] for t in NAMES}, old_classic_knob={t.lower(): c['ck'][t] for t in NAMES},
                element=sorted(elem), hits={t.lower(): [hits(p) for p in lanes[t]] for t in NAMES},
                snare_anchor=[sorted(x) for x in c['SA']], kick_anchor=[sorted(x) for x in c['KA']],
                donor_snare_anchor=[sorted(x) for x in dprot['SNARE']],
                buildup_changed={t.lower(): bu[t] != c['by'][t][:L[t]] for t in NAMES})
    return [lanes[t] for t in NAMES], meta

if __name__ == '__main__':
    os.makedirs(os.path.join(OUT, 'Card Files'), exist_ok=True)
    metas = []
    for b in sorted(IDX):
        lanes, meta = build_bank(b)
        open(os.path.join(OUT, 'Card Files', IDX[b]['file']), 'w', newline='').write(write_bank(lanes))
        metas.append(meta)
    shutil.copyfile(os.path.join(IN, 'MachineConfig.txt'), os.path.join(OUT, 'Card Files', 'MachineConfig.txt'))
    json.dump(metas, open(os.path.join(OUT, 'meta6.json'), 'w'), indent=1)
    print('built', len(metas), 'banks')
