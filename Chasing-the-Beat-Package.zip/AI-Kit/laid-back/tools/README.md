# Laid-back tools

Run them with `python3 -B` (the `-B` keeps Python from leaving cache folders behind). Python 3, nothing to install.

| File | What it does |
|---|---|
| `lb_build.py` | Builds a new laid-back bank from a spec (`../the-slow-arc.md`, "The spec"), or rebuilds the eight. |
| `example-spec.json` | A complete spec ("Rainy boom bap") that builds and passes as is. Copy it to start a new bank. |
| `check_laidback.py` | Checks a bank against the slow arc's rules. Prints PASS, or FAIL and WARN lines. |
| `engine/build6.py`, `engine/core.py` | The builder that made the laid-back card, unchanged except for comments. `lb_build.py` feeds it; don't edit it. |
| `drafts/` | The eight banks as the builder reads them: classic at its knob, the bank's own variations after it. `drafts.json` holds each bank's knobs, Timing, move and donor. |

## Prove it first

```
python3 -B lb_build.py --rebuild-egg /tmp/egg
```

It writes `bank-1.txt` to `bank-8.txt`. Each must be byte-for-byte the same as the file in `../Card Files/` (`cmp` or a file compare). If they match, the engine is the real one and anything you build with it is built the way the card was.

## Build a bank

```
python3 -B lb_build.py my-bank.json my-bank.txt
python3 -B check_laidback.py my-bank.txt --notes my-bank.txt.notes.json
```

- A spec problem stops with `SPEC PROBLEM:` and says what to fix (most often the number of variations: 24 minus the knob).
- `my-bank.txt.notes.json` holds the knobs the builder actually used (it can shorten a build-up), the hits per slot and the snare anchor. Give the user the knobs.
- The donor must be one of the eight (1 to 8). To use another bank as a donor, add its draft to `drafts/` and an entry to `drafts.json`, in the same shape.

## Checking a bank without notes

```
python3 -B check_laidback.py some-bank.txt --knobs K=8,S=9,H1=10,H2=6,P1=6,P2=6 [--triplet]
```

Without the notes the snare anchor is estimated, so a missing anchor is a WARN, not a FAIL.
