# The slow arc: how the laid-back banks were built

B.'s rule for the laid-back card: there are two kinds of music, music that makes you lean forward and music that makes you lean back. These banks lean back. Picture walking down the street with headphones on: house and techno put your head down and push you on; these let you sit back into the step.

The main kit's arc (`the-arc.md`) chases the beat: build fast, drop at 17, peak at 20. This one follows the beat. It builds slowly, moves by changing one thing, and hands over to another groove at the end instead of peaking.

The code that does all of this is `tools/lb_build.py`. It wraps the builder that made the card, unchanged: it rebuilds all eight banks in this folder byte for byte. This file says the same thing in words.

## Words used here

- **Slot:** one of the 24 knob positions of a track.
- **Classic:** the track's home groove, as the source gives it (or the builder's own part where the source has none, labelled OWN).
- **Knob:** the slot the classic sits at. It's different for each track: a kick might sit at 10, an open hat at 1.
- **Anchor:** the hits that make the style. The snare's anchor is the hits every pattern from the classic on shares (usually the backbeat, or the beat-3 hit in a half-time bank). The anchor never leaves, from the classic to slot 20.
- **Variations:** the bank's own new rhythms in the style. They live after the classic.
- **Donor:** one other bank whose groove plays at 21 to 24, on this bank's sounds.
- **Energy:** hits, plus half a point for each off-beat 16th (an e or an a). Used to put variations in order.

## The rules that never bend

- **Pattern 1 is the thinnest.** Tracks build up, then vary. Never full-to-thin.
- **Every track has 24 different patterns.** The module picks each track's pattern on its own, so a track never repeats a slot.
- **Kick and Snare have 4 bars: bars 1 and 3 match, bar 2 answers, bar 4 carries the pickup.** Only a source can break this (the Amen break's bars 3 and 4 are the record's).
- **No fills, no rolls.** A pickup is one or two hits late in bar 4.
- **Anchors hold.** Density changes around them, they never drop.
- **Variations are new rhythms, not thinned copies.** Hits move to new places. A pattern that's just the classic with hits removed doesn't count as a variation.
- **Ghosts go on a Perc track** with a quiet sound. There's no velocity in the file, so a ghost on the Snare track is just another snare.
- **Stock firmware 163, no 32nd notes.** Timing, Shuffle, Feel and tempo are global on the module, not in the file.

## The shape

```
 1 ............ classic ............ 16 | 17  18  19  20 | 21  22  23  24
   build-up      (knob)    middle        |    B part      |    donor
   thin -> full            gentle rise   | hole -> full   | donor's classic, easing back
```

| Slots | Part | In one line |
|---|---|---|
| 1 to the knob | Build-up | Thinnest first, only adds, ends on the classic. Up to 10 slots long. |
| After the knob to 16 | Middle | The bank's own variations, energy never falling, one small change at a time. |
| 17 to 20 | B part | The same groove with one big thing changed. 17 has a hole in it, 18 to 20 add back, 20 ends on a pickup. |
| 21 to 24 | Donor | Another bank's classic on this bank's sounds, easing back into the pocket. |

Slots 17 and 21 line up across all six tracks, so a player can turn every knob to 17 for the breakdown and to 21 for the handover.

## Step 0: gather the groove

For each of the six tracks, write down:

1. **The classic**, with its label (BOOK, ST, THESIS, ARCHIVE, OWN, or USER if the user gave it). Kick and Snare as 4 bars, the others as 1 bar.
2. **The sound to patch.** Closed hat on Hihat 1 (or a ride, in a jazz bank), open hat on Hihat 2, ghosts on Perc 1, a second ghost/rim/shaker layer on Perc 2. If the style names a perc job (cowbell, shaker, bell), that's the track's job.
3. **The knob** for the classic. How slowly it should arrive:
   - Kick, Snare, Hihat 1: usually 7 to 10.
   - Hihat 2, Perc 1, Perc 2: usually 1 to 6. A one-hit open hat sits at 1.
   - Never more hits' worth of slots than the classic has hits: a 4-hit classic can't take more than 4 build-up slots. (The tool shortens it if you ask for too many.)
4. **The home setting.** See `home-settings.md`.
5. **The B-part move.** Pick one, from the table below, by style.
6. **The donor.** Pick one bank (see "Picking a donor").

## Step 1: write the variations (the creative step)

This is the only step the tool leaves to you. Each track needs **exactly 24 minus its knob** variations: a kick at knob 8 needs 16, a one-hit open hat at knob 1 needs 23.

- **The bank's own vocabulary first.** The source's other bars, its documented variations and the named moves of the style (a boom-bap kick stutter on the a of 1, a soul bounce on the + of 2, a ghost before the backbeat, an open hat on the + of 4). After that, your own programming in the style, labelled OWN.
- **About as busy as the classic.** Most variations land between a little under the classic and about 15% more energy than it. Write a few busier ones too: the builder leaves out the busiest so the B part has room above the middle, and it may use them in the B part.
- **Keep the anchor in every variation**, in every bar (kick on 1 in bars 1 and 3 where that's the style; the snare's backbeat or beat-3 hit).
- **Kick and Snare:** bars 1 and 3 match. Put the changes in bar 2 (the answer) and bar 4 (the pickup) first.
- **Hats:** 24 different one-bar figures (8ths, offbeats, gallops, gaps), not one figure switched on and off.
- **Triplet banks:** only steps 1, 2 and 3 of each beat. Never step 4, 8, 12 or 16 (that step lands almost on the next beat on the hardware).
- All different from each other and from the classic.

## Step 2: run the builder

Write the spec (below) and run:

```
python3 -B tools/lb_build.py my-bank.json my-bank.txt
python3 -B tools/check_laidback.py my-bank.txt --notes my-bank.txt.notes.json
```

The builder makes the build-up, picks and orders the middle, writes the B part and the donor tail. If you can't run code, do steps 3 to 6 by hand, the way they're written here.

## Step 3: the build-up (1 to the knob)

The classic's own hits arrive a few at a time. Nothing invented.

1. **The anchor first** (the snare's backbeat, the kick's downbeat).
2. Then the rest, in an order that suits the Timing:
   - **Shake and Push:** beats, then the + (it never swings), then the a, then the e. The swing arrives last, as the groove fills in.
   - **Trip:** beats, then the +, then the e, then the a. Trip makes the a rush toward the next beat, so the rushing notes come in last.
   - **Triplet banks:** beats, then the last triplet (step 3), then the middle one (step 2).
   - **Clave:** 1 and 3, then the clave points the Timing keeps on time (1, 4, 7, 9, 12, 15), then 2 and 4, then the rest.
   - Among steps of the same kind, the strong beats first: 1, then 3, then 2, then 4.
3. **Kick and Snare:** a hit goes into bars 1 and 3 together, then bars 2 and 4 together, before single bars. If there are more knob slots than additions, a pair splits and arrives one bar at a time (bar 1, then bar 3), so the build keeps its full length.
4. Spread the additions evenly over the slots. Every slot holds everything from the slot before, plus more.
5. A track with 3 or more hits on Hihat 2, Perc 1 or Perc 2 builds over at least 3 slots.
6. If a build-up step would equal the donor's classic (which sits at 21), take a neighbouring step instead.

## Step 4: the middle (after the knob to 16)

Only the bank's own variations, no new hits.

1. Drop any variation that lost the anchor, or that the build-up, the B part or the donor tail already uses.
2. If there are more left than slots, leave out the busiest ones (more than 15% livelier than the classic), then take an even spread from calm to lively.
3. Order them so **the energy never falls**. Within the same energy, step to the variation nearest the last one (fewest hits changed). It develops a little at a time.

## Step 5: the B part (17 to 20)

The same groove with **one big thing changed**. Everything else keeps the groove. The snare's anchor never leaves.

**Slot 20** is the classic with the move applied, plus a lift:
- one pickup on the snare late in bar 4 (the a of 4; on the triplet grid the last triplet of 4),
- one on the kick near the a of 3, never on the same step as the snare and never making a run of three,
- an open hat (Hihat 2) on the + of 4 if the kick and snare leave it free.
- A track the move leaves alone, or one whose 20 would repeat an earlier slot, is made from one of the bank's busiest variations instead, so 20 is full and new.

**Slots 17, 18, 19** climb inside 20. 17 is the groove with a hole in it, not a count-in: it keeps the anchor and the move's own new element, then the off-beat character hits. The plain time-keeping comes back last (the reverse of the build-up). Kick and Snare bring back bar 2 and the bar-4 pickups before bars 1 and 3. Each slot holds everything from the slot before, and the bank total rises every slot.

Rough sizes: the move's own track starts at about 60% of 20, kick and Hihat 1 at about 30%, the other percs can start empty. 17 ends up around a third of the classic's hits; 20 a little more than the classic.

**The moves:**

| Move | What changes | Styles |
|---|---|---|
| Half-speed hats | Hihat 1 drops a level (16ths to 8ths; 8ths to quarters plus a + of 4). The kick loses its 16th pushes and its kicks on 2 and 4. | Trip hop, Bristol, soul and rock ballads, bossa, drum and bass |
| Kick off the beat | The 1 in bars 2 and 4 waits until the +, a kick on 3 moves to the + of 3, kicks on 2 or 4 move to their +. Bars 1 and 3 keep their 1. | Hip-hop, boom bap, neo-soul, Dilla, funk, breaks, future garage |
| Threes over fours | One accent track (the plainest of Hihat 2, Perc 1, Perc 2) plays groups of three: 1, 4, 7, 10, 13. On the triplet grid: 1, 3, 6, 9, 11, 14. Hihat 1 settles to 8ths. | Shuffles, triplet ballads, UK garage, dubstep, wave, half-time DnB |
| One-drop to rockers | The kick takes beat 1 as well as beat 3. | Reggae, dub |
| Rockers to one-drop | The kick lets go of beat 1. | Rockers reggae |
| Open hat on the + | Hihat 2 opens on every +, Hihat 1 steps off those steps. | Afrobeat |
| Maqsum to sa'idi | The kick (dum) doubles onto the + of 2. | Middle Eastern |
| Kick tumbao | The kick plays 1, the + of 2 and 4. | Cumbia |
| Bell enters | One perc track becomes a bell: quarters plus the + of 2 and 4. | Son, montuno, baiao |

The idea behind the moves: a section change in these styles picks one thing to change (the hats, the kick's placement, a cross-rhythm, the feel) and leaves the rest. A delayed kick leans back; an anticipated one would push.

## Step 6: the donor (21 to 24)

- **21 is the donor's classic**, every track, on this bank's sounds. If it already sits somewhere in this track, add the donor's most common variation hit to make it new. On a triplet bank, move it onto the triplet grid (step 4 of each beat moves to step 3).
- **22** is the donor's own variation closest to its classic, at 80 to 100% of its hits: nearly as full, holding the beat.
- **23 and 24 sit back into the pocket.** 23 aims at about 93% of 22's hits and 24 at about 85%. First take out the busiest 16th ghosts (e and a), then the +, never the donor's anchor beats. If that runs out, slide a rushing 16th onto the 8th before it (the a onto the +, the e onto the beat): same hits, further back.
- The bank's total hits fall every slot from 21 to 24, and no track rises by more than one hit.

**Picking a donor:** the closest groove first, not the biggest contrast. Same artist or same style, then same Timing, then a close tempo. If the user's whole set should stand alone, keep every donor inside the set (as these eight do).

## Checks (before handing anything over)

`tools/check_laidback.py` checks these. By hand, if you can't run it:

1. File: 7,462 bytes, 149 lines, CRLF (see `file-format.md`).
2. Every track: 24 different patterns, slot 1 not empty.
3. Build-up: every slot holds the one before plus more, up to the classic at its knob.
4. Snare anchor present from the knob to 20.
5. 17 to 20: every track climbs, and the bank total rises every slot.
6. 21 to 24: the bank total falls every slot, no track rises by more than one hit.
7. Triplet banks: nothing on steps 4, 8, 12, 16.
8. At most one empty pattern per track, and only at 17.
9. Worth a listen (WARN, not wrong): middle energy dipping, 17 not thinner than the classic, bars 1 and 3 differing.

## The spec (what `lb_build.py` reads)

A JSON file. Steps are 1 to 16; each pattern is a list of bars, each bar a list of steps. Kick and Snare have 4 bars, the others 1.

**A full, working example is in `tools/example-spec.json`.** Copy it, change it, and run it:

```
python3 -B tools/lb_build.py tools/example-spec.json rainy.txt
python3 -B tools/check_laidback.py rainy.txt --notes rainy.txt.notes.json
```

It builds and passes (one allowed WARN: the snare keeps its backbeat at 17). Below is the same file with the variation lists cut short so it fits on the page. Each `[ ... ]` stands for the full list; a single variation looks just like the classic, e.g. Kick `[[1, 8, 11], [1, 7, 11, 15, 16], [1, 8, 11], [1, 7, 11, 15]]`.

```json
{
  "name": "Rainy boom bap",
  "bpm": 90,
  "timing": "Shake", "shuffle_row": 6, "feel": "Flam", "triplet": false,
  "move": "OFF",
  "donor": 2, "donor_reason": "Slow Funk Break: the break boom bap samples",
  "tracks": {
    "KICK":   {"knob": 8, "classic": [[1, 8, 11], [1, 7, 11, 15], [1, 8, 11], [1, 7, 11, 15]], "variations": [ ...16 variations... ]},
    "SNARE":  {"knob": 5, "classic": [[5, 13], [5, 13], [5, 13], [5, 13]], "variations": [ ...19 variations... ]},
    "HIHAT1": {"knob": 8, "classic": [[1, 3, 5, 7, 9, 11, 13, 15]], "variations": [ ...16 variations... ]},
    "HIHAT2": {"knob": 1, "classic": [[15]], "variations": [ ...23 variations... ]},
    "PERC1":  {"knob": 3, "classic": [[4, 12, 16]], "variations": [ ...21 variations... ]},
    "PERC2":  {"knob": 2, "classic": [[8, 16]], "variations": [ ...22 variations... ]}
  }
}
```

- `timing`: Trip, Shake, Push or Clave. `move`: HALF, OFF, HEMI, ROCK, DROP, OPEN, SAIDI, TUMBAO, BELL.
- `donor`: one of the eight banks here, 1 to 8.
- `variations`: exactly 24 minus the knob, per track.
- The builder can shorten a knob (never lengthen it): the notes file it writes holds the knobs it used. Tell the user those.

## What you hand back

Same as the main kit: the complete bank file (never a fragment), a short note per track (sound, knob, what each part of the arc does, which hits are sourced and which are OWN), the home setting, and the check results.
