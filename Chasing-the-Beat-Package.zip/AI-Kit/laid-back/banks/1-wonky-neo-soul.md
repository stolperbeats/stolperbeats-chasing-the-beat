# Laid-back bank 1: Wonky Neo-Soul

- **What it's for:** Neo-soul in J Dilla's manner: early kick pickups, uneven hats that skip the downbeat, a ride bell on the 1. For warm, slightly wonky soul and hip-hop under keys and a vocal.
- **Source:** SuperTime Ultra's Dilla neo-soul study (labelled ST). Background: Dan Charnas, *Dilla Time* (2022).
- **File:** `Card Files/LB1-wonky-neo-soul.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 80 BPM.
- **Home setting:** Trip, Shuffle row 3, Feel Flam, Linear off. Why: Dilla: the e lands early, the + and a late, drums dragged. Also try: Trip 6, Slop (the drunk version).
- **B part (17-20):** kick off the beat: the 1 in bars 2 and 4 is delayed to the +, the beat-3 kick moves to the + of 3, kicks on 2 or 4 move to their +.
- **Donor (21-24):** laid-back bank 5, Hip-hop Jazz. Why: Trip to Trip
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick (leads) | 10 | ST (both bars) |
| Snare | Snare | 9 | ST (2 and 4, bar-2 pickup); the + of 4 in bars 1 and 3 is OWN |
| Hihat 1 | Uneven hats | 10 | ST |
| Hihat 2 | RIDE BELL | 6 | ST (the bell on 1); rest OWN |
| Perc 1 | Ghost snare | 6 | ST (ghosts on the a of 2 and a of 3); rest OWN |
| Perc 2 | Cross-stick layer | 6 | OWN |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . x . . x . . . . x .
Bar 2   x . . x . . . . . x x . . . . .
Bar 3   x . . . . . x . . x . . . . x .
Bar 4   x . . x . . . . . x x . . . x .
```

**Snare** (knob 9):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . x .
Bar 2   . . . . x . . . . . . . x . . x
Bar 3   . . . . x . . . . . . . x . x .
Bar 4   . . . . x . . . . . . x x . x x
```

**Hihat 1** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x x x x x x x x x x x x x x x
```

**Hihat 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . . . x . x . x . . .
```

**Perc 1** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . x . x . x . x . . x .
```

**Perc 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . x x . . . . . . x x . x x
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 1 | 2 | 4 | 6 | 8 | 10 | 11 | 13 | 15 | 17 | 13 | 13 | 15 | 17 | 17 | 17 | 5 | 9 | 13 | 18 | 14 | 13 | 11 | 12 |
| Snare | 1 | 2 | 4 | 6 | 8 | 10 | 11 | 12 | 14 | 13 | 13 | 13 | 13 | 15 | 15 | 15 | 9 | 11 | 13 | 15 | 8 | 9 | 9 | 9 |
| Hihat 1 | 1 | 3 | 4 | 6 | 7 | 9 | 10 | 12 | 13 | 15 | 10 | 10 | 10 | 10 | 10 | 10 | 3 | 6 | 8 | 10 | 6 | 6 | 6 | 5 |
| Hihat 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 5 | 6 | 0 | 2 | 4 | 6 | 2 | 1 | 1 | 1 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 5 | 0 | 2 | 4 | 6 | 2 | 2 | 2 | 1 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 0 | 2 | 4 | 6 | 2 | 2 | 2 | 2 |
| **Bank** | 6 | 13 | 21 | 30 | 38 | 47 | 44 | 49 | 54 | 57 | 48 | 49 | 52 | 57 | 57 | 58 | 17 | 32 | 46 | 61 | 34 | 33 | 31 | 30 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
