# Laid-back bank 6: Bristol Halftime

- **What it's for:** Dark half-time trip-hop: one accent per bar on beat 3, a sparse kick, 8th hats and a shaker. For brooding, slow-burning tracks that build from a bass line.
- **Source:** Wragg, *The High Art of Trip Hop* (PhD thesis, Waikato, 2018) (THESIS): the half-time feel, the two-bar pattern and the beat-3 accent, cross-stick first and later snare. Everything else is the builder's own programming in that frame. The record: Massive Attack, "Angel" (1998).
- **File:** `Card Files/LB6-bristol-halftime.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 106 BPM.
- **Home setting:** Shake, Shuffle row 4, Feel Flam, Linear on. Why: half-time with a 16th shaker: 60% swing on the shaker. Also try: Shake 2.
- **B part (17-20):** half-speed hats: Hat 1 drops one level (16ths to 8ths, or 8ths to quarters) and the kick loses its 16th pushes; the backbeat stays.
- **Donor (21-24):** laid-back bank 7, Wave. Why: half-time to half-time; Push-built under Shake knobs
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick | 4 | OWN |
| Snare | Cross-stick, later snare (beat 3) | 2 | THESIS (the beat-3 accent) |
| Hihat 1 | 8th hats (own) | 8 | OWN |
| Hihat 2 | Open hat (own) | 1 | OWN |
| Perc 1 | Ghost rim (own) | 2 | OWN |
| Perc 2 | Shaker 16ths (own) | 10 | OWN |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 4):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . . . . . . . . .
Bar 2   x . . . . . . . . . x . . . . .
Bar 3   x . . . . . . . . . . . . . . .
Bar 4   x . . . . . . . . . x . . . . x
```

**Snare** (knob 2):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . . . . . x . . . . . . .
Bar 2   . . . . . . . . x . . . . . . .
Bar 3   . . . . . . . . x . . . . . . .
Bar 4   . . . . . . . . x . . . . . . .
```

**Hihat 1** (knob 8):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2** (knob 1):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . . . . . x .
```

**Perc 1** (knob 2):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . . x . . . x
```

**Perc 2** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x x x x x x x x x x x x x x x
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 7 | 9 | 9 | 9 | 9 | 9 | 9 | 9 | 9 | 9 | 9 | 9 | 9 | 3 | 4 | 6 | 9 | 11 | 11 | 10 | 9 |
| Snare | 2 | 4 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 5 | 6 | 8 | 9 | 13 | 13 | 12 | 11 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 7 | 2 | 3 | 4 | 5 | 7 | 6 | 5 | 4 |
| Hihat 2 | 1 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 3 | 4 | 4 | 4 | 4 | 4 | 0 | 1 | 2 | 3 | 2 | 2 | 1 | 1 |
| Perc 1 | 1 | 2 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 0 | 1 | 3 | 4 | 2 | 2 | 2 | 1 |
| Perc 2 | 1 | 3 | 4 | 6 | 8 | 9 | 11 | 13 | 14 | 16 | 11 | 11 | 11 | 11 | 12 | 12 | 0 | 5 | 9 | 13 | 3 | 3 | 3 | 3 |
| **Bank** | 8 | 17 | 26 | 30 | 36 | 38 | 41 | 44 | 43 | 45 | 39 | 41 | 41 | 41 | 42 | 43 | 10 | 20 | 32 | 43 | 38 | 37 | 33 | 29 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
