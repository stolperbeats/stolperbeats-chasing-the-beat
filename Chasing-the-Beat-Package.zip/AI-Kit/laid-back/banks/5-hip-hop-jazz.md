# Laid-back bank 5: Hip-hop Jazz

- **What it's for:** Jazz-rap: a ride carrying a swung jazz pattern, pedal hat on 2 and 4, a nodding backbeat and a few ghosts. Patch a real ride on Hihat 1.
- **Source:** SuperTime Ultra's hip-hop jazz study (ST), the whole two-bar grid.
- **File:** `Card Files/LB5-hip-hop-jazz.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 90 BPM.
- **Home setting:** Trip, Shuffle row 4, Feel Tight, Linear off. Why: jazz ride: Trip row 4 puts the + at 60% of the beat, the 60% swing of the source. Also try: Trip 5 for triplet swing.
- **B part (17-20):** kick off the beat: the 1 in bars 2 and 4 is delayed to the +, the beat-3 kick moves to the + of 3, kicks on 2 or 4 move to their +.
- **Donor (21-24):** laid-back bank 4, Drunk Swing. Why: Trip to Trip, reciprocal
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick | 7 | ST |
| Snare | Snare | 4 | ST |
| Hihat 1 | RIDE | 6 | ST (ride) |
| Hihat 2 | Pedal hat on 2 and 4 | 2 | ST (pedal hat) |
| Perc 1 | Ghost snare | 2 | ST (bar-1 ghosts) |
| Perc 2 | Ghost snare, bar-2 lane | 2 | ST (bar-2 ghosts) |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 7):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . x . . . . . . x . . . . .
Bar 2   x . . . . . . . x . . x . . x .
Bar 3   x . . x . . . . . . x . . . . .
Bar 4   x . . . . . . . x . . x . . x .
```

**Snare** (knob 4):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . x . x . . . x . x .
```

**Hihat 2** (knob 2):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . x . . . . . . . x . . .
```

**Perc 1** (knob 2):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . x . . . . . . . x
```

**Perc 2** (knob 2):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . x . . . . . . . . . x . .
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 12 | 12 | 14 | 14 | 14 | 14 | 14 | 14 | 16 | 6 | 8 | 10 | 14 | 19 | 18 | 18 | 16 |
| Snare | 2 | 4 | 6 | 8 | 12 | 13 | 13 | 13 | 13 | 13 | 12 | 13 | 13 | 13 | 13 | 13 | 9 | 11 | 13 | 14 | 15 | 15 | 14 | 13 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 6 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 7 | 2 | 4 | 6 | 7 | 14 | 14 | 13 | 12 |
| Hihat 2 | 1 | 2 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 0 | 1 | 3 | 4 | 6 | 6 | 6 | 5 |
| Perc 1 | 1 | 2 | 2 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 0 | 1 | 3 | 4 | 6 | 6 | 6 | 5 |
| Perc 2 | 1 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 0 | 1 | 3 | 4 | 6 | 6 | 6 | 5 |
| **Bank** | 8 | 16 | 22 | 29 | 38 | 42 | 44 | 43 | 44 | 46 | 45 | 46 | 46 | 46 | 46 | 48 | 17 | 26 | 38 | 47 | 66 | 65 | 63 | 56 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
