# Laid-back bank 2: Slow Funk Break

- **What it's for:** The funk break slowed to hip-hop tempo: one-handed 16th hats that open on the e of 2 and 4, a busy kick, a hard backbeat, ghosts in the gaps. Slowed down, it's the break most people know from under a rap.
- **Source:** Kick from *The Greatest Drum Beats* p. 59, read by eye (BOOK). Hats, opens and ghosts from SuperTime Ultra's study and Ethan Hein's step-by-step build of the beat (ST). The record: James Brown, "Funky Drummer" (1970), Clyde Stubblefield on drums.
- **File:** `Card Files/LB2-slow-funk-break.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 85 BPM.
- **Home setting:** Shake, Shuffle row 4, Feel Tight, Linear off. Why: Clyde's 16ths: 60% swing. Also try: Shake 3.
- **B part (17-20):** kick off the beat: the 1 in bars 2 and 4 is delayed to the +, the beat-3 kick moves to the + of 3, kicks on 2 or 4 move to their +.
- **Donor (21-24):** laid-back bank 3, Slow Breakbeat. Why: break to break, same tempo
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick | 8 | BOOK |
| Snare | Snare | 9 | ST (backbeat); the full hits on some ghost spots are OWN |
| Hihat 1 | One-handed 16th hats | 10 | ST |
| Hihat 2 | Open hats | 6 | ST (opens on the e of 2 and 4); rest OWN |
| Perc 1 | Ghost snares | 6 | ST (ghosts); rest OWN |
| Perc 2 | Second ghost / rim | 6 | OWN |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 8):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . x . . . . . . . x . . x . .
Bar 2   x . x . . . . . . . x . . x . .
Bar 3   x . x . . . . . . . x . . x . .
Bar 4   x . x . . . . . . . x . . x . .
```

**Snare** (knob 9):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . x . . . . x . . .
Bar 2   . . . . x . . . . x . . x . . x
Bar 3   . . . . x . . x . . . . x . . .
Bar 4   . . . . x . . x . x . . x . . x
```

**Hihat 1** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x x x x . x x x x x x x . x x
```

**Hihat 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . . . x . x . x . . . x . x
```

**Perc 1** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . x . . . x . x . x . . . x
```

**Perc 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . x . x . . . . . x . x . x
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 13 | 13 | 14 | 15 | 15 | 15 | 15 | 17 | 6 | 8 | 12 | 15 | 14 | 14 | 13 | 12 |
| Snare | 1 | 2 | 4 | 6 | 8 | 10 | 11 | 13 | 15 | 13 | 13 | 13 | 13 | 13 | 13 | 15 | 9 | 11 | 13 | 16 | 17 | 16 | 15 | 14 |
| Hihat 1 | 1 | 2 | 4 | 5 | 7 | 9 | 10 | 11 | 13 | 14 | 11 | 11 | 11 | 11 | 11 | 11 | 4 | 7 | 10 | 12 | 8 | 8 | 6 | 5 |
| Hihat 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 5 | 0 | 2 | 4 | 6 | 6 | 6 | 5 | 4 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 0 | 2 | 4 | 6 | 7 | 6 | 6 | 5 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 0 | 2 | 4 | 5 | 7 | 6 | 6 | 5 |
| **Bank** | 7 | 14 | 23 | 31 | 40 | 49 | 47 | 52 | 53 | 52 | 50 | 51 | 52 | 52 | 53 | 58 | 19 | 32 | 47 | 60 | 59 | 56 | 51 | 45 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
