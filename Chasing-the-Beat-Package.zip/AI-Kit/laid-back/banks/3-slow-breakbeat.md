# Laid-back bank 3: Slow Breakbeat

- **What it's for:** The Amen break slowed and left un-chopped: two bars of funk, then a turnaround that delays the snare and drops the downbeat. At this speed it's a laid-back funk groove, not a jungle break.
- **Source:** Kick and snare, all four bars, from *The Greatest Drum Beats* p. 10, read by eye (BOOK). Ride from SuperTime Ultra's study (ST). The record: The Winstons, "Amen, Brother" (1969), Gregory Coleman on drums.
- **File:** `Card Files/LB3-slow-breakbeat.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 85 BPM.
- **Home setting:** Shake, Shuffle row 2, Feel Tight, Linear off. Why: the Amen is nearly straight: 57% swing on the 16ths. Also try: Shake 4, Flam.
- **B part (17-20):** kick off the beat: the 1 in bars 2 and 4 is delayed to the +, the beat-3 kick moves to the + of 3, kicks on 2 or 4 move to their +.
- **Donor (21-24):** laid-back bank 2, Slow Funk Break. Why: break to break, same tempo; the moved beat 4 stays in 1-20
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick | 8 | BOOK (all 4 bars) |
| Snare | Snare | 10 | BOOK (all 4 bars) |
| Hihat 1 | RIDE (timekeeper) | 8 | ST (ride) |
| Hihat 2 | Crash / open accent | 6 | OWN (the source crash only lives in bar 4, which a one-bar track cannot hold) |
| Perc 1 | Ghost snares | 6 | ST (ghost on the a of 4); rest OWN |
| Perc 2 | Second ghost layer | 6 | OWN |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 8):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . x . . . . . . . x x . . . .
Bar 2   x . x . . . . . . . x x . . . .
Bar 3   x . x . . . . . . . x . . . . .
Bar 4   . . x x . . . . . . x . . . . .
```

**Snare** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . x . x . . x . . .
Bar 2   . . . . x . . x . x . . x . . .
Bar 3   . . . . x . . x . x . . . . x .
Bar 4   . x . . x . . x . x . . . . x .
```

**Hihat 1** (knob 8):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . x . x . . . x . x . x .
```

**Perc 1** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . x . . . x . x . x . . . x
```

**Perc 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . x . x . . . . . x . x . x
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 7 | 11 | 12 | 13 | 14 | 12 | 12 | 13 | 14 | 14 | 15 | 15 | 15 | 6 | 8 | 10 | 14 | 16 | 15 | 14 | 13 |
| Snare | 2 | 4 | 5 | 6 | 7 | 10 | 12 | 13 | 15 | 17 | 13 | 14 | 14 | 15 | 16 | 17 | 5 | 9 | 13 | 18 | 15 | 15 | 14 | 13 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 6 | 7 | 7 | 7 | 7 | 7 | 7 | 8 | 2 | 4 | 6 | 8 | 14 | 12 | 11 | 10 |
| Hihat 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 6 | 0 | 2 | 4 | 6 | 6 | 5 | 5 | 4 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 5 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 6 | 0 | 2 | 4 | 6 | 7 | 6 | 6 | 5 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 0 | 2 | 4 | 5 | 7 | 6 | 6 | 5 |
| **Bank** | 8 | 16 | 23 | 29 | 38 | 46 | 44 | 48 | 47 | 50 | 47 | 50 | 50 | 53 | 54 | 57 | 13 | 27 | 41 | 57 | 65 | 59 | 56 | 50 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
