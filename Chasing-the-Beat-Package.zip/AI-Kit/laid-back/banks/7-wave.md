# Laid-back bank 7: Wave

- **What it's for:** Wave at 140, felt at 70: a half-time snare plus off-beat snares that bounce, straight 8th hats, sparse metallic taps and toms. For atmospheric music where silence hits as hard as the snare.
- **Source:** A proposed grid from the project's own style research (ARCHIVE), written in the style, not transcribed from a record. The style: wave, 120-160 BPM, sweet spot 140, half-time feel.
- **File:** `Card Files/LB7-wave.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 140 BPM.
- **Home setting:** Push, Shuffle row 3, Feel Tight, Linear off. Why: 4/4 half-time: Push gives every downbeat a little room. Also try: Push 2.
- **B part (17-20):** threes over fours: one accent track plays groups of three (on the triplet grid: two against three), Hat 1 settles to 8ths.
- **Donor (21-24):** laid-back bank 8, Dubstep Half-Step. Why: same Push, same tempo
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick | 6 | ARCHIVE (proposed) |
| Snare | Snare | 7 | ARCHIVE (proposed) |
| Hihat 1 | 8th hats | 8 | ARCHIVE (proposed) |
| Hihat 2 | Open hat | 2 | ARCHIVE (proposed) |
| Perc 1 | Metallic tap / low tom | 2 | ARCHIVE (proposed) |
| Perc 2 | Short end-of-bar runs (own) | 3 | OWN |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . . . . . x . x .
Bar 2   x . . . . . . . . . x . . . . .
Bar 3   x . . . . . . . . . . . x . x .
Bar 4   x . . . . . . . . . x . . . x .
```

**Snare** (knob 7):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . x . . . . . x . . . . . x .
Bar 2   . . x . . . . . x . . . . . x .
Bar 3   . . x . . . . . x . . . . . x .
Bar 4   . . x . . . . . x . . x . . x .
```

**Hihat 1** (knob 8):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2** (knob 2):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . x . . . . . . . x .
```

**Perc 1** (knob 2):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . x . . x . .
```

**Perc 2** (knob 3):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . . . . x x x
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 11 | 9 | 9 | 9 | 11 | 11 | 11 | 11 | 11 | 11 | 11 | 3 | 7 | 9 | 12 | 11 | 11 | 10 | 9 |
| Snare | 2 | 4 | 6 | 8 | 10 | 12 | 13 | 11 | 13 | 13 | 13 | 13 | 13 | 13 | 13 | 15 | 7 | 9 | 11 | 14 | 10 | 9 | 8 | 8 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 5 | 5 | 5 | 5 | 5 | 5 | 5 | 6 | 2 | 3 | 5 | 6 | 10 | 9 | 8 | 7 |
| Hihat 2 | 1 | 2 | 1 | 2 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 2 | 3 | 4 | 5 | 6 | 6 | 6 | 5 |
| Perc 1 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 0 | 1 | 2 | 3 | 6 | 6 | 6 | 5 |
| Perc 2 | 1 | 2 | 3 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 3 | 4 | 0 | 1 | 3 | 4 | 6 | 5 | 5 | 4 |
| **Bank** | 8 | 16 | 21 | 26 | 33 | 37 | 38 | 37 | 36 | 38 | 38 | 38 | 38 | 38 | 39 | 43 | 14 | 24 | 34 | 44 | 49 | 46 | 43 | 38 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
