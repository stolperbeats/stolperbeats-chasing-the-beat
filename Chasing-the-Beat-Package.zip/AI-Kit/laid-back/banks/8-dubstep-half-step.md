# Laid-back bank 8: Dubstep Half-Step

- **What it's for:** Dubstep half-step at 140, felt at 70: kick on 1, snare on 3, lightly shuffled 8th hats with 16th pickups, in a mostly empty bar. The space around the snare is the groove.
- **Source:** SuperTime Ultra's dubstep half-step study (ST). The scene it describes: mid-2000s South London (Big Apple Records, FWD>>, DMZ).
- **File:** `Card Files/LB8-dubstep-half-step.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 140 BPM.
- **Home setting:** Push, Shuffle row 2, Feel Tight, Linear off. Why: half-step: Push leaves the downbeats and leans everything between them. Also try: Shake 6.
- **B part (17-20):** threes over fours: one accent track plays groups of three (on the triplet grid: two against three), Hat 1 settles to 8ths.
- **Donor (21-24):** laid-back bank 7, Wave. Why: same Push, same tempo
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick | 8 | ST (1, plus the study's listed + of 3) |
| Snare | Snare (beat 3) | 7 | ST (beat 3); the pickup on the a of 4 in bars 1 and 3 is OWN |
| Hihat 1 | Shuffled 8ths | 10 | ST |
| Hihat 2 | Open hat | 6 | OWN |
| Perc 1 | Rim / perc | 6 | OWN |
| Perc 2 | Sticks / click | 6 | OWN |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 8):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . . . x . . . . .
Bar 2   x . . . . . . . . . x . . . x .
Bar 3   x . . . . . . . . . x . . . . .
Bar 4   x . . . . . . . . . x . . . x x
```

**Snare** (knob 7):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . . . . . x . . . . . . x
Bar 2   . . . . . . . . x . . . . . x .
Bar 3   . . . . . . . . x . . . . . . x
Bar 4   . . . . . . . . x . . . . x x x
```

**Hihat 1** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x x x . x . x . x x
```

**Hihat 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . x x . . x . . . x x
```

**Perc 1** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . x . . x . . . . x . x x x
```

**Perc 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . x . x . . . x . x . x .
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 1 | 2 | 3 | 4 | 6 | 8 | 10 | 11 | 9 | 11 | 11 | 11 | 11 | 11 | 11 | 13 | 4 | 6 | 10 | 12 | 11 | 11 | 10 | 9 |
| Snare | 1 | 2 | 4 | 6 | 8 | 9 | 10 | 9 | 9 | 9 | 9 | 11 | 11 | 11 | 11 | 11 | 5 | 7 | 9 | 11 | 13 | 13 | 12 | 11 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 8 | 8 | 8 | 8 | 8 | 9 | 2 | 3 | 5 | 6 | 8 | 6 | 5 | 4 |
| Hihat 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 2 | 3 | 4 | 5 | 2 | 2 | 1 | 1 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 0 | 2 | 4 | 6 | 2 | 2 | 2 | 1 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 0 | 2 | 4 | 5 | 3 | 3 | 3 | 3 |
| **Bank** | 6 | 12 | 19 | 26 | 34 | 41 | 39 | 40 | 39 | 43 | 41 | 43 | 44 | 44 | 45 | 49 | 13 | 23 | 36 | 45 | 39 | 37 | 33 | 29 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
