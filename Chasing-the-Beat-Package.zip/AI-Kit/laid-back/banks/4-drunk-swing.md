# Laid-back bank 4: Drunk Swing

- **What it's for:** Almost boom bap, with the whole identity in the timing: Trip row 6 and Slop stagger the hats and ghosts while the backbeat sits back. Head-nodding hip-hop that feels about to fall over and never does.
- **Source:** SuperTime Ultra's Dilla drunk-swing study (ST); BAP Studio's hip-hop pattern notes. Background: Charnas, *Dilla Time*.
- **File:** `Card Files/LB4-drunk-swing.txt`. Rename it `PatternBankNNN.txt` for the bank slot it goes in (`PatternBank000.txt` = bank 1).
- **Tempo:** 88 BPM.
- **Home setting:** Trip, Shuffle row 6, Feel Slop, Linear off. Why: drunk: e early, + and a late; Slop keeps the hats with the drums. Also try: Trip 7, Slop.
- **B part (17-20):** kick off the beat: the 1 in bars 2 and 4 is delayed to the +, the beat-3 kick moves to the + of 3, kicks on 2 or 4 move to their +.
- **Donor (21-24):** laid-back bank 5, Hip-hop Jazz. Why: Trip to Trip, reciprocal
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic at knob | Classic from |
|---|---|---|---|
| Kick | Kick | 10 | ST (both bars) |
| Snare | Snare | 9 | ST (2 and 4); the pickups are OWN |
| Hihat 1 | Drunk 16ths | 10 | ST |
| Hihat 2 | Open hat | 6 | OWN |
| Perc 1 | Ghost snare | 6 | ST (four ghosts); rest OWN |
| Perc 2 | Rim layer | 6 | OWN |

## The classics, drawn

`x` = hit, `.` = rest. Steps 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . x . . . . x . x . . . . .
Bar 2   x . . x . . . x . . x x . . . .
Bar 3   x . . x . . . . x . x . . . . .
Bar 4   x . . x . . . x . . x x . . x .
```

**Snare** (knob 9):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . x
Bar 2   . . . . x . . x . . . . x . . x
Bar 3   . . . . x . . . . . . . x . . x
Bar 4   . . . . x . . x . . . . x . x x
```

**Hihat 1** (knob 10):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x x x x . x x x x x x x . x x
```

**Hihat 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . x x . . x . . . x x
```

**Perc 1** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . x . . x . x . . x x
```

**Perc 2** (knob 6):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . x x . . x . . . x x . . x
```

## Hits per slot (1 to 24)

| Track | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 11 | 13 | 15 | 17 | 19 | 17 | 17 | 19 | 19 | 19 | 19 | 6 | 9 | 13 | 17 | 14 | 13 | 11 | 12 |
| Snare | 1 | 2 | 4 | 6 | 7 | 9 | 11 | 13 | 15 | 13 | 13 | 15 | 15 | 15 | 15 | 15 | 11 | 13 | 15 | 16 | 8 | 9 | 9 | 9 |
| Hihat 1 | 1 | 2 | 4 | 5 | 7 | 8 | 10 | 11 | 13 | 14 | 11 | 11 | 11 | 12 | 12 | 12 | 4 | 8 | 11 | 14 | 6 | 6 | 6 | 5 |
| Hihat 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 5 | 5 | 5 | 5 | 6 | 6 | 6 | 0 | 2 | 4 | 6 | 2 | 1 | 1 | 1 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 5 | 4 | 5 | 5 | 5 | 5 | 6 | 6 | 0 | 3 | 4 | 6 | 2 | 2 | 2 | 1 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 6 | 4 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 6 | 0 | 1 | 4 | 6 | 2 | 2 | 2 | 2 |
| **Bank** | 7 | 14 | 23 | 31 | 39 | 46 | 46 | 51 | 58 | 59 | 55 | 57 | 60 | 62 | 63 | 64 | 21 | 36 | 51 | 65 | 34 | 33 | 31 | 30 |

Read it as the slow arc: climbing to each classic, a gentle rise to 16, the dip at 17 and climb to 20, then the donor easing off from 21.
