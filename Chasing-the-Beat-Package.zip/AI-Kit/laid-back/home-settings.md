# Home settings for laid-back banks

Read the main kit's `timing.md` first: it has the tables. This page is the lean-back side of the same hardware, and how B. chose a home setting for each slow bank. Every number here comes from the firmware 163 timing tables (read out of the firmware by the unofficial Stolperbeats Visualiser v2; its Trip rows match the Making Sound Machines manual's chart exactly).

## The four Timings, for sitting back

- **Shake swings only the e and the a.** The + never moves, so straight 8th hats sound the same on every Shake row; only 16ths swing. Swing by row: 2 = 57%, 3 = 61%, 4 = 60%, 5 = 58%, 6 = 62.5%, 7 = 67% (full triplet). The rows aren't in order of strength: 5 is lighter than 3 and 4.
- **Trip moves the 8ths.** Row 2 pushes everything after the beat late, so the a rushes into the next beat. Rows 3 to 7 pull the e toward the beat and push the + and a late. Rows 5 and 7 put the + exactly on the last triplet. This is the Dilla clock: kicks, snares and hats on different clocks.
- **Push delays the e, + and a of every beat by the same small amount** (2.8% to 6.3% of a beat) and leaves the beats on time. Every downbeat gets room and the in-between notes sit back. Good for half-time electronic music, where swing would sound wrong.
- **Clave works on the half bar.** Steps 1, 4 and 7 (the 3-3-2) stay on time; everything else drifts late, including 2 and 4. A backbeat sits back in Clave.

Beats 1 and 3 are always on time. A Timing or Shuffle change waits for the next beat.

## The Feels: this is where leaning back lives

- **Flam** is the module's lean-back. Kick and snare fire one tick late, behind the hats. A tick is 1/16 to 1/36 of a beat depending on the row. At 60 BPM that's 62 ms on row 1, 50 on row 4, 42 on row 5, 36 on row 2, 31 on row 6, 28 on rows 3 and 7. Divide by tempo/60 for other tempos (at 90 BPM, two thirds of those).
- **Slop** is Flam where the hats that land with the kick or snare drag too, so they stay glued to the drums. Every other hat stays on time. The drunk one.
- **Tight**: all on the grid. Right when the swing or the Timing already does the leaning (breaks, dub, half-step).
- **Rolls** retriggers Hihat 2 until the next step: a flutter on a short step, a buzz on a long one. Use it sparingly here; it's a lean-forward trick.

## Linear

Snare silences kick, hats and percs on the same step; kick silences hats and percs; Hihat 2 silences Hihat 1; Perc 2 silences Perc 1. It's a performance switch, not part of a bank. "On works" means it only lifts doubles under the drums. "Off" means it would cut a kick (one-drop and clave banks put kick and snare together), the open hat, or most of a perc part.

## Choosing a home setting

Pick by what the groove's feel actually is, then let Flam or Slop do the leaning:

| The groove | Home setting | Examples in this folder |
|---|---|---|
| Golden-age MPC swing on 16ths | Shake 6, Flam | (none of the eight) |
| Dilla, neo-soul, drunk swing | Trip 3 to 6, Flam or Slop | Wonky Neo-Soul (Trip 3, Flam), Drunk Swing (Trip 6, Slop) |
| Jazz rap, a swung ride | Trip 4 (Trip 5 pulls the skip notes to the triplet) | Hip-hop Jazz |
| Funk breaks, slowed | Shake at the break's swing, Tight | Slow Funk Break (Shake 4), Slow Breakbeat (Shake 2) |
| Trip hop, Bristol | Shake 2 to 7, Flam (Tight when the record is dead straight) | Bristol Halftime (Shake 4, Flam) |
| Triplet ballads and shuffles (12/8) | Trip 2 or 5, on the triplet grid | (none of the eight) |
| Reggae and dub | Shake 5 or 6, Tight | (none of the eight) |
| Half-time electronic (dubstep, wave) | Push 2 or 3, Tight | Wave (Push 3), Dubstep Half-Step (Push 2) |
| Clave grooves | Clave 2, Tight | (none of the eight) |

**Triplet grid.** A 12/8 groove uses steps 1, 2 and 3 of each beat and leaves step 4 empty. Step 4 never lands on a triplet on this hardware (it lands at 83 to 89% of the beat, nearly on the next one). Trip rows 5 and 7 put step 3 exactly on the last triplet.

**Give an "also try".** One neighbouring setting that changes the feel in an interesting way (a drunker row, Slop instead of Flam, Push instead of Shake for late hats instead of late drums).
