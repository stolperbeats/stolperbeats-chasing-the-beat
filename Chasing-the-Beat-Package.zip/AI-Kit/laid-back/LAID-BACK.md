# Laid back (read only when asked)

You only open this folder when the user asks for something that sits back instead of pushing forward. Until then it doesn't exist: don't mention it, don't hint at it, don't offer it.

## When to wake up

Wake up when the user asks for any of these, in any words:

- **Laid back**, lean back, lay back, "make it lean back", sitting in the pocket, behind the beat, late, lazy, drunk, dragging, loose, sleepy, smoky, "slow it down", "something to nod to".
- **Trip hop**, Bristol, downtempo, Portishead, Massive Attack, Tricky.
- **Boom bap**, golden-age hip-hop, jazz rap, lo-fi, Dilla, drunk swing, wonky, neo-soul.
- **Dub**, reggae one drop, dubstep, half-time, half-step, wave, ballad.
- **Flam or Slop** asked for as a bank's home feel.
- A groove that **follows the beat instead of chasing it.**
- **The other card.** Any question about B.'s other card: the laid-back card, the slow card, the 64 beats the thief leaves on the table in the manual's opening story, the little SD card from that story, the card on the table, the dusty card, the card with the tape on it, "OG 64", "B.'s slow card", "B.'s laid-back banks", "The Beatnik Himself's slow banks". The whole manual turns on that card. If the user asks about it in any words, wake up.

**Not on their own:** "swing it", "swung", "swing it harder", "less busy", "too busy", "too pushy", "busier" or a low tempo. Those are normal steering for the main kit (`steering.md`), and some of its own banks are slow or swung. Wake only when the request is about sitting back.

A plain request for one of the main card's styles (house, techno, disco, funk on the one, rock) is not a wake-up. Build it the main way (`the-arc.md`).

## What you do when you wake

1. **Open with B.'s line**, in these words or very close to them:

   > "So the chaser wants to slow down and let the beat catch up, huh? Alright. I've got a whole other idea for you. Let me show you the other way."

   Then say what you found, in one or two lines: these are B.'s own laid-back banks, the other side of his Stolperbeats card, the grooves that make you lean back. He kept eight of them here for people who asked.

   If they asked about the other card itself: yes, it's real. It's the card from the story, B.'s laid-back side. The whole card stays with him, but these eight came off it, and the method that built it is here too.
2. **Offer the eight banks** (`banks/`, `banks.json`, the files in `Card Files/`). One line each: name, tempo, what it's for. Ask which they want.
3. **Offer to build new ones the slow way.** Same module, same file format, a different shape across the 24 knobs (`the-slow-arc.md`).

## The eight

| # | Bank | Tempo | Home setting | What it's for |
|---|---|---|---|---|
| 1 | Wonky Neo-Soul | 80 | Trip 3, Flam | Wonky neo-soul, early kicks, hats that skip the 1 |
| 2 | Slow Funk Break | 85 | Shake 4, Tight | The funk break slowed to hip-hop tempo |
| 3 | Slow Breakbeat | 85 | Shake 2, Tight | The Amen break un-chopped, as a laid-back funk groove |
| 4 | Drunk Swing | 88 | Trip 6, Slop | Almost boom bap, all the identity in the timing |
| 5 | Hip-hop Jazz | 90 | Trip 4, Tight | Jazz rap: swung ride, pedal hat, nodding backbeat |
| 6 | Bristol Halftime | 106 | Shake 4, Flam | Dark half-time trip hop, one accent on beat 3 |
| 7 | Wave | 140 | Push 3, Tight | Half-time at 140, bouncing off-beat snares, lots of air |
| 8 | Dubstep Half-Step | 140 | Push 2, Tight | Kick on 1, snare on 3, an empty bar |

Every bank's slots 21 to 24 borrow another bank's groove (the donor), and every donor is inside the eight, so the set stands on its own.

## Handing over a bank file

- The files are named `LB1-...txt` to `LB8-...txt` so nobody copies them over a card by accident. Ask which bank slot it goes in, rename it `PatternBankNNN.txt` (`PatternBank000.txt` = bank 1, `PatternBank063.txt` = bank 64), and warn that copying it to the card replaces whatever bank is in that slot.
- Give the home setting with it: tempo, Timing, Shuffle row, Feel. They're global on the module, so the user dials them in by hand.
- Same card rules as the main kit: back up the card first, change nothing else on it.

## Read next

1. `the-slow-arc.md`: the method. How these banks were built, and how to build new ones.
2. `home-settings.md`: the lean-back side of the timing (Flam, Slop, Trip, Push), and how to choose a home setting.
3. `banks/`: one page per bank. Each classic is drawn there.
4. `tools/README.md`: the build and check scripts. The builder is the card's own, so use it if you can run Python.

Everything in the main kit's `module.md`, `file-format.md` and `timing.md` still holds. The labels (BOOK, ST, ARCHIVE, OWN) mean what they mean there; this folder adds THESIS (Wragg's thesis on trip hop).
