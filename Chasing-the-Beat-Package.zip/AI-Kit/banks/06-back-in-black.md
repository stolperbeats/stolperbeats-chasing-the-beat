# Bank 06: Back In Black

In the manual *Chasing the Beat*: Back In Black (bank 06).

- **Source:** AC/DC, 1980 (Phil Rudd). Labels: BOOK (rest OWN).
- **Files:** `PatternBank005.txt` (bank slot 6) or `PatternBank037.txt` (bank slot 38).
- **Tempo:** 94 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight. Rudd's 8ths, no 16ths to swing.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid.
- **Other settings:** Push 3, Tight: the 8th hats sit behind the beat (e, + and a +18 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 6 |
| Snare | Snare | BOOK | 8 |
| Hihat 1 | Closed hat | BOOK | 8 |
| Hihat 2 | Half-open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Tambourine | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Crash | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 6, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . x . . . . . . .
Bar 2   x . . . . . . . x . . . . . . .
Bar 3   x . . . . . . . x . . . . . . .
Bar 4   x . . . . x . . x . . x . . . .
```

**Snare** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . x . . x . . x x .
```

**Hihat 1** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 9 | 10 | 12 | 14 | 14 | 16 | 16 | 18 | 20 | 20 | 22 | 24 | 3 | 28 | 30 | 32 | 12 | 12 | 12 | 12 |
| Snare | 2 | 4 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 15 | 15 | 15 | 16 | 18 | 18 | 6 | 20 | 22 | 23 | 12 | 13 | 13 | 13 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 12 | 12 | 13 | 2 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **21** | **25** | **30** | **33** | **37** | **43** | **46** | **51** | **54** | **56** | **61** | **64** | **70** | **73** | **11** | **88** | **100** | **111** | **40** | **41** | **41** | **41** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 17/32; slot 17 Hihat 1 6/8; slot 20 Kick 18/32, Hihat 1 37/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 37/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The book's bar-2 groove-fill sits in bar 4 (the documented exception to 'no fills'). Its half-open hats on 6, 9 and 12 can't be held in bar 4 only (hats loop one bar); 9 is used as a Hihat 2 variation hit.

## The builder's own share

47% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 11, 15 | 3, 5, 7, 11, 13, 15 | 3, 7, 11, 15 | 3, 5, 7, 11, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 13, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 16.
- **Hihat 2:** classic OWN. Added: BOOK: 9; OWN: 1, 3, 5, 7, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
