# Bank 03: Killing In The Name

In the manual *Chasing the Beat*: Killing In The Name (bank 03).

- **Source:** Rage Against The Machine, 1992 (Brad Wilk). Labels: BOOK (rest OWN).
- **Files:** `PatternBank002.txt` (bank slot 3) or `PatternBank034.txt` (bank slot 35).
- **Tempo:** 89 BPM.
- **Home setting:** Shake, Shuffle row 2, Feel Tight, Linear off. Why: Shake 2: the book says the whole song carries a light 16th swing. The verse and main beat are 8ths, so Shake leaves them exactly on the grid; only the 16th hits swing.
- **Change inside the bank:** Shake 4, Tight from slot 18. Why: Shake 4 (60%): the book says the 2:01 section is where the swing becomes obvious, with the e of 1 pushed toward the +. Shake moves exactly those kicks.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Hihat 2: all on the grid.
- **Other settings:** Push 2, Tight: the 8th hats sit back a little (e, + and a +24 ms). Shake 4, Tight: part of the design: turn to it at slot 18 for the 2:01 climb (e and a +34 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 9 |
| Snare | Snare | BOOK | 9 |
| Hihat 1 | Hi-hat (closed / half-open) | BOOK | 9 |
| Hihat 2 | Open hat | BOOK | 1 |
| Perc 1 | Floor tom | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Crash | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 9, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . x . . . . . . .
Bar 2   x . . . . . . . x . . . . . . .
Bar 3   x . . . . . . . x . . . . . . .
Bar 4   x . . . . . . . x x . x . x . .
```

**Snare** (slot 9, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . x .
```

**Hihat 1** (slot 9, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2** (slot 1, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . . . . . x .
```

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the 2:01 swung section (BOOK p78).

- **Kick** B part: 1, 2, 4, 8, 12 | 1, 2, 4, 8, 12 | 1, 2, 4, 8, 12 | 1, 2, 4, 8, 12 (bars 1 | 2 | 3 | 4)
- **Snare** B part: 5, 13 | 5, 13 | 5, 13 | 5, 13 (bars 1 | 2 | 3 | 4)
- **Hihat 1** B part: 1, 3, 5, 7, 9, 11, 13, 15

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 10 | 14 | 20 | 8 | 10 | 11 | 15 | 18 | 20 | 24 | 28 | 30 | 34 | 7 | 20 | 35 | 47 | 12 | 13 | 13 | 13 |
| Snare | 2 | 4 | 6 | 8 | 10 | 12 | 8 | 9 | 9 | 11 | 13 | 15 | 17 | 19 | 20 | 22 | 7 | 10 | 21 | 31 | 11 | 11 | 11 | 11 |
| Hihat 1 | 1 | 2 | 4 | 5 | 6 | 6 | 7 | 7 | 8 | 9 | 9 | 10 | 11 | 12 | 12 | 13 | 0 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 5 | 5 | 0 | 6 | 7 | 8 | 2 | 2 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **29** | **38** | **46** | **32** | **37** | **39** | **48** | **54** | **59** | **68** | **75** | **81** | **88** | **14** | **70** | **104** | **134** | **38** | **39** | **40** | **40** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 20/32, Hihat 2 1/4; slot 17 nothing silenced; slot 20 Kick 21/47, Hihat 1 57/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 57/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 6 times. Back to Tight for 21-24. Timing: Shake 4. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

B.'s layout: intro 1-6, verse 7, main beat (classic) 9, main-beat variations to 16, verse stripped to kick and snare at 17, the 2:01 section from 18. Slot 7 is thinner than 6 because the intro is busier than the verse: the dip is the song's own shape. Bar 4's flam is one snare hit. The crash on 1 of bar 1 can't be held (percs loop one bar), so Perc 2 is an OWN crash. Hihat 2's sourced hit is the intro/verse open hat on 15 (slot 1); the main beat itself has no open hat. Turn Shuffle to row 4 at slot 18.

## The builder's own share

40% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: BOOK: 2, 4, 8, 12, 15 | 2, 4, 8, 12, 15 | 2, 4, 8, 12, 15 | 2, 4, 8, 15 (bars 1 | 2 | 3 | 4); OWN: 3, 7, 11 | 3, 5, 7, 11, 13 | 3, 7, 11 | 3, 5, 7, 11, 13, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: BOOK: 10 | 10 | 10 | 10 (bars 1 | 2 | 3 | 4); OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 16.
- **Hihat 2:** classic BOOK. Added: OWN: 1, 3, 5, 7, 9, 11, 13.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
