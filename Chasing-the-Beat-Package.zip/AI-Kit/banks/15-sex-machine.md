# Bank 15: Sex Machine

In the manual *Chasing the Beat*: Sex Machine (bank 15).

- **Source:** James Brown, 1970 (Jabo Starks). Labels: BOOK (rest OWN).
- **Files:** `PatternBank014.txt` (bank slot 15) or `PatternBank046.txt` (bank slot 47).
- **Tempo:** 107 BPM.
- **Home setting:** Shake, Shuffle row 6, Feel Tight, Linear off. Why: Shake 6 (62.5%): Ainsworth's transcription measures the a of 2 hat 39–51 ms late and the e of 3 ghost 27–36 ms late at about 108 BPM. Shake 6 puts them 35 ms late. The open hats on the + measure 4 ms late; Shake keeps them on time.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: a of 2 +35 ms; the rest on the grid; Hihat 2: all on the grid; Perc 1: a of 2 +35 ms, e of 3 +35 ms, a of 4 +35 ms; the rest on the grid.
- **Other settings:** Shake 7, Tight: heavier, 67% (e and a +47 ms). Shake 6, Flam: kick and snare a tick late: the nearest the module gets to Jabo's late backbeat (it moves the kick too) (e and a +35 ms; kick and snare +18 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 4 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 7 |
| Hihat 2 | Open hat | BOOK | 2 |
| Perc 1 | Ghost snare (quiet) | BOOK | 4 |
| Perc 2 | Cowbell | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . . . x . . . . .
Bar 2   x . . . . . . . . . x . . . . .
Bar 3   x . . . . . . . . . x . . . . .
Bar 4   x . . . . . . . . . x . . . . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 7, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . x x x . . . x . x .
```

**Hihat 2** (slot 2, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . . . . . x . . . . .
```

**Perc 1** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . x x . x . . . . . x
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 11 | 13 | 13 | 16 | 16 | 18 | 20 | 20 | 22 | 24 | 24 | 3 | 28 | 32 | 34 | 9 | 9 | 10 | 10 |
| Snare | 2 | 4 | 6 | 8 | 9 | 11 | 11 | 12 | 13 | 15 | 15 | 15 | 17 | 17 | 19 | 19 | 7 | 23 | 25 | 27 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 11 | 12 | 2 | 14 | 15 | 16 | 8 | 8 | 8 | 8 |
| Hihat 2 | 1 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 0 | 6 | 7 | 8 | 4 | 4 | 4 | 4 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 0 | 13 | 15 | 16 | 5 | 5 | 5 | 5 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **23** | **29** | **35** | **39** | **43** | **46** | **52** | **57** | **59** | **63** | **66** | **71** | **76** | **78** | **12** | **94** | **107** | **117** | **37** | **38** | **39** | **39** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 12/28, Hihat 2 4/8; slot 17 Hihat 1 7/8; slot 20 Kick 20/34, Hihat 1 41/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 41/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 5 times. Back to Tight for 21-24. Timing: Shake 6. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Jabo's backbeat sits late against an on-time kick on the record; the module can only delay kick and snare together (Flam), so it's offered as an also-try, not built in.

## The builder's own share

50% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 9, 15 | 3, 4, 5, 7, 8, 9, 13, 15 | 3, 7, 9, 15 | 3, 4, 5, 7, 8, 9, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 3, 4, 6, 10, 11, 12, 14, 16.
- **Hihat 2:** classic BOOK. Added: OWN: 1, 5, 7, 9, 13, 15.
- **Perc 1:** classic BOOK. Added: OWN: 1, 2, 3, 4, 5, 6, 9, 11, 12, 13, 14, 15.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
