# Bank 22: Smells Like Teen Spirit

In the manual *Chasing the Beat*: Smells Like Teen Spirit (bank 22).

- **Source:** Nirvana, 1991 (Dave Grohl). Labels: BOOK (rest OWN).
- **Files:** `PatternBank021.txt` (bank slot 22) or `PatternBank053.txt` (bank slot 54).
- **Tempo:** 117 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid.
- **Other settings:** Push 2, Tight: the off-beat hits sit back (e, + and a +18 ms). Shake 2, Tight: the 16th kicks and snares round off (e and a +18 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 8 |
| Snare | Snare | BOOK | 8 |
| Hihat 1 | Half-open hat | BOOK | 4 |
| Hihat 2 | Open hat | BOOK | 17 (silent in the source: the drop is the record) |
| Perc 1 | Floor tom | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Crash | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . x . . . . x . x x . . x .
Bar 2   x . . x . . . . x . x x . . x .
Bar 3   x . . x . . . . x . x x . . x .
Bar 4   x . . x . . . . x . x x . . x .
```

**Snare** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . x . x . . x . . .
Bar 2   . . . . x . . x . x . . x . . .
Bar 3   . . . . x . . x . x . . x . . .
Bar 4   . . . . x . . x . x . . x . . .
```

**Hihat 1** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . . . x . . . x . . .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** nothing; every hit comes and goes.
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the intro figure (BOOK p123).

- **Kick** B part: 2, 4, 6, 8, 10, 12, 15 | 2, 4, 6, 8, 10, 12, 15 | 2, 4, 6, 8, 10, 12, 15 | 2, 4, 6, 8, 10, 12, 15 (bars 1 | 2 | 3 | 4)
- **Snare** B part: 1, 5, 9, 13 | 1, 5, 9, 13 | 1, 5, 9, 13 | 1, 5, 9, 13 (bars 1 | 2 | 3 | 4)
- **Hihat 2** B part: 3, 7, 11

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 12 | 16 | 20 | 24 | 26 | 28 | 32 | 34 | 36 | 38 | 40 | 42 | 3 | 28 | 42 | 54 | 26 | 26 | 26 | 26 |
| Snare | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 18 | 20 | 22 | 22 | 24 | 26 | 27 | 30 | 7 | 16 | 28 | 38 | 18 | 18 | 18 | 18 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 2 | 13 | 15 | 16 | 5 | 5 | 5 | 5 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 4 | 6 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **21** | **26** | **35** | **41** | **48** | **56** | **62** | **69** | **75** | **78** | **84** | **90** | **95** | **101** | **12** | **81** | **117** | **148** | **56** | **56** | **56** | **56** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 16/16 (EMPTIED); slot 17 Hihat 1 7/8; slot 20 Kick 34/54, Hihat 1 58/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 58/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The book calls the intro a fill; it repeats as a figure, so it's the B part at 18. Flams are one hit. The verse groove isn't in the book.

## The builder's own share

35% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: BOOK: 2, 6, 8, 10 | 2, 6, 8, 10 | 2, 6, 8, 10 | 2, 6, 8, 10 (bars 1 | 2 | 3 | 4); OWN: 3, 7 | 3, 5, 7, 13 | 3, 7 | 3, 5, 7, 13, 14, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: BOOK: 1, 9 | 1, 9 | 1, 9 | 1, 9 (bars 1 | 2 | 3 | 4); OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 3, 4, 6, 7, 8, 10, 11, 12, 14, 15, 16.
- **Hihat 2:** classic BOOK. Added: BOOK: 3, 7, 11; OWN: 1, 5, 9, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
