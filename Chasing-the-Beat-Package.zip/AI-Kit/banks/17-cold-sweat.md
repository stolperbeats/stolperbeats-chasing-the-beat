# Bank 17: Cold Sweat

In the manual *Chasing the Beat*: Cold Sweat (bank 17).

- **Source:** James Brown, 1967 (Clyde Stubblefield). Labels: BOOK (rest OWN).
- **Files:** `PatternBank016.txt` (bank slot 17) or `PatternBank048.txt` (bank slot 49).
- **Tempo:** 112 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Shake 1 (straight), by B.'s rule that every bank not using Trip starts on Shake. Ainsworth measures Cold Sweat almost straight (swing ratio 1.07:1), so straight is close to the record.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Hihat 2: all on the grid; Perc 1: all on the grid.
- **Other settings:** Push 3, Tight: a little less lean (e, + and a +15 ms). Push 2, Tight: the closest match to Ainsworth's measurements (e, + and a +19 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 4 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 7 |
| Hihat 2 | Open hat | BOOK | 1 |
| Perc 1 | Ghost snare (quiet) | BOOK | 2 |
| Perc 2 | Cowbell | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . . . x . . . . .
Bar 2   . . x . . . . . . . x . . . . .
Bar 3   x . . . . . . . . . x . . . . .
Bar 4   . . x . . . . . . . x . . . . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . . . x .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . . . x .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 7, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . . . x . x .
```

**Hihat 2** (slot 1, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . x . . . . .
```

**Perc 1** (slot 2, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . x . x . . . . . .
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 10 | 12 | 12 | 14 | 14 | 16 | 18 | 18 | 20 | 20 | 21 | 4 | 25 | 29 | 30 | 10 | 10 | 10 | 10 |
| Snare | 2 | 4 | 6 | 8 | 10 | 10 | 10 | 12 | 12 | 12 | 13 | 13 | 15 | 15 | 15 | 17 | 5 | 19 | 21 | 22 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 11 | 12 | 2 | 14 | 15 | 16 | 8 | 8 | 8 | 8 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 5 | 5 | 0 | 6 | 7 | 8 | 2 | 2 | 3 | 3 |
| Perc 1 | 1 | 2 | 3 | 3 | 4 | 4 | 5 | 5 | 6 | 7 | 7 | 8 | 8 | 9 | 9 | 10 | 0 | 12 | 14 | 16 | 3 | 3 | 3 | 3 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **27** | **34** | **35** | **40** | **44** | **47** | **50** | **54** | **58** | **61** | **65** | **67** | **72** | **11** | **86** | **99** | **108** | **34** | **35** | **36** | **36** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 12/28, Hihat 2 4/4 (EMPTIED); slot 17 Hihat 1 5/8; slot 20 Kick 18/30, Hihat 1 34/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 34/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Bar 2's extra ghost (step 2) is a variation hit, since percs loop one bar.

## The builder's own share

50% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 9, 15 | 1, 5, 7, 9, 13, 15 | 3, 7, 9, 15 | 1, 5, 7, 9, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 13 | 3, 7, 11, 15 | 7, 13 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 4, 6, 8, 10, 11, 12, 14, 16.
- **Hihat 2:** classic BOOK. Added: OWN: 1, 3, 5, 7, 9, 13, 15.
- **Perc 1:** classic BOOK. Added: BOOK: 2; OWN: 1, 3, 4, 5, 6, 7, 9, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
