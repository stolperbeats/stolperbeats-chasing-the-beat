# Bank 05: Go-go (Bustin' Loose)

In the manual *Chasing the Beat*: Go-go (Bustin' Loose) (bank 05).

- **Source:** Chuck Brown style (Ricky Wellman; congas Gregory Gerran). Labels: ARCHIVE (rest OWN).
- **Files:** `PatternBank004.txt` (bank slot 5) or `PatternBank036.txt` (bank slot 37).
- **Tempo:** 92 BPM.
- **Home setting:** Shake, Shuffle row 6, Feel Tight, Linear off. Why: Shake 6 (62.5%): SuperTime's go-go study is hard-swung at 62%.
- **What the home setting does to the classic:** Kick: a of 1 +41 ms, a of 2 +41 ms; the rest on the grid; Snare: all on the grid; Hihat 2: all on the grid; Perc 1: a of 4 +41 ms; the rest on the grid.
- **Other settings:** Shake 4, Tight: lighter, 60% (e and a +33 ms). Shake 7, Tight: full triplet swing (e and a +54 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | ARCHIVE | 8 |
| Snare | Snare | ARCHIVE | 4 |
| Hihat 1 | Closed hat (not in the study) | OWN | 17 (silent in the source: the drop is the record) |
| Hihat 2 | Open hat | ARCHIVE | 1 |
| Perc 1 | Ghost snare (quiet) | ARCHIVE | 3 |
| Perc 2 | Congas | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . x . . . x . . x . . . . .
Bar 2   x . . x . . x . . . x . . x . .
Bar 3   x . . x . . . x . . x . . . . .
Bar 4   x . . x . . x . . . x . . x . .
```

**Snare** (slot 4, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1:** silent in the source. Slot 17 is empty.

**Hihat 2** (slot 1, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . x . . . . .
```

**Perc 1** (slot 3, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . . . . . x . . . . x
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 18 | 21 | 23 | 23 | 25 | 27 | 29 | 31 | 33 | 3 | 37 | 39 | 41 | 19 | 20 | 20 | 20 |
| Snare | 2 | 4 | 6 | 8 | 9 | 11 | 11 | 13 | 13 | 14 | 14 | 15 | 17 | 17 | 19 | 19 | 7 | 23 | 25 | 27 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 5 | 5 | 0 | 6 | 7 | 8 | 2 | 2 | 3 | 3 |
| Perc 1 | 1 | 2 | 3 | 4 | 4 | 5 | 5 | 6 | 7 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 0 | 13 | 15 | 16 | 4 | 4 | 4 | 4 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **21** | **26** | **31** | **36** | **39** | **48** | **52** | **57** | **59** | **63** | **69** | **72** | **79** | **82** | **10** | **99** | **112** | **124** | **38** | **40** | **41** | **41** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 2 4/4 (EMPTIED), Perc 1 4/12; slot 17 nothing silenced; slot 20 Kick 20/41, Hihat 1 48/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 48/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 5 times. Back to Tight for 21-24. Timing: Shake 6. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The study has no closed hats and no conga part: Hihat 1 and the congas (Perc 2) are OWN, as the archive says a kit-only go-go is incomplete. Bar 2's open hat on 15 is a variation hit (hats loop one bar).

## The builder's own share

51% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic ARCHIVE. Added: OWN: 3, 7, 9, 14, 15 | 3, 5, 8, 9, 13, 15 | 3, 7, 9, 14, 15 | 3, 5, 8, 9, 13, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic ARCHIVE. Added: OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Hihat 2:** classic ARCHIVE. Added: ARCHIVE: 15; OWN: 1, 3, 5, 7, 9, 13.
- **Perc 1:** classic ARCHIVE. Added: OWN: 1, 2, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
