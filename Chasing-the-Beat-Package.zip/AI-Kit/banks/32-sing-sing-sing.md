# Bank 32: Sing, Sing, Sing

In the manual *Chasing the Beat*: Sing, Sing, Sing (bank 32).

- **Source:** Benny Goodman, 1937 (Gene Krupa). Labels: BOOK (rest OWN).
- **Files:** `PatternBank031.txt` (bank slot 32) or `PatternBank063.txt` (bank slot 64).
- **Tempo:** 216 BPM.
- **Home setting:** Trip, Shuffle row 5, Feel Tight, Linear off. Why: Trip 5: swing 8ths at 216. The short note comes out at 93 ms, right on Friberg and Sundström's ~100 ms.
- **What the home setting does to the classic:** Kick: all on the grid; Hihat 1: all on the grid; Perc 1: + of 1 +46 ms, + of 2 +46 ms, + of 3 +46 ms, + of 4 +46 ms; the rest on the grid; Perc 2: + of 3 +46 ms; the rest on the grid.
- **Other settings:** Trip 2, Tight: lighter still, + at 57% (e +10 ms, + +20 ms, a +30 ms). Trip 4, Tight: less swing at this speed, + at 60% (e -14 ms, + +28 ms, a +14 ms).
- **Triplet grid:** yes: only steps 1 and 3 of each beat are used.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick (soft, feathered) | BOOK | 8 |
| Snare | Snare (not in the classic) | OWN | 17 (silent in the source: the drop is the record) |
| Hihat 1 | Hi-hat foot | BOOK | 2 |
| Hihat 2 | Snare press roll (for Rolls) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Floor tom | BOOK | 20 (already at the module's limit) |
| Perc 2 | Tom accents | BOOK | 4 |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . . . x . . . x . . .
Bar 2   x . . . x . . . x . . . x . . .
Bar 3   x . . . x . . . x . . . x . . .
Bar 4   x . . . x . . . x . . . x . . .
```

**Snare:** silent in the source. Slot 17 is empty.

**Hihat 1** (slot 2, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . x . . . . . . . x . . .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1** (slot 20, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Perc 2** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . . . x . x . . . . .
```

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** nothing; every hit comes and goes.
- **Hihat 1:** 5
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 18 | 18 | 20 | 22 | 22 | 24 | 26 | 26 | 3 | 28 | 30 | 32 | 18 | 18 | 18 | 18 |
| Snare | 2 | 4 | 4 | 4 | 6 | 6 | 6 | 8 | 8 | 8 | 10 | 10 | 10 | 12 | 12 | 12 | 0 | 18 | 24 | 28 | 4 | 4 | 4 | 4 |
| Hihat 1 | 1 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 4 | 6 | 7 | 8 | 4 | 4 | 4 | 4 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 0 | 6 | 7 | 8 | 7 | 7 | 7 | 7 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 6 | 6 | 7 | 7 | 0 | 6 | 7 | 8 | 4 | 4 | 4 | 4 |
| **Bank** | **8** | **15** | **20** | **23** | **28** | **31** | **33** | **37** | **43** | **43** | **47** | **50** | **50** | **56** | **60** | **60** | **7** | **70** | **82** | **92** | **40** | **40** | **40** | **40** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 1, Hihat 2, Perc 1, Perc 2. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 8/8 (EMPTIED), Perc 1 20/32, Perc 2 12/16; slot 17 Hihat 1 3/16; slot 20 Kick 28/32, Hihat 1 32/32 (EMPTIED), Hihat 2 32/32 (EMPTIED), Perc 1 32/32 (EMPTIED), Perc 2 32/32 (EMPTIED).

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 2 times. Back to Tight for 21-24. Timing: Trip 5. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Triplet grid: steps 1 and 3 only, on Trip 5. The floor tom already fills every triplet step, so Perc 1's classic sits at slot 20. No snare in the classic: the Snare track is OWN and joins in the build. Hihat 2 is an OWN snare press roll, empty in the classic, for Rolls at the peak (after Krupa's).

## The builder's own share

45% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 15 (bars 1 | 2 | 3 | 4).
- **Snare:** classic OWN. Added: OWN: 3, 5, 7, 11, 13, 15 | 1, 3, 5, 7, 9, 11, 13, 15 | 3, 5, 7, 11, 13, 15 | 1, 3, 5, 7, 9, 11, 13, 15 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 1, 3, 7, 9, 11, 15.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic BOOK. Nothing added.
- **Perc 2:** classic BOOK. Added: BOOK: 7; OWN: 3, 13, 15.
