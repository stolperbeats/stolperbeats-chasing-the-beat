# Bank 11: Ain't Nobody

In the manual *Chasing the Beat*: Ain't Nobody (bank 11).

- **Source:** Rufus & Chaka Khan, 1983 (John 'JR' Robinson). Labels: BOOK (rest OWN).
- **Files:** `PatternBank010.txt` (bank slot 11) or `PatternBank042.txt` (bank slot 43).
- **Tempo:** 104 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight. JR played against a drum-machine part; the book describes no swing.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid.
- **Other settings:** Trip 2, Tight: experimental: the a of each beat crowds the next beat, so the kick run across the bar line rushes (Dilla-style wonk) (e +21 ms, + +41 ms, a +62 ms). Shake 2, Tight: the kicks and hats on the e and a swing lightly (e and a +21 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 8 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 8 |
| Hihat 2 | Open hat | BOOK | 17 (silent in the source: the drop is the record) |
| Perc 1 | Shaker | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Clap | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x x . . . . . x . . . x . x . x
Bar 2   x x . . . . . x . . . x . x . x
Bar 3   x x . . . . . x . . . x . x . x
Bar 4   x x . . . . . x . . . x . x . x
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x x x . x x x . . . x . x x x
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** 1
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the chorus at 1:23: hats open on 14 and 16 (BOOK p8).

- **Hihat 1** B part: 1, 2, 3, 4, 6, 7, 8, 12, 15
- **Hihat 2** B part: 14, 16

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 12 | 16 | 20 | 24 | 26 | 28 | 30 | 32 | 34 | 36 | 38 | 40 | 3 | 44 | 48 | 50 | 26 | 26 | 26 | 26 |
| Snare | 2 | 4 | 6 | 8 | 9 | 9 | 11 | 11 | 11 | 13 | 13 | 13 | 14 | 15 | 15 | 17 | 7 | 19 | 21 | 22 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 7 | 9 | 11 | 12 | 12 | 12 | 12 | 12 | 13 | 13 | 13 | 4 | 9 | 13 | 16 | 13 | 13 | 13 | 13 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 2 | 5 | 8 | 2 | 2 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **21** | **26** | **34** | **40** | **48** | **56** | **60** | **66** | **68** | **70** | **75** | **80** | **84** | **88** | **14** | **94** | **113** | **128** | **55** | **55** | **56** | **56** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 24/44; slot 17 Hihat 1 10/16; slot 20 Kick 18/50, Hihat 1 54/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 54/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The chorus opens the hat on 14 and 16, which aren't 8ths: slot 18 has them; the peak's Hihat 2 is on 8ths for Rolls.

## The builder's own share

40% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 9, 11, 15 | 3, 5, 7, 9, 10, 11, 13, 15 | 3, 7, 9, 11, 15 | 3, 5, 7, 9, 10, 11, 13, 15 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 5, 9, 10, 11, 13.
- **Hihat 2:** classic BOOK. Added: BOOK: 14, 16; OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
