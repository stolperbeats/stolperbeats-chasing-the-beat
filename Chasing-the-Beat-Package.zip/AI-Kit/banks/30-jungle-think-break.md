# Bank 30: Jungle (Think break)

In the manual *Chasing the Beat*: Jungle (Think break) (bank 30).

- **Source:** Lyn Collins, 'Think (About It)', 1972 (Jabo Starks), chopped jungle-style. Labels: AINSWORTH.
- **Files:** `PatternBank029.txt` (bank slot 30) or `PatternBank061.txt` (bank slot 62).
- **Tempo:** 165 BPM.
- **Home setting:** Shake, Shuffle row 2, Feel Tight, Linear off. Why: Shake 2 (57%): Ainsworth measures the Think break's e ghosts about 11–15 ms late at 113 BPM with the + on time; KAN describes the hats sitting between straight 16ths and 16th triplets. Shake 2 keeps that ratio at jungle tempo.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Hihat 2: all on the grid; Perc 1: e of 1 +13 ms, a of 1 +13 ms, e of 2 +13 ms, a of 2 +13 ms, e of 3 +13 ms, a of 3 +13 ms, e of 4 +13 ms, a of 4 +13 ms; the rest on the grid; Perc 2: a of 2 +13 ms, e of 3 +13 ms; the rest on the grid.
- **Other settings:** Shake 1, Tight: machine-straight chops (straight). Shake 4, Tight: a looser break, 60% (e and a +18 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | AINSWORTH | 2 |
| Snare | Snare | AINSWORTH | 4 |
| Hihat 1 | Closed hat | AINSWORTH | 7 |
| Hihat 2 | Open hat | AINSWORTH | 1 |
| Perc 1 | Tambourine | AINSWORTH | 20 (already at the module's limit) |
| Perc 2 | Ghost snare (quiet) | AINSWORTH | 3 |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 2, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . . . . . . . . .
Bar 2   x . . . . . . . . . . . . . . .
Bar 3   x . . . . . . . . . . . . . . .
Bar 4   x . . . . . . . . . . . . . . .
```

**Snare** (slot 4, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 7, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . . .
```

**Hihat 2** (slot 1, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . . . . . . x .
```

**Perc 1** (slot 20, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x x x x x x x x x x x x x x x
```

**Perc 2** (slot 3, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . x . x x . . . . .
```

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 6 | 8 | 9 | 11 | 11 | 12 | 14 | 16 | 16 | 18 | 20 | 20 | 22 | 3 | 26 | 30 | 32 | 5 | 5 | 6 | 6 |
| Snare | 2 | 4 | 6 | 8 | 10 | 10 | 11 | 13 | 13 | 15 | 15 | 15 | 16 | 18 | 18 | 19 | 7 | 23 | 25 | 27 | 9 | 9 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 11 | 12 | 2 | 14 | 15 | 16 | 8 | 8 | 8 | 8 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 5 | 5 | 0 | 6 | 7 | 8 | 2 | 2 | 3 | 3 |
| Perc 1 | 1 | 2 | 3 | 4 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 11 | 12 | 13 | 14 | 0 | 14 | 15 | 16 | 15 | 15 | 15 | 15 |
| Perc 2 | 1 | 2 | 3 | 4 | 4 | 5 | 5 | 6 | 7 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 0 | 13 | 15 | 16 | 4 | 4 | 4 | 4 |
| **Bank** | **8** | **16** | **23** | **28** | **33** | **37** | **43** | **48** | **51** | **57** | **62** | **65** | **68** | **75** | **77** | **83** | **12** | **96** | **107** | **115** | **43** | **43** | **46** | **46** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 12/28, Perc 1 24/64; slot 17 Hihat 1 7/8; slot 20 Kick 20/32, Hihat 1 39/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 39/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 2. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The tambourine is already every 16th, so Perc 1's classic sits at slot 20. The Think grid is sourced; every chop is OWN. The beat-4 snare on the record lands early; nothing on the module plays early.

## The builder's own share

41% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic AINSWORTH. Added: OWN: 3, 7, 9, 11, 15 | 3, 5, 7, 8, 9, 11, 13, 15 | 3, 7, 9, 11, 15 | 3, 5, 7, 8, 9, 11, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic AINSWORTH. Added: OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic AINSWORTH. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 15, 16.
- **Hihat 2:** classic AINSWORTH. Added: AINSWORTH: 11; OWN: 1, 3, 5, 7, 9, 13.
- **Perc 1:** classic AINSWORTH. Nothing added.
- **Perc 2:** classic AINSWORTH. Added: AINSWORTH: 16; OWN: 1, 2, 3, 4, 5, 6, 7, 9, 12, 13, 14, 15.
