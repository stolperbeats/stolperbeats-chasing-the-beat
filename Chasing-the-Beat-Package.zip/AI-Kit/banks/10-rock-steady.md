# Bank 10: Rock Steady

In the manual *Chasing the Beat*: Rock Steady (bank 10).

- **Source:** Aretha Franklin, 1971 (Bernard Purdie). Labels: BOOK (rest OWN).
- **Files:** `PatternBank009.txt` (bank slot 10) or `PatternBank041.txt` (bank slot 42).
- **Tempo:** 104 BPM.
- **Home setting:** Shake, Shuffle row 2, Feel Tight, Linear off. Why: Shake 2 (57%): a light percolation on Purdie's ghosts and the a-of-2 kick, which the book says pushes the song.
- **What the home setting does to the classic:** Kick: a of 2 +21 ms; the rest on the grid; Snare: all on the grid; Hihat 1: all on the grid; Hihat 2: all on the grid; Perc 1: e of 1 +21 ms, e of 2 +21 ms, a of 2 +21 ms, e of 3 +21 ms, e of 4 +21 ms; the rest on the grid.
- **Other settings:** Shake 4, Tight: more swing on the ghosts (e and a +29 ms). Push 2, Tight: every offbeat late by the same amount instead of swinging (e, + and a +21 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 8 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 6 |
| Hihat 2 | Open hat | BOOK | 2 |
| Perc 1 | Ghost snare (quiet) | BOOK | 5 |
| Perc 2 | Handclap | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . x . . . . x . . x . . . . .
Bar 2   x . x . . . . x . . x . . . . .
Bar 3   x . x . . . . x . . x . . . . .
Bar 4   x . x . . . . x . . x . . . . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 6, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . x . x . . . x . x .
```

**Hihat 2** (slot 2, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . . . . . x . . . . .
```

**Perc 1** (slot 5, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . . . x . x . x . . . x . .
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 17 | 19 | 21 | 23 | 23 | 25 | 27 | 27 | 3 | 31 | 33 | 35 | 18 | 18 | 18 | 18 |
| Snare | 2 | 4 | 6 | 8 | 9 | 11 | 11 | 12 | 13 | 15 | 15 | 15 | 17 | 17 | 19 | 19 | 7 | 23 | 25 | 27 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 7 | 8 | 8 | 9 | 10 | 10 | 11 | 11 | 12 | 2 | 14 | 15 | 16 | 7 | 7 | 7 | 7 |
| Hihat 2 | 1 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 0 | 6 | 7 | 8 | 4 | 4 | 4 | 4 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 11 | 11 | 12 | 0 | 14 | 15 | 16 | 6 | 6 | 6 | 6 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **23** | **29** | **35** | **41** | **44** | **49** | **54** | **59** | **63** | **66** | **70** | **75** | **80** | **82** | **12** | **98** | **108** | **118** | **46** | **47** | **47** | **47** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 12/24, Hihat 2 8/8 (EMPTIED), Perc 1 4/20; slot 17 Hihat 1 7/8; slot 20 Kick 20/35, Hihat 1 42/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 42/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 2. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The handclap on Perc 2 is OWN (not in the book figure).

## The builder's own share

42% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 7, 9, 15 | 5, 7, 9, 13, 14, 15 | 7, 9, 15 | 5, 7, 9, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 3, 4, 6, 8, 10, 11, 12, 14, 16.
- **Hihat 2:** classic BOOK. Added: OWN: 1, 5, 7, 9, 13, 15.
- **Perc 1:** classic BOOK. Added: OWN: 1, 3, 4, 5, 7, 9, 11, 12, 13, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
