# Bank 25: I Feel Love

In the manual *Chasing the Beat*: I Feel Love (bank 25).

- **Source:** Donna Summer / Giorgio Moroder, 1977 (kick: Keith Forsey). Labels: ARTICLES (rest OWN).
- **Files:** `PatternBank024.txt` (bank slot 25) or `PatternBank056.txt` (bank slot 57).
- **Tempo:** 126.5 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight: sequenced.
- **What the home setting does to the classic:** Kick: all on the grid; Hihat 1: all on the grid.
- **Other settings:** Shake 2, Tight: only matters once the build adds 16ths (e and a +17 ms). Push 3, Tight: the offbeat hats lean late (e, + and a +13 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | ARTICLES | 8 |
| Snare | Snare / clap (not sourced) | OWN | 17 (silent in the source: the drop is the record) |
| Hihat 1 | Offbeat hat (filtered noise) | ARTICLES | 4 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | 16th hat / noise tick | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Clap | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, ARTICLES):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . . . x . . . x . . .
Bar 2   x . . . x . . . x . . . x . . .
Bar 3   x . . . x . . . x . . . x . . .
Bar 4   x . . . x . . . x . . . x . . .
```

**Snare:** silent in the source. Slot 17 is empty.

**Hihat 1** (slot 4, ARTICLES):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . x . . . x . . . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** nothing; every hit comes and goes.
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 18 | 20 | 20 | 22 | 24 | 24 | 26 | 28 | 3 | 30 | 32 | 34 | 18 | 18 | 18 | 18 |
| Snare | 2 | 4 | 4 | 4 | 4 | 6 | 6 | 6 | 6 | 8 | 8 | 8 | 8 | 9 | 9 | 11 | 0 | 15 | 19 | 22 | 4 | 4 | 4 | 4 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 4 | 13 | 15 | 16 | 5 | 5 | 5 | 5 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **19** | **22** | **27** | **31** | **34** | **38** | **42** | **49** | **49** | **52** | **56** | **59** | **63** | **68** | **7** | **84** | **99** | **112** | **34** | **34** | **34** | **34** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic nothing silenced; slot 17 Hihat 1 3/16; slot 20 Kick 22/34, Hihat 1 34/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 34/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Thin: only the kick and the offbeat hat are sourced (magazine and encyclopedia descriptions). The snare, Perc 1, Perc 2 and Hihat 2 are OWN, and silent at the drop, which is the record.

## The builder's own share

63% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic ARTICLES. Added: OWN: 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic OWN. Added: OWN: 5, 7, 13, 15 | 3, 5, 7, 11, 13, 15 | 5, 7, 13, 15 | 3, 5, 7, 11, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic ARTICLES. Added: OWN: 1, 2, 4, 5, 6, 8, 9, 10, 12, 13, 14, 16.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
