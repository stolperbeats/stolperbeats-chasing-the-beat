# Bank 24: Chicago house

In the manual *Chasing the Beat*: Chicago house (bank 24).

- **Source:** Chicago jack house (SuperTime study). Labels: ST (rest OWN).
- **Files:** `PatternBank023.txt` (bank slot 24) or `PatternBank055.txt` (bank slot 56).
- **Tempo:** 124 BPM.
- **Home setting:** Shake, Shuffle row 2, Feel Tight, Linear off. Why: Shake 2 (57%): SuperTime's jack-house study is 56%, and says the shuffle on the closed hats is what makes it jack.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: e of 1 +17 ms, a of 1 +17 ms, e of 2 +17 ms, a of 2 +17 ms, e of 3 +17 ms, a of 3 +17 ms, e of 4 +17 ms, a of 4 +17 ms; the rest on the grid; Hihat 2: all on the grid.
- **Other settings:** Shake 4, Tight: 60%, more jack (e and a +24 ms). Shake 5, Tight: 58% (e and a +20 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | ST | 8 |
| Snare | Clap | ST | 4 |
| Hihat 1 | Closed hat | ST | 8 |
| Hihat 2 | Open hat | ST | 4 |
| Perc 1 | Shaker | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Rim / cowbell | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . . . x . . . x . . .
Bar 2   x . . . x . . . x . . . x . . .
Bar 3   x . . . x . . . x . . . x . . .
Bar 4   x . . . x . . . x . . . x . . .
```

**Snare** (slot 4, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 8, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x . x x x . x x x . x x x . x
```

**Hihat 2** (slot 4, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . x . . . x . . . x .
```

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 18 | 19 | 20 | 22 | 24 | 26 | 26 | 28 | 3 | 32 | 34 | 36 | 17 | 17 | 18 | 18 |
| Snare | 2 | 4 | 6 | 8 | 9 | 11 | 11 | 12 | 13 | 15 | 15 | 15 | 17 | 17 | 19 | 19 | 7 | 23 | 25 | 27 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 6 | 8 | 10 | 12 | 13 | 13 | 13 | 13 | 14 | 14 | 14 | 14 | 2 | 14 | 15 | 16 | 12 | 12 | 14 | 14 |
| Hihat 2 | 1 | 2 | 3 | 4 | 5 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 6 | 6 | 7 | 7 | 0 | 6 | 7 | 8 | 4 | 4 | 4 | 4 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **28** | **36** | **42** | **46** | **53** | **58** | **63** | **64** | **66** | **73** | **75** | **80** | **82** | **12** | **95** | **107** | **119** | **46** | **47** | **50** | **50** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Kick 8/16, Hihat 1 16/48; slot 17 Hihat 1 7/8; slot 20 Kick 24/36, Hihat 1 39/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 39/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 2. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Shaker and rim are OWN.

## The builder's own share

40% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic ST. Added: OWN: 3, 7, 11, 15 | 3, 7, 8, 11, 15 | 3, 7, 11, 15 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic ST. Added: OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic ST. Added: OWN: 3, 7, 11, 15.
- **Hihat 2:** classic ST. Added: OWN: 1, 5, 9, 13.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
