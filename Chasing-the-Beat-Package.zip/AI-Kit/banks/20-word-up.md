# Bank 20: Word Up

In the manual *Chasing the Beat*: Word Up (bank 20).

- **Source:** Cameo, 1986 (Larry Blackmon). Labels: BOOK (rest OWN).
- **Files:** `PatternBank019.txt` (bank slot 20) or `PatternBank051.txt` (bank slot 52).
- **Tempo:** 116 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight: the book calls it computer-driven.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid.
- **Other settings:** Push 3, Tight: the + of 2 kick and the + of 3 hat sit back (e, + and a +14 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 4 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 5 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Shaker | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Clap | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . x . . . . . . . . .
Bar 2   x . . . . . x . . . . . . . . .
Bar 3   x . . . . . x . . . . . . . . .
Bar 4   x . . . . . x . . . . . . . . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 5, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . . . x . x . x . . .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the 2:17 variation (BOOK p158).

- **Kick** B part: 1, 7, 16 | 1, 7, 16 | 1, 7, 16 | 1, 7, 16 (bars 1 | 2 | 3 | 4)
- **Hihat 1** B part: 1, 5, 9, 13

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 10 | 12 | 14 | 14 | 16 | 18 | 18 | 20 | 20 | 22 | 23 | 3 | 12 | 24 | 33 | 9 | 10 | 10 | 10 |
| Snare | 2 | 4 | 6 | 8 | 9 | 9 | 11 | 11 | 11 | 13 | 13 | 13 | 14 | 16 | 16 | 16 | 7 | 18 | 20 | 22 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 11 | 11 | 12 | 2 | 5 | 11 | 16 | 6 | 6 | 6 | 6 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **21** | **26** | **32** | **33** | **37** | **42** | **44** | **50** | **53** | **53** | **59** | **63** | **67** | **69** | **12** | **61** | **88** | **111** | **32** | **33** | **33** | **33** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 12/20; slot 17 Hihat 1 7/8; slot 20 Kick 18/33, Hihat 1 37/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 37/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The sparsest bank in the set: the climb and the peak are mostly OWN.

## The builder's own share

55% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: BOOK: 16 | 16 | 16 | 16 (bars 1 | 2 | 3 | 4); OWN: 3, 9, 11, 15 | 3, 5, 9, 11, 13, 15 | 3, 9, 11, 15 | 3, 5, 9, 11, 13, 14, 15 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 3, 4, 6, 7, 8, 10, 12, 14, 15, 16.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
