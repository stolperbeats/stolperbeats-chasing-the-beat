# Bank 23: Apache

In the manual *Chasing the Beat*: Apache (bank 23).

- **Source:** Incredible Bongo Band, 1973 (Jim Gordon; bongos King Errisson). Labels: AINSWORTH (rest OWN).
- **Files:** `PatternBank022.txt` (bank slot 23) or `PatternBank054.txt` (bank slot 55).
- **Tempo:** 118 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Shake 1 (straight), by B.'s rule that every bank not using Trip starts on Shake.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Perc 1: all on the grid.
- **Other settings:** Shake 2, Tight: swing on the ghosts only (e and a +18 ms). Push 3, Tight: the closest match to Ainsworth's measurements of the break (e, + and a +14 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | AINSWORTH | 7 |
| Snare | Snare | AINSWORTH | 4 |
| Hihat 1 | Closed hat | AINSWORTH | 8 |
| Hihat 2 | Open hat | AINSWORTH | 17 (silent in the source: the drop is the record) |
| Perc 1 | Ghost snare (quiet) | AINSWORTH | 2 |
| Perc 2 | Bongos | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 7, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . x . . . . . . . x . . . . .
Bar 2   x . x . . . x . . . x . . . . .
Bar 3   x . x . . . . . . . x . . . . .
Bar 4   x . x . . . x . . . x . . . . .
```

**Snare** (slot 4, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 8, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1** (slot 2, AINSWORTH):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . . . x . . . . . x
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 16 | 18 | 18 | 20 | 22 | 22 | 23 | 24 | 3 | 26 | 28 | 30 | 16 | 16 | 16 | 16 |
| Snare | 2 | 4 | 6 | 8 | 9 | 9 | 11 | 11 | 11 | 13 | 13 | 13 | 14 | 16 | 16 | 16 | 7 | 18 | 20 | 22 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 12 | 12 | 13 | 2 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 3 | 3 | 4 | 4 | 5 | 5 | 6 | 7 | 7 | 8 | 8 | 9 | 9 | 10 | 0 | 12 | 14 | 16 | 3 | 3 | 3 | 3 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **27** | **33** | **36** | **42** | **46** | **49** | **55** | **56** | **59** | **64** | **69** | **71** | **74** | **12** | **86** | **97** | **108** | **43** | **43** | **43** | **43** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 22/32; slot 17 Hihat 1 7/8; slot 20 Kick 18/30, Hihat 1 34/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 34/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Bongos aren't in Ainsworth's table; the archive's split is unverified, so Perc 2 is OWN. Bar B's open hat on 7 is a Hihat 2 hit (hats loop one bar).

## The builder's own share

43% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic AINSWORTH. Added: OWN: 7, 9, 15 | 5, 9, 13, 15 | 7, 9, 15 | 5, 9, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic AINSWORTH. Added: OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic AINSWORTH. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 16.
- **Hihat 2:** classic AINSWORTH. Added: AINSWORTH: 7; OWN: 1, 3, 5, 9, 11, 13, 15.
- **Perc 1:** classic AINSWORTH. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
