# Bank 31: Rock Around The Clock

In the manual *Chasing the Beat*: Rock Around The Clock (bank 31).

- **Source:** Bill Haley & His Comets, 1954 (Billy Gussak). Labels: BOOK (rest OWN).
- **Files:** `PatternBank030.txt` (bank slot 31) or `PatternBank062.txt` (bank slot 63).
- **Tempo:** 178 BPM.
- **Home setting:** Trip, Shuffle row 5, Feel Tight, Linear off. Why: Trip 5: the shuffle is the first and third triplet. Trip rows 5 and 7 put the + exactly on the last triplet (67%). Friberg and Sundström found the short swung note stays around 100 ms at medium and fast tempos; at 178 BPM Trip 5 makes it 112 ms.
- **What the home setting does to the classic:** Kick: all on the grid; Hihat 1: + of 1 +56 ms, + of 2 +56 ms, + of 3 +56 ms, + of 4 +56 ms; the rest on the grid.
- **Other settings:** Trip 2, Tight: lighter still, + at 57% (e +12 ms, + +24 ms, a +36 ms). Trip 4, Tight: a lighter shuffle, + at 60% (e -17 ms, + +34 ms, a +17 ms).
- **Triplet grid:** yes: only steps 1 and 3 of each beat are used.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick (soft, feathered) | BOOK | 8 |
| Snare | Snare (rimshot) | BOOK | 2 |
| Hihat 1 | Snare on the hoop / shuffle | BOOK | 20 (already at the module's limit) |
| Hihat 2 | Crash or open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Brush / shaker | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Woodblock / rim | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . . . x . . . x . . .
Bar 2   x . . . x . . . x . . . x . . .
Bar 3   x . . . x . . . x . . . x . . .
Bar 4   x . . . x . . . x . . . x . . .
```

**Snare** (slot 2, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . . . . . . . . . . . . .
Bar 2   . . . . . . . . . . x . x . . .
Bar 3   . . . . . . . . . . . . . . . .
Bar 4   . . . . . . . . . . x . x . . .
```

**Hihat 1** (slot 20, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** - | 13 | - | 13 (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the 4th verse at 1:15: the backbeat arrives (BOOK p108).

- **Snare** B part: 5, 13 | 5, 13 | 5, 13 | 5, 13 (bars 1 | 2 | 3 | 4)

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 18 | 18 | 20 | 22 | 22 | 24 | 26 | 26 | 3 | 28 | 30 | 32 | 18 | 18 | 18 | 18 |
| Snare | 2 | 4 | 6 | 6 | 8 | 8 | 10 | 10 | 12 | 12 | 14 | 14 | 16 | 16 | 18 | 18 | 4 | 8 | 18 | 28 | 6 | 6 | 6 | 6 |
| Hihat 1 | 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 2 | 6 | 7 | 8 | 7 | 7 | 7 | 7 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| **Bank** | **8** | **15** | **20** | **22** | **26** | **29** | **33** | **35** | **43** | **43** | **47** | **50** | **52** | **57** | **62** | **62** | **9** | **60** | **76** | **92** | **40** | **40** | **40** | **40** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 1, Hihat 2, Perc 1, Perc 2. Hits Linear would silence (silenced/total over 4 bars): classic Kick 2/16, Hihat 1 18/32; slot 17 Hihat 1 4/8; slot 20 Kick 28/32, Hihat 1 32/32 (EMPTIED), Hihat 2 32/32 (EMPTIED), Perc 1 32/32 (EMPTIED), Perc 2 32/32 (EMPTIED).

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 2 times. Back to Tight for 21-24. Timing: Trip 5. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Triplet grid: steps 1 and 3 of each beat only, everywhere, on Trip 5. The hoop shuffle already fills every triplet step, so Hihat 1's classic sits at slot 20. Feathered kick: patch a soft kick.

## The builder's own share

45% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 15 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: BOOK: 5, 13 | 5, 15 | 5, 13 | 5, 15 (bars 1 | 2 | 3 | 4); OWN: 3, 7, 11, 15 | 1, 3, 7, 9 | 3, 7, 11, 15 | 1, 3, 7, 9 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Nothing added.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
