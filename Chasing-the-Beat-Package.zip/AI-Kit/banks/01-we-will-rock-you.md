# Bank 01: We Will Rock You

In the manual *Chasing the Beat*: We Will Rock You (bank 01).

- **Source:** Queen, 1977 (Roger Taylor and overdubs). Labels: BOOK (rest OWN).
- **Files:** `PatternBank000.txt` (bank slot 1) or `PatternBank032.txt` (bank slot 33).
- **Tempo:** 81 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight. Stamps and claps, no swing in the book.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Perc 2: all on the grid.
- **Other settings:** Push 3, Tight: the second stomp of each pair sits heavier (e, + and a +21 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick (the stomp) | BOOK | 8 |
| Snare | Clap | BOOK | 4 |
| Hihat 1 | Closed hat (not on the record) | OWN | 17 (silent in the source: the drop is the record) |
| Hihat 2 | Open hat or crash (not on the record) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Tambourine (not on the record) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Floor tom (doubles the stomp) | BOOK | 4 |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . x . . . . . x . x . . . . .
Bar 2   x . x . . . . . x . x . . . . .
Bar 3   x . x . . . . . x . x . . . . .
Bar 4   x . x . . . . . x . x . . . . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1:** silent in the source. Slot 17 is empty.

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . . . . . x . x . . . . .
```

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 17 | 19 | 19 | 21 | 21 | 23 | 23 | 24 | 3 | 26 | 28 | 30 | 18 | 18 | 18 | 18 |
| Snare | 2 | 4 | 6 | 8 | 9 | 9 | 11 | 11 | 11 | 13 | 13 | 13 | 15 | 15 | 15 | 16 | 7 | 18 | 20 | 22 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 0 | 13 | 15 | 16 | 5 | 5 | 5 | 5 |
| **Bank** | **8** | **16** | **21** | **26** | **32** | **34** | **39** | **43** | **46** | **53** | **53** | **56** | **60** | **64** | **66** | **69** | **10** | **83** | **96** | **108** | **40** | **40** | **40** | **40** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Perc 2 16/16 (EMPTIED); slot 17 nothing silenced; slot 20 Kick 18/30, Hihat 1 34/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 34/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The record has no hats or percussion beyond the stomp toms: Hihat 1, Hihat 2 and Perc 1 are all OWN, and silent at the drop (which is the record). The claps are flammed on a kit; here they're one hit.

## The builder's own share

49% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 7, 15 | 5, 7, 13, 15 | 7, 15 | 5, 7, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic BOOK. Added: OWN: 2, 4, 5, 6, 7, 8, 10, 12, 13, 14, 15, 16.
