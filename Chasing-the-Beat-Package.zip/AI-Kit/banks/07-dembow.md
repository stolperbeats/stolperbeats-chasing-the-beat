# Bank 07: Dembow

In the manual *Chasing the Beat*: Dembow (bank 07).

- **Source:** from Shabba Ranks' 'Dem Bow' (1990) and the Poco Man Jam riddim. Labels: ARCHIVE (rest OWN).
- **Files:** `PatternBank006.txt` (bank slot 7) or `PatternBank038.txt` (bank slot 39).
- **Tempo:** 96 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight: the archive's sources say quantise it hard, the groove is where the snare sits.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Perc 1: all on the grid.
- **Other settings:** Clave 3, Tight: the same, with a bigger drag (beats 2 and 4 +17 ms; 1, a of 1 and + of 2 held). Clave 2, Tight: the module's 3-3-2 logic: the tresillo snare stays locked, the kick on 2 and 4 drags (beats 2 and 4 +22 ms; 1, a of 1 and + of 2 held).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | ARCHIVE | 8 |
| Snare | Snare / rim | ARCHIVE | 8 |
| Hihat 1 | Closed hat | ARCHIVE | 8 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Shaker | ARCHIVE | 20 (already at the module's limit) |
| Perc 2 | Clap or timbale | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . . . x . . . x . . .
Bar 2   x . . . x . . . x . . . x . . .
Bar 3   x . . . x . . . x . . . x . . .
Bar 4   x . . . x . . . x . . . x . . .
```

**Snare** (slot 8, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . x . . x . . . . x . . x .
Bar 2   . . . x . . x . . . . x . . x .
Bar 3   . . . x . . x . . . . x . . x .
Bar 4   . . . x . . x . . . . x . . x .
```

**Hihat 1** (slot 8, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1** (slot 20, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x x x x x x x x x x x x x x x
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 7 | - | 7 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 17 | 19 | 21 | 23 | 23 | 25 | 27 | 27 | 3 | 31 | 33 | 34 | 18 | 18 | 18 | 18 |
| Snare | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 17 | 19 | 19 | 21 | 21 | 23 | 23 | 25 | 13 | 27 | 29 | 30 | 18 | 18 | 18 | 18 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 12 | 12 | 13 | 2 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 3 | 4 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 11 | 12 | 13 | 14 | 0 | 14 | 15 | 16 | 15 | 15 | 15 | 15 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **28** | **34** | **40** | **46** | **53** | **58** | **64** | **68** | **73** | **75** | **82** | **86** | **90** | **18** | **102** | **112** | **120** | **65** | **65** | **65** | **65** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 24/32, Perc 1 32/64; slot 17 nothing silenced; slot 20 Kick 22/34, Hihat 1 42/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 42/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The 16th shaker is already every 16th, the most Perc 1 can hold, so its classic sits at slot 20. Open hat and Perc 2 are OWN.

## The builder's own share

30% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic ARCHIVE. Added: OWN: 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic ARCHIVE. Added: OWN: 5, 13 | 3, 5, 11, 13 | 5, 13 | 3, 5, 11, 13, 14, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic ARCHIVE. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 16.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic ARCHIVE. Nothing added.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
