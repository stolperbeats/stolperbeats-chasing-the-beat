# Bank 02: Sleng Teng (MT-40 Rock)

In the manual *Chasing the Beat*: Sleng Teng (bank 02).

- **Source:** Wayne Smith, 'Under Mi Sleng Teng', 1985 (Casio MT-40 'rock' preset). Labels: MT-40X (rest OWN).
- **Files:** `PatternBank001.txt` (bank slot 2) or `PatternBank033.txt` (bank slot 34).
- **Tempo:** 82 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight, like the Casio preset it came from.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Perc 1: all on the grid.
- **Other settings:** Shake 2, Tight: the soft hats on the e and a swing lightly (e and a +26 ms). Clave 2, Tight: holds 1, the a of 1 and the + of 2 (the riddim's 3-3-2) and drags the kick and snare on 2 and 4: a live-dancehall lean (beats 2 and 4 +26 ms; 1, a of 1 and + of 2 held).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | MT-40X | 8 |
| Snare | Snare | MT-40X | 4 |
| Hihat 1 | Closed hat (strong) | MT-40X | 8 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Closed hat (soft) | MT-40X | 8 |
| Perc 2 | Rimshot | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, MT-40X):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . x . x . . . x . . .
Bar 2   x . . . x . x . x . . . x . . .
Bar 3   x . . . x . x . x . . . x . . .
Bar 4   x . . . x . x . x . . . x . . .
```

**Snare** (slot 4, MT-40X):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 8, MT-40X):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1** (slot 8, MT-40X):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . x . x . x . x . x . x . x
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 16 | 20 | 21 | 23 | 23 | 25 | 25 | 27 | 27 | 28 | 3 | 30 | 32 | 34 | 22 | 22 | 22 | 22 |
| Snare | 2 | 4 | 6 | 8 | 9 | 9 | 11 | 11 | 11 | 13 | 13 | 13 | 15 | 15 | 15 | 16 | 7 | 18 | 20 | 22 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 12 | 12 | 13 | 2 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 12 | 12 | 13 | 0 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **28** | **34** | **38** | **46** | **53** | **57** | **62** | **64** | **66** | **71** | **76** | **77** | **81** | **12** | **92** | **102** | **112** | **55** | **55** | **55** | **55** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Kick 8/20, Hihat 1 20/32; slot 17 Hihat 1 7/8; slot 20 Kick 22/34, Hihat 1 34/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 34/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The preset's own variation adds open hats, but no source gives where: Hihat 2 is OWN. Perc 2 (rimshot) is OWN.

## The builder's own share

35% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic MT-40X. Added: OWN: 3, 11, 15 | 3, 11, 15 | 3, 11, 15 | 3, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic MT-40X. Added: OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic MT-40X. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 16.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic MT-40X. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
