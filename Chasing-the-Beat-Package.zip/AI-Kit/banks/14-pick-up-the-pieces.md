# Bank 14: Pick Up The Pieces

In the manual *Chasing the Beat*: Pick Up The Pieces (bank 14).

- **Source:** Average White Band, 1974 (Robbie McIntosh). Labels: BOOK (rest OWN).
- **Files:** `PatternBank013.txt` (bank slot 14) or `PatternBank045.txt` (bank slot 46).
- **Tempo:** 107 BPM.
- **Home setting:** Shake, Shuffle row 3, Feel Tight, Linear off. Why: Shake 3 (61%): the book calls it nimble jazz-funk swing.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: a of 2 +31 ms; the rest on the grid; Hihat 2: all on the grid.
- **Other settings:** Push 2, Tight: even lateness instead of swing (e, + and a +20 ms). Shake 4, Tight: 60% (e and a +28 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 6 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 7 |
| Hihat 2 | Open hat | BOOK | 2 |
| Perc 1 | Ghost snare (quiet) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Cowbell | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 6, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . . x . x . . . . .
Bar 2   x . . . . . . . x . x . . . . .
Bar 3   x . . . . . . . x . x . . . . .
Bar 4   x . . . . . . . x . x . . . . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 7, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . x x x . . . x . x .
```

**Hihat 2** (slot 2, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . . . . . x . . . . .
```

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the 0:20 and 0:30 versions (BOOK p99-100).

- **Kick** B part: 1, 9, 11, 16 | 1, 9, 11, 16 | 1, 9, 11, 16 | 1, 9, 11, 16 (bars 1 | 2 | 3 | 4)
- **Snare** B part: 5, 8, 13, 16 | 5, 8, 13, 14 | 5, 8, 13, 16 | 5, 8, 13, 14 (bars 1 | 2 | 3 | 4)
- **Hihat 1** B part: 5, 7, 8, 9, 13, 15
- **Hihat 2** B part: 3, 11, 16

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 15 | 17 | 19 | 19 | 21 | 23 | 23 | 25 | 27 | 3 | 16 | 27 | 35 | 13 | 13 | 14 | 14 |
| Snare | 2 | 4 | 6 | 8 | 10 | 10 | 12 | 12 | 14 | 14 | 16 | 18 | 18 | 20 | 20 | 22 | 7 | 16 | 24 | 30 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 11 | 12 | 2 | 6 | 11 | 16 | 8 | 8 | 8 | 8 |
| Hihat 2 | 1 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 4 | 4 | 5 | 5 | 5 | 0 | 3 | 6 | 8 | 4 | 4 | 4 | 4 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **27** | **34** | **37** | **42** | **46** | **51** | **56** | **58** | **63** | **67** | **71** | **75** | **80** | **12** | **61** | **94** | **121** | **39** | **39** | **40** | **40** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 16/28, Hihat 2 4/8; slot 17 Hihat 1 7/8; slot 20 Kick 23/35, Hihat 1 42/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 42/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 6 times. Back to Tight for 21-24. Timing: Shake 3. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

B part = the 0:20 snares plus the 0:30 kick and open hat on the a of 4 (hat on beat 1 dropped), both from the book.

## The builder's own share

43% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: BOOK: 16 | 16 | 16 | 16 (bars 1 | 2 | 3 | 4); OWN: 3, 7, 15 | 3, 5, 7, 8, 13, 15 | 3, 7, 15 | 3, 5, 7, 8, 13, 14, 15 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: BOOK: 8, 16 | 8, 14 | 8, 16 | 8, 14 (bars 1 | 2 | 3 | 4); OWN: 7, 15 | 3, 7, 11, 15, 16 | 7, 15 | 3, 7, 11, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 3, 4, 6, 10, 11, 12, 14, 16.
- **Hihat 2:** classic BOOK. Added: BOOK: 16; OWN: 1, 5, 7, 9, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
