# Bank 08: Superstition

In the manual *Chasing the Beat*: Superstition (bank 08).

- **Source:** Stevie Wonder, 1972 (Stevie on drums). Labels: BOOK (rest OWN).
- **Files:** `PatternBank007.txt` (bank slot 8) or `PatternBank039.txt` (bank slot 40).
- **Tempo:** 100 BPM.
- **Home setting:** Shake, Shuffle row 6, Feel Tight, Linear off. Why: Shake 6 (62.5%): Ethan Hein measured heavy 16th swing on the opening bars, with the 16th offbeats consistently late.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: a of 2 +38 ms, e of 3 +38 ms, a of 4 +38 ms; the rest on the grid.
- **Other settings:** Shake 3, Tight: lighter, 61% (e and a +33 ms). Shake 7, Tight: the heaviest swing, 67% (e and a +50 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 8 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat (swung 16ths) | BOOK | 8 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Ghost snare (quiet) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Tambourine | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . . . x . . . x . . .
Bar 2   x . . . x . . . x . . . x . . .
Bar 3   x . . . x . . . x . . . x . . .
Bar 4   x . . . x . . . x . . . x . . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x x x x x . x . x x
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 19 | 19 | 21 | 22 | 24 | 26 | 28 | 30 | 3 | 34 | 36 | 38 | 17 | 17 | 18 | 18 |
| Snare | 2 | 4 | 6 | 8 | 9 | 11 | 11 | 13 | 13 | 14 | 14 | 15 | 17 | 17 | 19 | 19 | 7 | 23 | 25 | 27 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 7 | 9 | 11 | 12 | 12 | 12 | 12 | 12 | 13 | 13 | 13 | 2 | 14 | 15 | 16 | 11 | 11 | 12 | 13 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **21** | **26** | **32** | **38** | **42** | **50** | **55** | **58** | **60** | **62** | **68** | **72** | **78** | **80** | **12** | **97** | **109** | **121** | **44** | **45** | **47** | **48** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Kick 8/16, Hihat 1 16/44; slot 17 Hihat 1 7/8; slot 20 Kick 24/38, Hihat 1 41/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 41/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 5 times. Back to Tight for 21-24. Timing: Shake 6. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Hats loop one bar: bar 1 of the book is the classic, and bars 2, 3 and 4 are slots 21-24 variations. The swing is Shake 6, not the grid.

## The builder's own share

46% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 11, 15 | 3, 7, 8, 11, 12, 15 | 3, 7, 11, 15 | 3, 7, 8, 11, 12, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 4, 6, 12, 14.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
