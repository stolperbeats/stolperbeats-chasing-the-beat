# Bank 18: Disco (Philly, Earl Young)

In the manual *Chasing the Beat*: Disco (Philly, Earl Young) (bank 18).

- **Source:** Earl Young style (SuperTime study). Labels: ST (rest OWN).
- **Files:** `PatternBank017.txt` (bank slot 18) or `PatternBank049.txt` (bank slot 50).
- **Tempo:** 112 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight. The study has no swing; the open hat on every + is the lift.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Hihat 2: all on the grid; Perc 1: all on the grid.
- **Other settings:** Shake 2, Tight: only the ghosts on the a swing (e and a +19 ms). Push 3, Tight: the open hats lean late (e, + and a +15 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | ST | 8 |
| Snare | Snare | ST | 6 |
| Hihat 1 | Pedal / closed hat | ST | 4 |
| Hihat 2 | Open hat | ST | 4 |
| Perc 1 | Ghost snare (quiet) | ST | 2 |
| Perc 2 | Tambourine | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . x . . . x . . . x . . .
Bar 2   x . . . x . . . x . . . x . . .
Bar 3   x . . . x . . . x . . . x . . .
Bar 4   x . . . x . . . x . . . x . . .
```

**Snare** (slot 6, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . x x
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . x x
```

**Hihat 1** (slot 4, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . . . x . . . x . . . x . . .
```

**Hihat 2** (slot 4, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . x . . . x . . . x .
```

**Perc 1** (slot 2, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . . . . . . x . . . . . . . x
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 18 | 20 | 20 | 22 | 24 | 24 | 26 | 28 | 3 | 30 | 32 | 34 | 18 | 18 | 18 | 18 |
| Snare | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 14 | 14 | 16 | 16 | 16 | 17 | 19 | 19 | 19 | 7 | 21 | 22 | 23 | 13 | 14 | 14 | 16 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 2 | 13 | 15 | 16 | 5 | 5 | 5 | 5 |
| Hihat 2 | 1 | 2 | 3 | 4 | 5 | 5 | 5 | 5 | 6 | 6 | 6 | 6 | 6 | 6 | 7 | 7 | 0 | 6 | 7 | 8 | 4 | 4 | 4 | 4 |
| Perc 1 | 1 | 2 | 3 | 3 | 4 | 4 | 5 | 5 | 6 | 7 | 7 | 8 | 8 | 9 | 9 | 10 | 0 | 12 | 14 | 16 | 2 | 3 | 3 | 3 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **23** | **29** | **37** | **41** | **47** | **50** | **55** | **62** | **62** | **66** | **70** | **74** | **78** | **82** | **12** | **92** | **103** | **113** | **44** | **46** | **46** | **48** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Kick 8/16, Hihat 1 16/16 (EMPTIED), Hihat 2 2/16, Perc 1 2/8; slot 17 Hihat 1 7/8; slot 20 Kick 22/34, Hihat 1 35/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 35/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Study default tempo, not a record. Bar 2's ghosts (10, 14) are variation hits on Perc 1.

## The builder's own share

39% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic ST. Added: OWN: 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic ST. Added: OWN: 7, 15 | 3, 7, 11 | 7, 15 | 3, 7, 11, 14 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic ST. Added: OWN: 2, 3, 4, 6, 7, 8, 10, 11, 12, 14, 15, 16.
- **Hihat 2:** classic ST. Added: OWN: 1, 5, 9, 13.
- **Perc 1:** classic ST. Added: ST: 10, 14; OWN: 1, 2, 3, 4, 5, 6, 7, 9, 11, 12, 13, 15.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
