# Bank 26: Planet Rock / electro

In the manual *Chasing the Beat*: Planet Rock / electro (bank 26).

- **Source:** electro hip-hop study (the Planet Rock family, 1982). Labels: ST (rest OWN).
- **Files:** `PatternBank025.txt` (bank slot 26) or `PatternBank057.txt` (bank slot 58).
- **Tempo:** 127 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight: the study says no swing, no drag.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Perc 2: all on the grid.
- **Other settings:** Push 2, Tight: the offbeats sit back (e, + and a +17 ms). Shake 2, Tight: the 16th hats swing lightly (e and a +17 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | ST | 7 |
| Snare | Snare / clap | ST | 4 |
| Hihat 1 | Closed hat | ST | 20 (already at the module's limit) |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Clap (doubles) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Cowbell | ST | 3 |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 7, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . x . . . x . . . . .
Bar 2   x . . x . . x . . . x . . . . .
Bar 3   x . . . . . x . . . x . . . . .
Bar 4   x . . x . . x . . . x . . . . .
```

**Snare** (slot 4, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 20, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x x x x x x x x x x x x x x x x
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2** (slot 3, ST):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . . . x . . x . . . . .
```

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 16 | 18 | 20 | 20 | 22 | 24 | 24 | 25 | 3 | 29 | 31 | 32 | 16 | 16 | 16 | 16 |
| Snare | 2 | 4 | 6 | 8 | 9 | 9 | 11 | 11 | 11 | 13 | 13 | 13 | 14 | 16 | 16 | 16 | 7 | 18 | 20 | 22 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 11 | 12 | 13 | 14 | 2 | 14 | 15 | 16 | 15 | 15 | 15 | 15 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 3 | 4 | 4 | 5 | 5 | 6 | 7 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 0 | 13 | 15 | 16 | 4 | 4 | 4 | 4 |
| **Bank** | **8** | **16** | **22** | **28** | **32** | **36** | **41** | **46** | **49** | **55** | **59** | **61** | **65** | **72** | **74** | **77** | **12** | **90** | **101** | **110** | **50** | **50** | **50** | **50** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 22/64, Perc 2 4/12; slot 17 Hihat 1 7/8; slot 20 Kick 18/32, Hihat 1 36/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 36/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

16th hats are already every 16th, so Hihat 1's classic sits at slot 20. A study, not the record.

## The builder's own share

39% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic ST. Added: OWN: 3, 9, 15 | 3, 5, 9, 13, 15 | 3, 9, 15 | 3, 5, 9, 13, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic ST. Added: OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic ST. Nothing added.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic ST. Added: ST: 15; OWN: 1, 2, 4, 5, 6, 7, 9, 10, 12, 13, 14, 16.
