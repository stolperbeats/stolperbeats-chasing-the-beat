# Bank 12: Afrobeats

In the manual *Chasing the Beat*: Afrobeats (bank 12).

- **Source:** genre grid (archive F8). Labels: ARCHIVE (rest OWN).
- **Files:** `PatternBank011.txt` (bank slot 12) or `PatternBank043.txt` (bank slot 44).
- **Tempo:** 106 BPM.
- **Home setting:** Shake, Shuffle row 2, Feel Tight, Linear off. Why: Shake 2 (57%): the archive's sources want light swing on hats and percussion, not on the kick. Shake never moves 8th-note steps, and this kick sits on 1, the + of 2 and the + of 3, so the kick stays straight while the a's and e's swing.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: a of 1 +20 ms; the rest on the grid; Hihat 1: a of 1 +20 ms, a of 2 +20 ms, a of 3 +20 ms, a of 4 +20 ms; the rest on the grid; Perc 2: e of 2 +20 ms, e of 4 +20 ms; the rest on the grid.
- **Other settings:** Clave 2, Tight: holds the 3-3-2 spots on time and drags the rest (beats 2 and 4 +20 ms; 1, a of 1 and + of 2 held). Shake 5, Tight: 58%, a touch more (e and a +24 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | ARCHIVE | 6 |
| Snare | Rim | ARCHIVE | 4 |
| Hihat 1 | Closed hat | ARCHIVE | 8 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Shaker (dense) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Conga / shaker | ARCHIVE | 4 |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 6, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . x . . . x . . . . .
Bar 2   x . . . . . x . . . x . . . . .
Bar 3   x . . . . . x . . . x . . . . .
Bar 4   x . . . . . x . . . x . . . . .
```

**Snare** (slot 4, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . x . . . . . . . . x . . .
Bar 2   . . . x . . . . . . . . x . . .
Bar 3   . . . x . . . . . . . . x . . .
Bar 4   . . . x . . . . . . . . x . . .
```

**Hihat 1** (slot 8, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x x x . x x x . x x x . x x
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2** (slot 4, ARCHIVE):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . . x . . x . . . . x . . x . .
```

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** nothing; every hit comes and goes.
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Not documented. None documented; the climb is built from the bank's own hits (OWN).


## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 16 | 18 | 20 | 20 | 22 | 24 | 26 | 26 | 3 | 30 | 34 | 36 | 14 | 14 | 14 | 14 |
| Snare | 2 | 4 | 6 | 8 | 10 | 10 | 12 | 14 | 14 | 15 | 17 | 17 | 19 | 21 | 21 | 23 | 2 | 27 | 29 | 31 | 9 | 9 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 6 | 8 | 10 | 12 | 13 | 13 | 13 | 13 | 14 | 14 | 14 | 14 | 2 | 14 | 15 | 16 | 12 | 12 | 14 | 14 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 3 | 4 | 5 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 0 | 13 | 15 | 16 | 5 | 5 | 5 | 5 |
| **Bank** | **8** | **16** | **22** | **28** | **36** | **40** | **47** | **54** | **57** | **62** | **66** | **67** | **73** | **79** | **82** | **85** | **7** | **100** | **113** | **123** | **45** | **45** | **48** | **48** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 20/48, Perc 2 4/16; slot 17 Hihat 1 2/8; slot 20 Kick 24/36, Hihat 1 43/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 43/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 2. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

Genre grid, not one record. The archive's fuller 3+3+2 kick (4, 9, 12, 15 added) and the tresillo rim feed the middle and the variations.

## The builder's own share

39% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic ARCHIVE. Added: ARCHIVE: 4 | 4, 9, 15 | 4 | 4, 9, 15 (bars 1 | 2 | 3 | 4); OWN: 3, 9, 15 | 3, 5, 8, 13 | 3, 9, 15 | 3, 5, 8, 13, 14, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic ARCHIVE. Added: ARCHIVE: - | 7 | - | 7 (bars 1 | 2 | 3 | 4); OWN: 5, 7, 15, 16 | 3, 5, 8, 11, 15, 16 | 5, 7, 15, 16 | 3, 5, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic ARCHIVE. Added: OWN: 2, 6, 10, 14.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic ARCHIVE. Added: OWN: 1, 2, 4, 5, 7, 8, 9, 10, 12, 13, 15, 16.
