# Bank 04: Give It Away

In the manual *Chasing the Beat*: Give It Away (bank 04).

- **Source:** Red Hot Chili Peppers, 1991 (Chad Smith). Labels: BOOK (rest OWN).
- **Files:** `PatternBank003.txt` (bank slot 4) or `PatternBank035.txt` (bank slot 36).
- **Tempo:** 91 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight. The book describes no swing; Chad's kick on the e and + sits locked with Flea.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 2: all on the grid.
- **Other settings:** Push 2, Tight: the open hats and kicks off the beat sit back (e, + and a +24 ms). Shake 2, Tight: rounds the e and a kicks (e and a +24 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 8 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat (not in the book) | OWN | 17 (silent in the source: the drop is the record) |
| Hihat 2 | Open hat | BOOK | 20 (already at the module's limit) |
| Perc 1 | Ghost snare (quiet) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Cowbell | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . x . . x . . x x . . x x .
Bar 2   x . . x . . x . . x x . . x x .
Bar 3   x . . x . . x . . x x . . x x .
Bar 4   x . . x . . x . . x x . . x x .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1:** silent in the source. Slot 17 is empty.

**Hihat 2** (slot 20, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: Chad's later added snares (BOOK p61 text).

- **Snare** B part: 5, 7, 10, 13, 16 | 5, 7, 10, 13, 16 | 5, 7, 10, 13, 16 | 5, 7, 10, 13, 16 (bars 1 | 2 | 3 | 4)

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 8 | 12 | 16 | 20 | 24 | 28 | 29 | 31 | 31 | 33 | 33 | 35 | 35 | 37 | 3 | 39 | 40 | 41 | 30 | 30 | 30 | 30 |
| Snare | 2 | 4 | 6 | 8 | 10 | 10 | 12 | 12 | 13 | 14 | 16 | 18 | 18 | 19 | 21 | 21 | 7 | 20 | 26 | 29 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Hihat 2 | 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 0 | 6 | 7 | 8 | 7 | 7 | 7 | 7 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **15** | **22** | **28** | **37** | **42** | **48** | **55** | **58** | **64** | **66** | **71** | **74** | **77** | **83** | **85** | **10** | **95** | **112** | **126** | **52** | **53** | **53** | **53** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 2 24/32; slot 17 nothing silenced; slot 20 Kick 22/41, Hihat 1 48/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 48/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The open hats already sit on every 8th, the most Hihat 2 can hold with room for Rolls, so Hihat 2's classic is at slot 20 and the build climbs toward it. Chad's later kick 'loosening' isn't transcribed, so the B part changes the snare only.

## The builder's own share

35% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 9 | 3, 5, 9, 13 | 3, 9 | 3, 5, 9, 13, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: BOOK: 7, 10, 16 | 7, 10, 16 | 7, 10, 16 | 7, 10, 16 (bars 1 | 2 | 3 | 4); OWN: 15 | 3, 11, 15 | 15 | 3, 11, 14, 15 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Hihat 2:** classic BOOK. Nothing added.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
