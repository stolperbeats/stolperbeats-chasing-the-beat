# Bank 16: Soul Man

In the manual *Chasing the Beat*: Soul Man (bank 16).

- **Source:** Sam & Dave, 1967 (Al Jackson Jr.). Labels: BOOK (rest OWN).
- **Files:** `PatternBank015.txt` (bank slot 16) or `PatternBank047.txt` (bank slot 48).
- **Tempo:** 112 BPM.
- **Home setting:** Shake, Shuffle row 4, Feel Tight, Linear off. Why: Shake 4 (60%): the book says Al Jackson swings the 16ths on the bass drum. Shake moves exactly the kicks on the a of 2 and the a of 4.
- **What the home setting does to the classic:** Kick: a of 2 +27 ms, a of 4 +27 ms; the rest on the grid; Snare: all on the grid; Hihat 1: all on the grid.
- **Other settings:** Shake 6, Tight: heavier, 62.5% (e and a +33 ms). Shake 3, Tight: 61% (e and a +30 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 8 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 8 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Ghost snare (quiet) | OWN | 17 (silent in the source: the drop is the record) |
| Perc 2 | Tambourine | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . . . . . x x . x . . . . x
Bar 2   x . . . . . . x x . x . . . . x
Bar 3   x . . . . . . x x . x . . . . x
Bar 4   x . . . . . . x x . x . . . . x
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1:** silent in the source. Slot 17 is empty.

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the bridge at 0:34: kick on every 8th (BOOK p124).

- **Kick** B part: 1, 3, 5, 7, 9, 11, 13, 15 | 1, 3, 5, 7, 9, 11, 13, 15 | 1, 3, 5, 7, 9, 11, 13, 15 | 1, 3, 5, 7, 9, 11, 13, 15 (bars 1 | 2 | 3 | 4)

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 16 | 20 | 23 | 23 | 25 | 27 | 29 | 31 | 31 | 33 | 3 | 32 | 38 | 41 | 22 | 22 | 22 | 22 |
| Snare | 2 | 4 | 6 | 8 | 10 | 10 | 12 | 12 | 13 | 15 | 15 | 15 | 17 | 17 | 19 | 19 | 7 | 23 | 25 | 27 | 9 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 12 | 12 | 13 | 2 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **21** | **26** | **33** | **36** | **43** | **50** | **56** | **60** | **63** | **65** | **72** | **76** | **80** | **83** | **12** | **95** | **111** | **124** | **47** | **48** | **48** | **48** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 20/32; slot 17 Hihat 1 7/8; slot 20 Kick 27/41, Hihat 1 41/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 41/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 6 times. Back to Tight for 21-24. Timing: Shake 4. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

B part = the bridge kick on every 8th, doubling the bass.

## The builder's own share

37% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: BOOK: 3, 5, 7, 13, 15 | 3, 5, 7, 13, 15 | 3, 5, 7, 13, 15 | 3, 5, 7, 13, 15 (bars 1 | 2 | 3 | 4); OWN: - | - | - | 14 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: OWN: 7, 15, 16 | 3, 7, 8, 11, 15, 16 | 7, 15, 16 | 3, 7, 8, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 16.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
