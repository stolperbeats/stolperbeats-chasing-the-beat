# Bank 19: Like I Love You

In the manual *Chasing the Beat*: Like I Love You (bank 19).

- **Source:** Justin Timberlake, 2002 (Pharrell Williams). Labels: BOOK (rest OWN).
- **Files:** `PatternBank018.txt` (bank slot 19) or `PatternBank050.txt` (bank slot 51).
- **Tempo:** 115 BPM.
- **Home setting:** Shake, Shuffle row 1, Feel Tight, Linear off. Why: Straight. The book describes no swing.
- **What the home setting does to the classic:** Kick: all on the grid; Snare: all on the grid; Hihat 1: all on the grid; Perc 1: all on the grid.
- **Other settings:** Shake 4, Tight: more swing (e and a +26 ms). Shake 2, Tight: the ghosts and the a-of-1 kick swing lightly (e and a +19 ms).
- **Triplet grid:** no.

## Tracks

| Track | Sound to patch | Classic from | Classic at knob |
|---|---|---|---|
| Kick | Kick | BOOK | 8 |
| Snare | Snare | BOOK | 4 |
| Hihat 1 | Closed hat | BOOK | 8 |
| Hihat 2 | Open hat | OWN | 17 (silent in the source: the drop is the record) |
| Perc 1 | Ghost snare (quiet) | BOOK | 4 |
| Perc 2 | Hat accent (the loud beats) | OWN | 17 (silent in the source: the drop is the record) |

## The classic, drawn

`x` = hit, `.` = rest. Steps run 1 to 16; `e + a` are the 16ths between the beats.

**Kick** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   x . . x . . . . . . x . . x . .
Bar 2   x . . x . . . . . . x . . x . .
Bar 3   x . . x . . . . . . x . . x . .
Bar 4   x . . x . . . . . . x . . x . .
```

**Snare** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Bar 1   . . . . x . . . . . . . x . . .
Bar 2   . . . . x . . . . . . . x . . .
Bar 3   . . . . x . . . . . . . x . . .
Bar 4   . . . . x . . . . . . . x . . .
```

**Hihat 1** (slot 8, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   x . x . x . x . x . x . x . x .
```

**Hihat 2:** silent in the source. Slot 17 is empty.

**Perc 1** (slot 4, BOOK):

```
        1 e + a 2 e + a 3 e + a 4 e + a
Every   . x . . . . . x . x . . . . . x
```

**Perc 2:** silent in the source. Slot 17 is empty.

## What never changes

Hits that play in all 24 slots of the track (read from the card file).

- **Kick:** 1 | - | 1 | - (bars 1 | 2 | 3 | 4)
- **Snare:** 5 | - | 5 | - (bars 1 | 2 | 3 | 4)
- **Hihat 1:** nothing; every hit comes and goes.
- **Hihat 2:** nothing; every hit comes and goes.
- **Perc 1:** nothing; every hit comes and goes.
- **Perc 2:** nothing; every hit comes and goes.

## B part (slots 18 to 20)

Documented: the 0:31 variation, used loosely (BOOK p82).

- **Snare** B part: 5, 8, 13 | 5, 8, 13 | 5, 8, 13 | 5, 8, 13 (bars 1 | 2 | 3 | 4)
- **Perc 1** B part: 2, 16

## Hits per slot

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Kick | 2 | 4 | 6 | 8 | 10 | 12 | 14 | 16 | 19 | 19 | 21 | 23 | 25 | 27 | 27 | 29 | 3 | 33 | 35 | 37 | 17 | 18 | 18 | 18 |
| Snare | 2 | 4 | 6 | 8 | 10 | 10 | 12 | 12 | 14 | 14 | 14 | 15 | 16 | 18 | 18 | 20 | 7 | 12 | 20 | 26 | 10 | 10 | 10 | 10 |
| Hihat 1 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 9 | 10 | 10 | 11 | 12 | 12 | 13 | 2 | 14 | 15 | 16 | 9 | 9 | 9 | 9 |
| Hihat 2 | 1 | 2 | 2 | 2 | 2 | 2 | 2 | 2 | 3 | 3 | 3 | 3 | 3 | 4 | 4 | 4 | 0 | 6 | 7 | 8 | 3 | 3 | 3 | 3 |
| Perc 1 | 1 | 2 | 3 | 4 | 5 | 5 | 6 | 6 | 7 | 8 | 8 | 9 | 9 | 10 | 10 | 11 | 0 | 2 | 9 | 16 | 5 | 5 | 5 | 5 |
| Perc 2 | 1 | 2 | 2 | 2 | 3 | 3 | 3 | 4 | 4 | 5 | 5 | 5 | 6 | 6 | 7 | 7 | 0 | 10 | 13 | 16 | 2 | 2 | 2 | 2 |
| **Bank** | **8** | **16** | **22** | **28** | **35** | **38** | **44** | **48** | **56** | **58** | **61** | **65** | **70** | **77** | **78** | **84** | **12** | **77** | **99** | **119** | **46** | **47** | **47** | **47** |

## Linear

Keep Linear off for the climb: at slot 20 it empties Hihat 2, Perc 1. Hits Linear would silence (silenced/total over 4 bars): classic Hihat 1 16/32; slot 17 Hihat 1 7/8; slot 20 Kick 18/37, Hihat 1 45/64, Hihat 2 32/32 (EMPTIED), Perc 1 64/64 (EMPTIED), Perc 2 45/64.

## Rolls at 20

Flip Feel to Rolls at slot 20: each Hihat 2 hit plays 4 times. Back to Tight for 21-24. Timing: Shake 1. Hihat 2 steps at slot 20: 1, 3, 5, 7, 9, 11, 13, 15.

## What the module can't hold

The loud hats on the beats can't be louder: Perc 2 is an OWN hat accent on the beats if wanted. The B part is used loosely, as the book says.

## The builder's own share

40% of all hits across the 24 slots are OWN (the builder's programming, not the record).

## Source labels per track

The classic's label, then every hit added outside the classic, by label. See `the-arc.md`, "Source labels".

- **Kick:** classic BOOK. Added: OWN: 3, 7, 9, 15 | 3, 5, 7, 9, 13, 15 | 3, 7, 9, 15 | 3, 5, 7, 9, 13, 15, 16 (bars 1 | 2 | 3 | 4).
- **Snare:** classic BOOK. Added: BOOK: 8 | 8 | 8 | 8 (bars 1 | 2 | 3 | 4); OWN: 7, 15 | 3, 7, 11, 15 | 7, 15 | 3, 7, 11, 14, 15, 16 (bars 1 | 2 | 3 | 4).
- **Hihat 1:** classic BOOK. Added: OWN: 2, 4, 6, 8, 10, 12, 14, 16.
- **Hihat 2:** classic OWN. Added: OWN: 1, 3, 5, 7, 9, 11, 13, 15.
- **Perc 1:** classic BOOK. Added: OWN: 1, 3, 4, 5, 6, 7, 9, 11, 12, 13, 14, 15.
- **Perc 2:** classic OWN. Added: OWN: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16.
