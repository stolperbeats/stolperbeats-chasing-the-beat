# The arc: how every bank was built

This is the method. Every one of the 32 banks was built this way, track by track, and every bank you build should be too. The code that does it is `tools/lf_build.py`; this file says the same thing in words. `worked-example.md` walks one bank through it slot by slot.

## Words used here

- **Slot:** one of the 24 knob positions of a track (1 to 24). See `module.md`.
- **Hit:** one step set to 1.
- **The classic:** the famous part of the groove for one track, exactly as the source gives it. The record's kick, the record's hats, and so on.
- **The classic's knob:** the slot where the classic sits, whole and unchanged.
- **Peak:** slot 20, the busiest pattern of the track.
- **B part:** a second section of the same song that a source writes down (a chorus beat, a bridge). Only some grooves have one.
- **Vocabulary:** hits the source itself offers beyond the classic: its other bars, its documented variations, its fills. They're used before any invented hit.
- **OWN:** a hit the builder invented, in the style, because no source gives it. Always labelled.
- **Unit:** for Kick and Snare, a new hit is usually added to two bars at once: bars 2 and 4 together, or bars 1 and 3 together. That pair is one unit. On a 1-bar track a unit is one hit.

## The shape

Every track of every bank follows the same shape across the 24 slots:

```
hits
 ^                                                    20
 |                                                 19  *
 |                                              18 *
 |                     .  .  .  .  .  16                21 22 23 24
 |              classic                *                  *  *  *  *
 |        .  .  *
 |  1  .
 |  *                                     17
 |                                         *
 +--------------------------------------------------------------> slot
   1 ... build-up ... classic ... middle ... 16 | 17 drop | 18 19 climb | 20 peak | 21-24 variations
```

- **1 to the classic:** build-up. Thinnest at 1.
- **Classic to 16:** the middle. Never thinner, slowly busier.
- **17:** the drop. Very stripped back.
- **18 and 19:** big jumps up, into the B part if there is one.
- **20:** the peak. As dense as the module allows.
- **21 to 24:** variations on the classic. About as busy as the classic. They don't thin out.

Two rules hold on every track at every slot:
- **All 24 patterns of a track are different.** No two slots repeat.
- **Kick and Snare: bars 1 and 3 always match** (except where the source itself has a different bar, like a bar-4 fill). New hits go into bars 2 and 4 first: that's the answer, and bar 4 is where a pickup goes.

## Step 0: gather the groove

Before writing anything, write down for each of the six tracks:

1. **The classic**, with its source label (see "Source labels" below). If the source has no part for this track (a record with no hats, say), the classic is silence. That's fine; see "Tracks the record leaves silent".
2. **The sound to patch** (closed hat, clap, cowbell...).
3. **The vocabulary:** the source's other bars and variations, in order of how much they belong.
4. **The B part**, if a source documents one.
5. **The home setting:** tempo, Timing, Shuffle row, Feel (see `timing.md`).

Lay the tracks out the way the module wants (`module.md`): closed hat on Hihat 1, open hat on Hihat 2, the dense perc on Perc 1 and the sparse important one on Perc 2. Hihat 2 is the Rolls track, so give it a sound that works as a burst (open hat, shaker, a snare for a press roll).

## Step 1: work out the peak (slot 20) first

You need the peak to know how far the middle climbs. The peak is **the classic, plus the B part, plus the vocabulary, plus**:

| Track | Added at the peak |
|---|---|
| Kick | every 8th (steps 1, 3, 5 ... 15). In bars 1 and 3, leave off the backbeat steps 5 and 13; bars 2 and 4 keep them. Bar 4 adds the 16th pickup (steps 14 and 16). |
| Snare | the backbeat (5, 13) plus the 8th offbeats around it (7, 15) in bars 1 and 3; in bars 2 and 4 also 3 and 11; bar 4 adds the pickup 14 and 16. |
| Hihat 1 | every 16th (all 16 steps) |
| Hihat 2 | every 8th (1, 3, 5 ... 15), never every 16th: Rolls needs the gaps |
| Perc 1, Perc 2 | every 16th |

Kick and snare stop short of every 16th, because a solid 16th kick or snare is a buzz, not a groove.

- **Swung banks** (a Shake row of 2 or more) also add the a of 2 (step 8) to kick bars 2 and 4 and to snare bars 2 and 4, and step 16 to the snare.
- **Triplet banks** (see below): the peak is every triplet step (steps 1 and 3 of each beat) on every track, nothing else.

## Step 2: the build-up, slot 1 to the classic

The classic's own hits arrive a few at a time. Nothing invented here: the build-up is the record.

Order the classic's hits like this, and add them in that order:

1. **Beats first** (steps 1, 5, 9, 13), strongest first: 1, then 9, then 5, then 13.
2. **Then the +** (3, 7, 11, 15).
3. **Then the a** (4, 8, 12, 16).
4. **Then the e** (2, 6, 10, 14).
5. On Kick and Snare: **bars 1 and 3 before bars 2 and 4.** So slot 1 of a kick is often the downbeat in bars 1 and 3 only.

Split the hits evenly over **at most 8 slots**. A track with few hits reaches its classic sooner (a snare backbeat of 8 hits arrives by slot 4; a hat of 4 hits by slot 4). **The classic's knob is the slot where the last hit lands.** Slot 1 is the thinnest pattern in the track.

Example (Blue Monday's closed hat, classic of 11 hits on 3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16): slot 1 = 9; 2 = 5, 9; 3 = 5, 9, 13; 4 adds 3; 5 adds 7; 6 adds 11 and 15; 7 adds 4 and 8; 8 adds 12 and 16 = the classic.

## Step 3: the middle, classic to slot 16

From the classic, each slot **adds a hit** (or a unit), or **keeps the count with one added hit moved** to a new step. Never thinner than the slot before.

- **How far:** by slot 16, a sourced track has climbed about **60% of the way** from the classic to the peak. A track with no source part climbs about **40%**. Stop at least 3 hits short of the peak. Spread the climb evenly over the slots.
- **What to add, in order:**
  1. The **vocabulary** (the source's own other hits).
  2. Then **OWN** hits, in timing order: in **straight** banks the 8ths first (beats, then the +), then the a, then the e. In **swung** banks the a and the e first (that's where Shake's swing lives), then the beats and the +. See `timing.md`, "Where added hits go".
  3. Among steps of the same kind, strongest beat first: 1, 9, 5, 13.
- **Where:** on Kick and Snare, **bars 2 and 4 first** (the answer), then **bar 4 alone** (the pickup), then **bars 1 and 3 together**. Never bar 1 or bar 3 alone.
- **Hold back the B part.** Hits that belong to the B part are saved for slot 18, so the climb lands fresh. Use them in the middle only if nothing else is left.
- **Keep every slot different.** If adding would repeat an earlier slot, move one added hit to an unused step instead.

**Straight 8th banks and 16ths.** If a straight bank's hats are already on every 8th, the middle can only get busier with 16ths. That's allowed (they sit dead on the grid on Shake row 1). Kick, snare and Hihat 2 still prefer 8ths.

## Step 4: the drop, slot 17

Very stripped back. A notable hole in the bank.

| Track | At 17 |
|---|---|
| Kick | beat 1 only (in every bar, or bars 1 to 3 with bar 4 empty, or bars 1 and 3) |
| Snare | the anchor: the backbeat (2 and 4) or the style's own anchor hit, sometimes thinned in bar 4 |
| Hihat 1 | quarters (1, 5, 9, 13) or less |
| Hihat 2 | empty, or one hit. Never more, so Rolls left on can't fill the drop. |
| Perc 1, Perc 2 | empty, or one hit |

Slot 17 must be thinner than slot 16 and different from every other slot. On Kick and Snare bars 1 and 3 still match.

## Step 5: the climb, slots 18 and 19

- **18:** if the source documents a **B part** for this track, slot 18 **is** the B part. If the B part as written is thinner than 17, or equals an earlier slot, add a hit or two (from the peak's hits) until it's new. If there's no B part: **slot 16 plus about a third of the gap to the peak**, at most 2 hits short of the peak.
- **19:** **half the remaining way** from 18 to the peak, built by adding the peak's hits in the timing order of step 3. Always below the peak.

These are big jumps on purpose. 17 to 18 to 19 to 20 should feel like a lift.

## Step 6: the peak, slot 20

Slot 20 is exactly the peak from step 1. Hihat 2 on 8ths, so the user can flip Feel to Rolls here (see `timing.md`).

## Step 7: the variations, slots 21 to 24

Classic variations. They don't thin out and they don't climb much.

1. **The source's own other bars first** (a record's second hat bar, a documented variation).
2. Then **the classic plus one or two hits** from the vocabulary, then from the B part, then OWN hits (timing order of step 3).
3. Last resort: one of the classic's own hits moves to a new step.

Each is **about as busy as the classic**: at least its hit count, at most about a third more (at least 4 more hits of room on Kick and Snare, 2 on the 1-bar tracks). Put the four in **rising order** of hits. All different from every other slot. On Kick and Snare bars 1 and 3 match.

## Special cases

### Tracks at the module's limit (classic at 20)

Some classics are already as dense as the track can be: every 16th, or every 8th on Hihat 2, or every triplet step in a triplet bank. They can't get busier, so **the classic is the peak and sits at slot 20**. Slots 1 to 16 climb toward it (the classic with hits missing, more and more of them filled in). 21 to 24 are the classic with one hit out. Seven tracks on the card work this way: Give It Away Hihat 2, Dembow Perc 1, New jack swing Hihat 1, Planet Rock Hihat 1, Jungle Perc 1, Rock Around The Clock Hihat 1, Sing, Sing, Sing Perc 1.

### Tracks the record leaves silent (classic 17)

If the source has no part for a track (no hats on the record, no percussion), the record's part is **silence**. Then:
- **Slot 1 is one OWN hit** (or one vocabulary hit if there is one).
- The middle climbs from there, more gently (40%).
- **Slot 17, the drop, is silent.** That is the record. List the classic's knob as 17.
- Every hit on the track is OWN (or from the B part) and labelled.

### Swung banks

A bank whose home setting is a Shake row of 2 or more is swung. Shake only moves the e and the a (`timing.md`). So added hits go on **the a and the e first**: that's where the swing can be heard. The peak adds the a of 2 to kick and snare.

### Triplet (shuffle) banks

Swing on the 8th notes, like rock'n'roll or swing jazz, uses **Trip row 5** and **steps 1 and 3 of each beat only** (1, 3, 5, 7, 9, 11, 13, 15). Step 3 lands exactly on the last triplet there. **Never put a hit on step 2 or 4 of a beat** in a triplet bank, in any slot: they don't land on a triplet and turn the shuffle wonky. Peak density comes from more tracks on the triplet steps, plus Rolls on Hihat 2.

### A groove with its own song order

If a source transcribes several sections of one song, the bank can follow the song instead: one bank on the card (03, Killing In The Name) runs intro 1-6, verse 7, main beat (the classic) at 9, variations to 16, the verse stripped to kick and snare at 17, the documented second section 18-20, main-beat variations 21-24. Its slot 7 is thinner than 6 because the song's verse is thinner than its intro. Only do this when the sections are documented.

## Source labels

Every hit is either the source's or the builder's, and the files say which. The labels used on the card:

| Label | What it means |
|---|---|
| **BOOK** | A figure in the drum book *The Greatest Drum Beats*, read by eye. Cited by page (e.g. "BOOK p27"). |
| **AINSWORTH** | A published transcription with measured timing: Patrick Ainsworth, "Microtiming in Early Funk" (2025). |
| **MT-40X** | The MT-40X project's transcription of the Casio MT-40 "rock" preset (the Sleng Teng riddim). |
| **ST** | SuperTime Ultra practice studies. The site says they are written for practice, not transcribed from records. |
| **ARCHIVE** | Researched genre grids from an earlier archive of style studies. Bank 28's techno study is credited to CrimethInc. |
| **ARTICLES** | Magazine and encyclopedia descriptions of a groove, with no transcription (bank 25, I Feel Love: kick and offbeat hat). |
| **OWN** | The builder's own programming, in the style. Not the record. |

**Why every invented hit is labelled.** The banks are named after records. A user who turns to slot 20 of "Billie Jean" should know that slot 20 is not on the record. So the card never presents OWN programming as the record: the build-up and the classic are the source's hits; most of the middle, the climb, the peak and the variations are OWN, and each bank page says how much (from 30% to 63% of all hits on this card).

When you build a bank, **label your own hits OWN** in the same way, and the source's hits with the source. If you work from a source the user gives you, name it. If you work from memory of a record, say so plainly in your note: that's not a transcription. The file itself can't hold labels; they go in your note to the user, per track.

## Checklist for a finished bank

- [ ] `tools/validate.py` passes.
- [ ] `tools/check_arc.py` shows no FAIL (WARN lines explained in your note).
- [ ] Every track has 24 different patterns.
- [ ] Slot 1 is the thinnest of 1 to 16 on every track.
- [ ] The classic sits whole at its knob (at most 8; 17 for silent tracks; 20 at the limit; bank 03 uses 9 by its song order).
- [ ] 1 to 16 never get thinner (one documented exception per song order, like bank 03).
- [ ] 17 is the thinnest of 17 to 24; Hihat 2 has at most one hit there.
- [ ] 18 < 19 < 20 in hits; 20 is the busiest slot of the track.
- [ ] Hihat 2 at 20 is on 8ths (or the triplet steps).
- [ ] 21 to 24 are about as busy as the classic, rising.
- [ ] Kick and Snare: bars 1 and 3 match.
- [ ] Triplet banks: nothing on steps 2 or 4 of any beat.
- [ ] Every hit not from a source is labelled OWN in your note.
