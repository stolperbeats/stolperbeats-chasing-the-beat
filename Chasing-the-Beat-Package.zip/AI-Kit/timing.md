# Timing: where each step really lands

The pattern file says which steps play. Three global settings on the module say **when** each step plays: Timing, Shuffle row and Feel. They aren't in the file (`module.md`), but they change how a pattern feels, so you choose a home setting for every bank you build and tell the user.

The numbers here are worked out from the firmware 163 timing tables in `tools/hw.py`. The plain-words descriptions come from the module's manual and the build's timing research.

## The three settings

- **Timing**: four buttons, in the module's own words **Trip**, **Shake**, **Push** and **Clave**. Each is a different way of moving the steps inside a beat.
- **Shuffle row**: 1 to 7, how hard the Timing moves them. **Row 1 is dead straight in every Timing.** Lower rows move more, but not in strict order.
- **Feel**: **Tight**, **Rolls**, **Flam** or **Slop** (press the Timing button again to step through them).

## What each Timing does to the e, the + and the a

Reminder (`module.md`): in each beat, step 1 is the beat, then the **e**, the **+** and the **a**. The beat itself never moves (in every Timing but Clave, where beats 2 and 4 drift late).

| Timing | In plain words | The e | The + | The a |
|---|---|---|---|---|
| **Shake** | Classic drum-machine 16th swing. Swings only the e and the a. | late | **never moves** | late |
| **Push** | Lays every offbeat back by the same small amount. Beats stand out. | late | late | late |
| **Trip** | A wonky, tripping shuffle that moves the 8ths. | early on rows 3-7, late on 2 | late | late |
| **Clave** | Works on the half bar: steps 1, 4, 7 (and 9, 12, 15) stay on time, the rest drifts late. | late | late (except 7 and 15) | on time on 4 and 12 |

The module's manual gives a one-line description of each button (*Stolperbeats – Manual*, PDF page 1, "Timing and Feeling"), and calls the Feel settings "Feelings". In short: Trip trips over itself, Shake is hip-hop swing, Push makes room for the downbeats, Clave holds the 3-3-2.

**The one thing to remember about Shake:** the + never moves. A part made only of 8th notes (beats and +) sounds exactly the same on every Shake row. Only 16th hits (the e and the a) swing. That's why straight-8th rock banks can sit on any Shake row and stay straight.

### In milliseconds

How late each step lands against a straight grid. Negative = earlier than a straight 16th (only Trip's e does this; it's still after the beat). Beat 1 of each pair is always 0.

**Shake** (e and a only; the + is always 0):

| Row | Swing | e and a at 90 BPM | at 120 BPM | at 140 BPM |
|---|---|---|---|---|
| 1 | straight | 0 | 0 | 0 |
| 2 | 57% | +24 ms | +18 ms | +15 ms |
| 3 | 61% | +37 ms | +28 ms | +24 ms |
| 4 | 60% | +33 ms | +25 ms | +21 ms |
| 5 | 58% | +28 ms | +21 ms | +18 ms |
| 6 | 62.5% | +42 ms | +31 ms | +27 ms |
| 7 | 67% (full triplet swing) | +56 ms | +42 ms | +36 ms |

"Swing" is where the swung 8th pair splits: 50% is straight, 67% is a full triplet.

**Push** (e, + and a all move the same):

| Row | e, + and a at 90 BPM | at 120 BPM | at 140 BPM |
|---|---|---|---|
| 2 | +24 ms | +18 ms | +15 ms |
| 3 | +19 ms | +14 ms | +12 ms |
| 4 | +33 ms | +25 ms | +21 ms |
| 5 | +28 ms | +21 ms | +18 ms |
| 6 | +42 ms | +31 ms | +27 ms |
| 7 | +37 ms | +28 ms | +24 ms |

**Trip** (e / + / a, at 120 BPM; scale by 120 ÷ tempo for other tempos):

| Row | e | + | a | Note |
|---|---|---|---|---|
| 2 | +18 | +36 | +54 | everything after the beat shoved late; the a crowds the next beat |
| 3 | -14 | +28 | +14 | |
| 4 | -25 | +50 | +25 | |
| 5 | -42 | +83 | +42 | **the + lands exactly on the last triplet (67%)** |
| 6 | -62 | +62 | +62 | |
| 7 | -69 | +83 | +69 | the + on the last triplet too |

**Clave** (at 120 BPM): row 2 moves the e +18, the + +36, beat 2 +18 ms; row 3 the + +56 ms; row 4 the + +50, beat 2 +25 ms. Steps 1, 4 and 7 of each half bar stay on time: the 3-3-2.

### Feel

| Feel | What it does | Use |
|---|---|---|
| **Tight** | All six tracks on the timing grid. | Home for every bank on this card. |
| **Rolls** | After every Hihat 2 hit, Hihat 2 re-fires until the next step. On Shuffle rows 1 and 4 it re-fires every tick: 4 hits per step on a straight grid. On other rows every second tick: 2 to 6 hits, depending on the step. | The peak, slot 20. Flip back to Tight for 21. |
| **Flam** | Kick and snare fire one tick late (one tick is 1/16 to 1/36 of a beat: about 14 to 31 ms at 120 BPM). | The module's lean-back sound. |
| **Slop** | Like Flam, and the hats that land with kick or snare are late too. | Lean-back, looser. |

**Nothing here makes a beat early.** Every Feel but Tight makes drums later. So these settings can make a groove lean back, never push forward.

## How the card chose each home setting

1. **Feel is Tight** in every bank. Flam and Slop drag; this card drives.
2. **Swing only where a source asks for it.** Machine records are straight. Measured funk breaks are lighter than people think: Cold Sweat is almost straight (swing ratio about 1.07:1, Ainsworth 2025).
3. **16th swing = Shake. 8th-note triplet swing = Trip 5.** Funk swings the 16ths; jazz and rock'n'roll swing the 8ths (Ethan Hein's swing primer). Shake can't swing 8ths at all.
4. **Fast swing is lighter swing.** Friberg and Sundström (2002) found the short swung note stays near 100 ms at fast tempos. Trip 5 gives 112 ms at 178 BPM and 93 ms at 216.
5. **A bank that doesn't need Trip starts on Shake.** Straight banks sit on Shake row 1 (B.'s rule). Row 1 is straight in every Timing, so it sounds the same, but the user starts on the Shake button.
6. **Clave** is the "also try" for 3-3-2 grooves (dembow, Sleng Teng): it holds exactly those steps on time.

The result on this card: **Shake 1** (dead straight) in 19 banks, a **Shake row 2 to 6** in 11 banks where a source asks for 16th swing, **Trip 5** in the 2 triplet banks.

| # | Bank | BPM | Home | Also try | Why (from the bank facts) |
|---|---|---|---|---|---|
| 01 | We Will Rock You | 81 | Shake 1, Tight | Push 3 | Straight. Stamps and claps, no swing in the book. |
| 02 | Sleng Teng (MT-40 Rock) | 82 | Shake 1, Tight | Shake 2; Clave 2 | Straight, like the Casio preset it came from. |
| 03 | Killing In The Name | 89 | Shake 2, Tight; **Shake 4 from slot 18** | Push 2 | The book says the whole song carries a light 16th swing; the 8th parts stay on the grid. Row 4 for the swung section at 18. |
| 04 | Give It Away | 91 | Shake 1, Tight | Push 2; Shake 2 | Straight. The book describes no swing. |
| 05 | Go-go (Bustin' Loose) | 92 | Shake 6, Tight | Shake 4; Shake 7 | SuperTime's go-go study is hard-swung at 62%. |
| 06 | Back In Black | 94 | Shake 1, Tight | Push 3 | Straight 8ths, no 16ths to swing. |
| 07 | Dembow | 96 | Shake 1, Tight | Clave 3; Clave 2 | Straight: quantised hard; the groove is where the snare sits. |
| 08 | Superstition | 100 | Shake 6, Tight | Shake 3; Shake 7 | Ethan Hein measured heavy 16th swing on the opening bars. |
| 09 | Lust For Life | 102 | Shake 1, Tight | Push 3 | Straight. Quarter-note hats and a walking kick. |
| 10 | Rock Steady | 104 | Shake 2, Tight | Shake 4; Push 2 | A light percolation on the ghosts and the a-of-2 kick. |
| 11 | Ain't Nobody | 104 | Shake 1, Tight | Trip 2; Shake 2 | Straight; played against a drum-machine part. |
| 12 | Afrobeats | 106 | Shake 2, Tight | Clave 2; Shake 5 | Light swing on hats and percussion; the kick is on 8ths, so it stays straight. |
| 13 | New jack swing | 106 | Shake 6, Tight | Shake 3; Shake 7 | SuperTime's study sits at 64%, between rows 6 and 7. |
| 14 | Pick Up The Pieces | 107 | Shake 3, Tight | Push 2; Shake 4 | The book calls it nimble jazz-funk swing. |
| 15 | Sex Machine | 107 | Shake 6, Tight | Shake 7; Shake 6 with Flam | Ainsworth measures the a-of-2 hat and e-of-3 ghost late; Shake 6 puts them 35 ms late. |
| 16 | Soul Man | 112 | Shake 4, Tight | Shake 6; Shake 3 | The book says the 16ths on the bass drum swing. |
| 17 | Cold Sweat | 112 | Shake 1, Tight | Push 3; Push 2 | Measured almost straight (1.07:1). |
| 18 | Disco (Philly, Earl Young) | 112 | Shake 1, Tight | Shake 2; Push 3 | Straight; the open hat on every + is the lift. |
| 19 | Like I Love You | 115 | Shake 1, Tight | Shake 4; Shake 2 | Straight. The book describes no swing. |
| 20 | Word Up | 116 | Shake 1, Tight | Push 3 | Straight: computer-driven. |
| 21 | Billie Jean | 117 | Shake 1, Tight | Push 3 | Straight: drum machine plus drummer, no swing. |
| 22 | Smells Like Teen Spirit | 117 | Shake 1, Tight | Push 2; Shake 2 | Straight. |
| 23 | Apache | 118 | Shake 1, Tight | Shake 2; Push 3 | Straight by the Shake rule; the record leans late more than it swings (Push). |
| 24 | Chicago house | 124 | Shake 2, Tight | Shake 4; Shake 5 | SuperTime's jack-house study is 56%; the closed-hat shuffle makes it jack. |
| 25 | I Feel Love | 126.5 | Shake 1, Tight | Shake 2; Push 3 | Straight: sequenced. |
| 26 | Planet Rock / electro | 127 | Shake 1, Tight | Push 2; Shake 2 | Straight: no swing, no drag. |
| 27 | Blue Monday | 130 | Shake 1, Tight | Push 3 | Straight: a drum machine. |
| 28 | Detroit techno | 134 | Shake 1, Tight | Shake 2; Push 4 | Zero swing; variation comes from sound, not timing. |
| 29 | Motorik | 136 | Shake 1, Tight | Push 3 | Straight: the trance is the repetition. |
| 30 | Jungle (Think break) | 165 | Shake 2, Tight | Shake 1; Shake 4 | The break's e ghosts sit a little late with the + on time; Shake 2 keeps that ratio at jungle tempo. |
| 31 | Rock Around The Clock | 178 | Trip 5, Tight | Trip 2; Trip 4 | The shuffle is the first and third triplet; Trip 5 puts the + on the last triplet. Short note 112 ms. |
| 32 | Sing, Sing, Sing | 216 | Trip 5, Tight | Trip 2; Trip 4 | Swing 8ths at 216; short note 93 ms. |

Every bank page in `banks/` has the full reason and what each "also try" does in ms.

## Where added hits go

When the arc adds hits that no source gives (OWN hits), the home setting decides where they go. These are the build's rules:

1. **Feel is Tight in the home setting.** Offer Flam only where a source asks for a late backbeat.
2. **Hihat 2 is the Rolls track.** Empty or one hit at 17. On 8ths (or quarters) at 20, never every 16th.
3. **Linear-safe stacking.** Dense perc on Perc 1, sparse and important on Perc 2. Open hat on Hihat 2, closed on Hihat 1.
4. **Swung banks add on the a and the e first; straight banks add on 8ths first.** Under Shake, swing lives only on the e and the a, so in a swung bank that's where new hits make the swing heard. In a straight 8th bank, keep added hits on 8ths as long as you can (kick, snare and Hihat 2 always; the busier hats and percs may go to 16ths once the 8ths are full).
5. **Triplet banks use steps 1 and 3 of each beat only**, in every slot. On Trip 5, step 2 lands at 17% and step 4 at 83% of the beat: neither is a triplet.
6. **The home setting is part of the bank.** Say it in your note: Timing, Shuffle row, Feel, and any change inside the bank (like bank 03's row change at 18).

## Choosing a home setting for a new bank

- **Machine-made or straight record:** Shake 1, Tight.
- **16th-swung style** (funk, go-go, new jack swing, jack house, UK garage-style shuffled hats): a Shake row. Match a measured swing if a source gives one (row 2 = 57%, 5 = 58%, 4 = 60%, 3 = 61%, 6 = 62.5%, 7 = 67%). Then put the swung hits on the e and the a.
- **8th-note triplet swing** (shuffle, swing jazz, rock'n'roll): Trip 5, steps 1 and 3 only.
- **3-3-2 grooves:** Shake 1 at home, Clave 2 or 3 as the also-try.
- **Wants weight without swing:** offer Push 2 or 3 as the also-try.
- **Fast tempo:** lighter swing. Check the short note stays near 100 ms or more.
- **Wants to lean back** (Flam or Slop at home, a dragging or behind-the-beat feel): that's a different way of building. Read `laid-back/LAID-BACK.md` first.
