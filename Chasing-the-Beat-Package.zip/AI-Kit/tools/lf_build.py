"""Lean-forward pack, Build-1: plans every track's 24-slot arc and writes both card folders.
Run from this folder:  python3 -B lf_build.py
Writes into tools/build-output/: 'Card Files - Slots 1-32/', 'Card Files - Slots 33-64/', bank-index.json.

The arc (../the-arc.md):
  1..classic   build-up: the classic's own hits arrive one unit at a time (beat, +, a, e; bars 1&3 before 2&4)
  classic..16  middle: each slot adds a hit or keeps the count with one hit moved (never thinner)
  17           drop: very stripped back (kick on 1, the snare anchor, quarter hats, Hihat 2 and percs empty)
  18-19        climb: big jumps up, into the documented B part where there is one
  20           peak: as dense as the module allows (Hihat 2 on 8ths only, for Rolls; kick on 8ths plus its own 16ths)
  21-24        classic variations: the classic plus one or two hits, or the source's own other bars
Tracks whose classic is already as dense as the module allows (every 16th, or every 8th on Hihat 2 or a triplet
track) can't get busier, so their classic sits at slot 20 and the build climbs toward it (../the-arc.md explains).
Tracks with no part in the source start at one hit; their classic (silence) is the drop at slot 17."""
import json, os, math
from itertools import combinations
from lf_banks import BANKS
import hw

KEYS = ['K', 'S', 'H1', 'H2', 'P1', 'P2']
NAMES = ['KICK', 'SNARE', 'HIHAT1', 'HIHAT2', 'PERC1', 'PERC2']
LONG = ('K', 'S')
E8 = frozenset(range(1, 17, 2))
ALL = frozenset(range(1, 17))
STRONG = {1: 0, 9: 1, 5: 2, 13: 3}

def P(bars): return tuple(frozenset(b) for b in bars)
def hits(p): return sum(len(b) for b in p)
def union(p, q): return tuple(a | b for a, b in zip(p, q))
def minus(p, q): return tuple(a - b for a, b in zip(p, q))
def subset(p, q): return all(a <= b for a, b in zip(p, q))
def cells(p): return {(i, s) for i, b in enumerate(p) for s in b}
def from_cells(cs, nb): return tuple(frozenset(s for i, s in cs if i == k) for k in range(nb))
def sub(step): return (step - 1) % 4
def bstr(p): return ', '.join(''.join('1' if i in b else '0' for i in range(1, 17)) for b in p)

def build_rank(step):
    """order the classic's own hits arrive in the build: beat, +, a, e (the e and a swing under Shake, so last)."""
    return {0: 0, 2: 1, 3: 2, 1: 3}[sub(step)] * 10 + STRONG.get(step, 4) + step / 100

def add_class(step, swung):
    """order added hits come in (../timing.md, "Where added hits go", rule 4): swung banks the a and the e first; straight banks 8ths first."""
    return ({3: 0, 1: 1, 2: 2, 0: 3} if swung else {0: 0, 2: 1, 3: 2, 1: 3})[sub(step)]

def unit_split(target, base):
    """the hits in target and not in base, as units: a step in bars 1&3 together, in bars 2&4 together, else one bar."""
    nb = len(target)
    add = [set(t - b) for t, b in zip(target, base)]
    out = []
    if nb == 1:
        return [frozenset({(0, s)}) for s in sorted(add[0])]
    for (i, j) in ((0, 2), (1, 3)):
        both = add[i] & add[j]
        for s in sorted(both): out.append(frozenset({(i, s), (j, s)}))
        for k in (i, j):
            for s in sorted(add[k] - both): out.append(frozenset({(k, s)}))
    return out

def ustep(u): return min(s for _, s in u)
def ugroup_build(u):
    ks = sorted(k for k, _ in u)
    return {(0, 2): 0, (1, 3): 1}.get(tuple(ks), 2 if ks[0] in (0, 2) else 3 if ks[0] == 1 else 4)
def ugroup_add(u):
    """added hits: the answer (bars 2&4) first, then the bar-4 pickup, then bars 1&3."""
    ks = tuple(sorted(k for k, _ in u))
    return {(1, 3): 0, (3,): 1, (0, 2): 2, (1,): 3, (0,): 4, (2,): 5}.get(ks, 9)
def ok_unit(u, nb):
    """Kick/Snare: never add to bar 1 or bar 3 alone (bars 1 and 3 must match)."""
    return nb == 1 or ugroup_add(u) in (0, 1, 2, 3)

def apply(p, u): return from_cells(cells(p) | set(u), len(p))
def remove(p, u): return from_cells(cells(p) - set(u), len(p))

def generic_peak(key, swung, trip):
    if trip:
        if key == 'K': return P([E8] * 4)
        if key == 'S':
            a = {3, 5, 7, 11, 13, 15}
            return P([a, E8, a, E8])
        return P([E8])
    if key == 'K':
        b13 = set(E8) - {5, 13}; b2 = set(E8); b4 = set(E8) | {14, 16}
        if swung: b2 |= {8}; b4 |= {8}
        return P([b13, b2, b13, b4])
    if key == 'S':
        b13 = {5, 7, 13, 15}; b2 = {3, 5, 7, 11, 13, 15}; b4 = b2 | {14, 16}
        if swung: b13 |= {16}; b2 |= {8, 16}; b4 |= {8}
        return P([b13, b2, b13, b4])
    if key == 'H2': return P([E8])
    return P([ALL])

def vocab_units(spec, key, trip):
    out = []
    for item in spec['vocab']:
        if key in LONG:
            bars, steps, tag = item
            idx = {'24': (1, 3), '13': (0, 2), '4': (3,)}[bars]
            u = frozenset((k, s) for k in idx for s in steps if (not trip or s in E8))
        else:
            steps, tag = item
            u = frozenset((0, s) for s in steps if (not trip or s in E8))
        if u: out.append((u, tag))
    return out

def drop_candidates(key, C, spec):
    nb = len(C)
    out = [P(d) if nb == 4 else P([d]) for d in (spec['drop'] or [])]
    if hits(C) == 0:
        out.append(C)            # no part in the source: the drop is the classic (silence)
    if key == 'K':
        out += [P([[1]] * 4), P([[1], [], [1], []]), P([[1], [1], [1], []]), P([[1, 9], [1], [1, 9], [1]]), P([[9]] * 4)]
    elif key == 'S':
        A = [set(b) & {5, 13} for b in C]
        if not any(A):
            first = next((set(b) for b in C if b), None)
            A = [set(first)] * 4 if first else [{13}] * 4
        A = [a if a else {max(x for y in A for x in y)} for a in A]
        lo, hi = min(min(a) for a in A), max(max(a) for a in A)
        out += [P(A), P([A[0], A[1], A[2], {lo}]), P([A[0], {hi}, A[2], {hi}]), P([{hi}] * 4), P([{lo}] * 4), P([[], [hi], [], [hi]])]
    elif key == 'H1':
        out += [P([s]) for s in ([1, 5, 9, 13], [1, 9], [5, 13], [1], [9], [])]
    elif key == 'H2':
        out += [P([s]) for s in ([], [15], [11], [7], [3], [1], [9])]
    else:
        out += [P([[]])] + [P([[s]]) for s in sorted(C[0])] + [P([[s]]) for s in (1, 9, 5, 13)]
    return out

def plan_track(bank, key):
    spec = bank['tracks'][key]
    trip = bank['trip']
    swung = bank['timing'] == 'Shake' and bank['row'] >= 2
    nb = 4 if key in LONG else 1
    C = P(spec['C']) if nb == 4 else P([spec['C']])
    Bp = None
    if spec['B'] is not None:
        Bp = P(spec['B']) if nb == 4 else P([spec['B']])
    V = vocab_units(spec, key, trip)
    G = generic_peak(key, swung, trip)
    if key == 'H2':
        Pk = union(P([E8]), C)
    else:
        Pk = union(G, C)
        if Bp: Pk = union(Pk, Bp)
        for u, _ in V: Pk = apply(Pk, u)
    if trip:
        Pk = tuple(b & E8 for b in Pk)
    slots = [None] * 25            # 1-based
    tag = {}                        # (bar, step) -> source tag of every hit that isn't the classic's
    note = {}
    def free(p, upto=25): return all(slots[i] != p for i in range(1, upto) if slots[i] is not None)
    def mark(p, t):
        for c in cells(p) - cells(C): tag.setdefault(c, t)
    # hits a middle or 21-24 pattern may use beyond the peak's own (sparse one-bar tracks need the room to stay distinct)
    Uall = P([ALL]) if (nb == 1 and key != 'H2' and not trip) else Pk
    empty = hits(C) == 0
    ceiling = (not empty) and C == Pk

    def add_key(u):
        # same step: the answer (bars 2&4) first, then bars 1&3 right after, so the bars grow together
        return (add_class(ustep(u), swung), STRONG.get(ustep(u), 4), ustep(u), ugroup_add(u))

    if ceiling:
        units = sorted(unit_split(C, tuple(frozenset() for _ in C)), key=lambda u: (build_rank(ustep(u)), ugroup_build(u)))
        n = len(units)
        def pre(k): return from_cells(set().union(*units[:k]) if k else set(), nb)
        def by_count(k, lo):
            cands = [pre(k)]
            if k + 1 <= n:
                cands += [remove(pre(k + 1), units[j]) for j in range(k - 1, -1, -1)]
            if 1 <= n - k <= 2:
                cands += [remove(C, set().union(*comb)) for comb in combinations(units, n - k)]
            for c in cands:
                if free(c) and hits(c) >= lo: return c
            return None
        prev = 0
        for i in range(1, 17):
            k = 1 + round((n - 3) * (i - 1) / 15)
            c = by_count(k, prev)
            if c is None: c = by_count(k + 1, prev)
            slots[i] = c; prev = hits(c)
        classic_slot = 20
        base = C
        note['ceiling'] = True
    elif spec['build']:
        for i, b in enumerate(spec['build']):
            slots[i + 1] = P(b) if nb == 4 else P([b])
        classic_slot = len(spec['build'])
        assert slots[classic_slot] == C
        base = C
    elif empty:
        first = V[0][0] if V else sorted(unit_split(Pk, C), key=add_key)[0]
        slots[1] = apply(C, first); mark(slots[1], V[0][1] if V else 'OWN')
        classic_slot = 17
        base = slots[1]
    else:
        units = sorted(unit_split(C, tuple(frozenset() for _ in C)), key=lambda u: (build_rank(ustep(u)), ugroup_build(u)))
        n = len(units); c = min(n, 8)
        sizes = [n // c + (1 if i >= c - n % c else 0) for i in range(c)]
        acc = set(); k = 0
        for i in range(c):
            acc |= set().union(*units[k:k + sizes[i]]); k += sizes[i]
            slots[i + 1] = from_cells(acc, nb)
        classic_slot = c
        base = C

    # ---- middle: classic_slot+1 .. 16
    if not ceiling:
        Bnew = cells(Bp) - cells(C) if Bp else set()
        Bsrc_or_own = spec['Bsrc'] or 'OWN'
        gen = [u for u in sorted(unit_split(Pk, base), key=add_key) if ok_unit(u, nb)]
        gen += [u for u in sorted(unit_split(Uall, union(Pk, base)), key=add_key) if ok_unit(u, nb)]
        # the B part's new hits are saved for slot 18; they're only used in the middle if nothing else is left
        pool = [(u, t) for u, t in V if not (set(u) & Bnew)] + [(u, 'OWN') for u in gen if not (set(u) & Bnew)]
        pool += [(u, t) for u, t in V if set(u) & Bnew] + [(u, Bsrc_or_own) for u in gen if set(u) & Bnew]
        start = classic_slot if classic_slot != 17 else 1
        cur = slots[start]
        m = 16 - start
        # sourced tracks climb about 60% of the way to the peak by slot 16; tracks with no source part stay lighter (40%)
        T16 = hits(base) + round((0.4 if empty else 0.6) * (hits(Pk) - hits(base)))
        T16 = min(T16, hits(Pk) - 3)
        T16 = max(T16, hits(cur))
        remaining = list(pool)
        added = []
        def take(p):
            for idx, (u, t) in enumerate(remaining):
                if not set(u) <= cells(p):
                    q = apply(p, u)
                    if hits(q) <= hits(Pk) - 3 or not remaining[idx + 1:]:
                        remaining.pop(idx)
                        return q, (u, t)
            return None, None
        for j in range(1, m + 1):
            slot = start + j
            target = hits(base) + round((T16 - hits(base)) * j / m)
            target = max(target, hits(cur))
            cand = cur; used_units = []
            while hits(cand) < target:
                q, ut = take(cand)
                if q is None: break
                cand = q; used_units.append(ut)
            if cand == cur or not free(cand):
                # keep the count: move one added hit (swap an added unit for an unused one of the same size)
                done = False
                for u_old, t_old in reversed(added):
                    if not set(u_old) <= cells(cand): continue
                    for idx, (u_new, t_new) in enumerate(remaining):
                        if len(u_new) != len(u_old) or set(u_new) <= cells(cand): continue
                        q = apply(remove(cand, u_old), u_new)
                        if hits(q) >= hits(cur) and free(q):
                            remaining.pop(idx); remaining.append((u_old, t_old))
                            added.remove((u_old, t_old)); used_units.append((u_new, t_new))
                            cand = q; done = True; break
                    if done: break
                if not done:
                    while not free(cand) or cand == cur:
                        q, ut = take(cand)
                        if q is None: break
                        cand = q; used_units.append(ut)
            for u, t in used_units:
                if (u, t) not in added: added.append((u, t))
                for cc in u: tag.setdefault(cc, t)
            slots[slot] = cand; cur = cand

    # ---- drop: 17
    for d in drop_candidates(key, C, spec):
        if key == 'H2' and hits(d) > 1: continue
        if free(d) and hits(d) < max(1, hits(slots[16])):
            if nb == 4 and d[0] != d[2]: continue
            slots[17] = d; break
    assert slots[17] is not None, (bank['name'], key, 'drop')
    for cc in cells(slots[17]) - cells(C): tag.setdefault(cc, 'OWN')

    # ---- climb 18, 19 and peak 20
    def grow(p, need, cap):
        for u in sorted(unit_split(Pk, p), key=add_key):
            if hits(p) >= need: break
            if not ok_unit(u, nb) and nb == 4 and p[0] == p[2]: continue
            q = apply(p, u)
            if hits(q) <= cap: p = q
        return p
    def fallback(lo, hi):
        """a pattern inside the peak with lo < hits <= hi that no slot uses yet."""
        us = unit_split(Pk, tuple(frozenset() for _ in Pk))
        for r in range(1, 4):
            for comb in combinations(sorted(us, key=add_key, reverse=True), r):
                q = remove(Pk, set().union(*comb))
                if lo < hits(q) <= hi and free(q) and (nb == 1 or q[0] == q[2]): return q
        return None
    if ceiling:
        slots[20] = C
        slots[19] = fallback(hits(C) - 2, hits(C) - 1)
        slots[18] = fallback(hits(slots[17]), hits(C) - 2)
    else:
        slots[20] = Pk
        if Bp is not None:
            c18 = Bp
            if hits(c18) <= hits(slots[17]) or not free(c18) or c18 == Pk:
                c18 = grow(Bp, hits(Bp) + 1, hits(Pk) - 2)
            note['B_at_18'] = c18 == Bp
        else:
            s16 = slots[16]
            need = hits(s16) + max(1, math.ceil((hits(Pk) - hits(s16)) / 3))
            c18 = grow(s16, need, hits(Pk) - 2)
        if not free(c18) or hits(c18) <= hits(slots[17]) or hits(c18) >= hits(Pk) - 1:
            c18 = fallback(hits(slots[17]), hits(Pk) - 2)
        slots[18] = c18
        need = hits(c18) + max(1, math.ceil((hits(Pk) - hits(c18)) / 2))
        c19 = grow(c18, need, hits(Pk) - 1)
        if not free(c19) or hits(c19) <= hits(c18) or hits(c19) >= hits(Pk):
            c19 = fallback(hits(c18), hits(Pk) - 1)
        slots[19] = c19
        for i in (18, 19, 20):
            for cc in cells(slots[i]) - cells(C):
                if Bp is not None and cc in cells(Bp): tag.setdefault(cc, spec['Bsrc'])
                tag.setdefault(cc, 'OWN')

    # ---- 21-24: classic variations
    reach = max(4 if nb == 4 else 2, math.ceil(0.35 * hits(base)))
    cands = []
    for v, t in spec['var']:
        cands.append((P([v]) if nb == 1 else P(v), t))
    vu = vocab_units(spec, key, trip)
    if Bp is not None:
        vu += [(u, spec['Bsrc']) for u in unit_split(Bp, base) if ok_unit(u, nb)]
    gu = [(u, 'OWN') for u in sorted(unit_split(Pk, base), key=add_key) if ok_unit(u, nb)]
    gu += [(u, 'OWN') for u in sorted(unit_split(Uall, union(Pk, base)), key=add_key) if ok_unit(u, nb)]
    single = vu + gu
    for u, t in single: cands.append((apply(base, u), t))
    for (u1, t1), (u2, t2) in combinations(single[:12], 2):
        cands.append((apply(apply(base, u1), u2), t1 if t1 == t2 else t1 + '+' + t2))
    # last resort: one of the classic's hits moves (keeps the count), or moves and one more joins
    core = [u for u in unit_split(base, tuple(frozenset() for _ in base)) if ok_unit(u, nb) or nb == 1]
    for u_out in sorted(core, key=lambda u: -build_rank(ustep(u))):
        if ustep(u_out) in (1,) and key in LONG: continue
        for u_in, t in single[:12]:
            if len(u_in) == len(u_out):
                cands.append((apply(remove(base, u_out), u_in), 'OWN'))
    if ceiling:
        cands = [(remove(C, u), 'OWN') for u in sorted(unit_split(C, tuple(frozenset() for _ in C)), key=add_key)] + cands
    lo = hits(base) - (1 if ceiling else 0)
    hi = hits(base) + reach
    pick = []
    for p, t in cands:
        if len(pick) == 4: break
        if not (lo <= hits(p) <= hi): continue
        if nb == 4 and p[0] != p[2]: continue
        if not free(p) or any(p == q for q, _ in pick): continue
        pick.append((p, t))
    assert len(pick) == 4, (bank['name'], key, '21-24')
    pick.sort(key=lambda x: hits(x[0]))
    for i, (p, t) in enumerate(pick):
        slots[21 + i] = p
        for cc in cells(p) - cells(C): tag.setdefault(cc, t.split('+')[0])
    pats = slots[1:]
    assert all(p is not None for p in pats), (bank['name'], key, [i + 1 for i, p in enumerate(pats) if p is None])
    return dict(pats=pats, classic_slot=classic_slot, C=C, B=Bp, peak=Pk, ceiling=ceiling, empty=empty, tag=tag, note=note)

def write_bank(lanes):
    lines = []
    for nm, pats in zip(NAMES, lanes):
        assert len(pats) == 24
        for i, p in enumerate(pats):
            lines.append(f"{nm} > PTN{i}: {bstr(p)};")
        lines.append('')
    return '\r\n'.join(lines[:-1]) + '\r\n'

def main():
    here = os.path.dirname(os.path.abspath(__file__))
    # Package copy: writes into tools/build-output/ instead of the folder above (the original wrote to Build-1/).
    root = os.path.join(here, 'build-output')
    dA = os.path.join(root, 'Card Files - Slots 1-32')
    dB = os.path.join(root, 'Card Files - Slots 33-64')
    os.makedirs(dA, exist_ok=True); os.makedirs(dB, exist_ok=True)
    index = []
    for b in BANKS:
        plans = {k: plan_track(b, k) for k in KEYS}
        text = write_bank([plans[k]['pats'] for k in KEYS])
        fa = f"PatternBank{b['n'] - 1:03d}.txt"; fb = f"PatternBank{b['n'] + 31:03d}.txt"
        for d, f in ((dA, fa), (dB, fb)):
            with open(os.path.join(d, f), 'w', newline='') as fh: fh.write(text)
        index.append(dict(n=b['n'], name=b['name'], file_a=fa, file_b=fb, bpm=b['bpm'], timing=b['timing'], row=b['row'],
                          row2=b.get('row2'), trip=b['trip'], tracks={k: dict(
                              classic_slot=plans[k]['classic_slot'], ceiling=plans[k]['ceiling'], empty=plans[k]['empty'],
                              note=plans[k]['note'],
                              classic=[sorted(x) for x in plans[k]['C']],
                              B=[sorted(x) for x in plans[k]['B']] if plans[k]['B'] else None,
                              pats=[[sorted(x) for x in p] for p in plans[k]['pats']],
                              tags=sorted([[i, s, t] for (i, s), t in plans[k]['tag'].items()])) for k in KEYS}))
    with open(os.path.join(root, 'bank-index.json'), 'w') as fh: json.dump(index, fh, indent=0)
    print('built', len(index), 'banks')

if __name__ == '__main__':
    main()
