N=[16,28,36,20,24,32,36]
LENS={'Trip':[[4,4,4,4,4,4,4,4],[8,8,8,4,8,8,8,4],[8,12,8,8,8,12,8,8],[4,8,4,4,4,8,4,4],[4,12,4,4,4,12,4,4],[4,16,8,4,4,16,8,4],[4,20,8,4,4,20,8,4]],
 'Shake':[[4]*8,[8,6]*4,[11,7]*4,[6,4]*4,[7,5]*4,[10,6]*4,[12,6]*4],
 'Push':[[4]*8,[8,7,7,6]*2,[10,9,9,8]*2,[6,5,5,4]*2,[7,6,6,5]*2,[10,8,8,6]*2,[11,9,9,7]*2],
 'Clave':[[4]*8,[8,8,5,8,8,5,8,6],[10,12,5,10,12,5,10,8],[6,6,3,6,6,3,6,4],[8,7,3,8,7,3,8,4],[9,11,4,9,11,4,8,8],[11,12,4,10,13,4,10,8]]}
T=['Trip','Shake','Push','Clave']; MASK=0x01224489
def ticks(t,row):
    r=row-1; h=[0]; a=0
    for k in range(7): a+=LENS[t][r][k]; h.append(a)
    return h+[p+2*N[r] for p in h]
def pos(t,row): return [x/N[row-1] for x in ticks(t,row)]
def off(t,row): return [p-k/4 for k,p in enumerate(pos(t,row))]
def every(t,row): rr=row-1+7*T.index(t); return bool((MASK>>rr)&1)
def rolls(t,row,step):
    tk=ticks(t,row); n=N[row-1]; k=step-1; a=tk[k]; b=tk[k+1] if k<15 else 4*n
    return sum(1 for x in range(a+1,b) if every(t,row) or x%2==0)
def ms(beats,bpm): return beats*60000/bpm
