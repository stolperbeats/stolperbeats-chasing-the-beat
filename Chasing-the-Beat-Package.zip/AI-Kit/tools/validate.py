#!/usr/bin/env python3
"""Check Stolperbeats PatternBank files before they go on a card.

Usage:
    python3 -B validate.py PatternBank000.txt [more files or folders ...]

A folder is checked file by file (every PatternBank*.txt in it).
Prints PASS or FAIL per file. Every failure names the line number.
Exit code 0 if every file passes, 1 if any fails.

The rules match the card files of "Chasing the Beat" exactly
(see ../file-format.md). They are:
  - six tracks, in this order: KICK, SNARE, HIHAT1, HIHAT2, PERC1, PERC2
  - 24 patterns per track, PTN0 to PTN23, in order
  - KICK and SNARE: four bars of 16 steps, separated by ", "
  - HIHAT1, HIHAT2, PERC1, PERC2: one bar of 16 steps
  - steps are only 0 (off) or 1 (on)
  - every pattern line ends with ";"
  - one empty line between tracks, none at the end
  - Windows line endings (CR LF) on every line, including the last
"""
import os
import re
import sys

TRACKS = ["KICK", "SNARE", "HIHAT1", "HIHAT2", "PERC1", "PERC2"]
BARS = {"KICK": 4, "SNARE": 4, "HIHAT1": 1, "HIHAT2": 1, "PERC1": 1, "PERC2": 1}
LINE = re.compile(r"^([A-Z0-9]+) > PTN(\d+): (.*);$")


def expected_lines():
    """The line layout every good file has: (track, pattern) or None for a blank line."""
    out = []
    for t, name in enumerate(TRACKS):
        for p in range(24):
            out.append((name, p))
        if t < len(TRACKS) - 1:
            out.append(None)
    return out


def check(path):
    errors = []
    try:
        raw = open(path, "rb").read()
    except OSError as e:
        return [f"cannot open the file: {e}"]
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError as e:
        return [f"byte {e.start}: not plain ASCII text"]

    if not text.endswith("\r\n"):
        errors.append("end of file: the last line must end with CR LF (Windows line ending)")
    body = text[:-2] if text.endswith("\r\n") else text
    lines = body.split("\r\n")
    for n, ln in enumerate(lines, 1):
        if "\n" in ln or "\r" in ln:
            errors.append(f"line {n}: line ending is not CR LF")

    layout = expected_lines()
    if len(lines) != len(layout):
        errors.append(f"the file has {len(lines)} lines; it must have {len(layout)} "
                      f"(6 tracks x 24 patterns, plus 5 empty lines between tracks)")

    for n, (ln, want) in enumerate(zip(lines, layout), 1):
        ln = ln.replace("\r", "").replace("\n", "")
        if want is None:
            if ln != "":
                errors.append(f"line {n}: must be empty (the gap between two tracks)")
            continue
        name, ptn = want
        m = LINE.match(ln)
        if not m:
            errors.append(f"line {n}: expected '{name} > PTN{ptn}: <steps>;' and got '{ln[:40]}'")
            continue
        got_name, got_ptn, steps = m.group(1), int(m.group(2)), m.group(3)
        if got_name != name:
            errors.append(f"line {n}: track name is {got_name}, expected {name}")
        if got_ptn != ptn:
            errors.append(f"line {n}: pattern number is PTN{got_ptn}, expected PTN{ptn}")
        bars = steps.split(", ")
        nb = BARS.get(name, 1)
        if len(bars) != nb:
            errors.append(f"line {n}: {name} needs {nb} bar{'s' if nb > 1 else ''} "
                          f"separated by ', ' and has {len(bars)}")
        for b, bar in enumerate(bars, 1):
            if len(bar) != 16:
                errors.append(f"line {n}: bar {b} has {len(bar)} steps; every bar has 16")
            bad = sorted(set(bar) - {"0", "1"})
            if bad:
                errors.append(f"line {n}: bar {b} has characters other than 0 and 1: {' '.join(map(repr, bad))}")
    return errors


def files_from(args):
    for a in args:
        if os.path.isdir(a):
            for f in sorted(os.listdir(a)):
                if f.startswith("PatternBank") and f.endswith(".txt"):
                    yield os.path.join(a, f)
        else:
            yield a


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    failed = 0
    total = 0
    for path in files_from(argv):
        total += 1
        name = os.path.basename(path)
        if not re.fullmatch(r"PatternBank\d{3}\.txt", name):
            print(f"NOTE {name}: the module looks for PatternBank000.txt to PatternBank063.txt; rename before copying")
        errs = check(path)
        if errs:
            failed += 1
            print(f"FAIL {path}")
            for e in errs[:40]:
                print(f"     {e}")
            if len(errs) > 40:
                print(f"     ... and {len(errs) - 40} more")
        else:
            print(f"PASS {path}")
    print(f"\n{total - failed} of {total} passed" + ("" if not failed else f", {failed} failed"))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
