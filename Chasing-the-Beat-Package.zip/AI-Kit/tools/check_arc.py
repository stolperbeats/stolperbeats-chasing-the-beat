#!/usr/bin/env python3
"""Check that a PatternBank file follows the arc (../the-arc.md), track by track.

Usage:
    python3 -B check_arc.py PatternBank040.txt [--triplet] [--classic K=8,S=4,H1=8,...]

Run validate.py first: this script assumes the file loads.
It prints OK / WARN / FAIL lines per track and a summary. WARN lines are things the
arc usually does but a documented exception may break (say why in your note).

--triplet         the bank is a triplet (Trip 5) bank: steps 2 and 4 of a beat are not allowed
--classic ...     the classic's knob per track (K, S, H1, H2, P1, P2). If given, the script
                  checks that slots 1 to the classic never get thinner and that the classic is
                  where the build-up ends.
"""
import sys

TRACKS = ["KICK", "SNARE", "HIHAT1", "HIHAT2", "PERC1", "PERC2"]
SHORT = dict(zip(["K", "S", "H1", "H2", "P1", "P2"], TRACKS))
E8 = set(range(1, 17, 2))


def load(path):
    by = {}
    for r in open(path, newline="").read().split("\r\n"):
        if not r:
            continue
        nm, rest = r.split(" > PTN")
        _, p = rest.split(": ")
        by.setdefault(nm, []).append(tuple(frozenset(k + 1 for k, c in enumerate(b) if c == "1")
                                           for b in p.rstrip(";").split(", ")))
    return by


def hits(p):
    return sum(len(b) for b in p)


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    path = argv[0]
    trip = "--triplet" in argv
    classic = {}
    if "--classic" in argv:
        for kv in argv[argv.index("--classic") + 1].split(","):
            k, v = kv.split("=")
            classic[SHORT[k.strip().upper()]] = int(v)
    bank = load(path)
    fails = warns = 0

    def say(level, track, msg):
        nonlocal fails, warns
        if level == "FAIL":
            fails += 1
        if level == "WARN":
            warns += 1
        print(f"{level:4} {track:7} {msg}")

    for t in TRACKS:
        pats = bank[t]
        h = [hits(p) for p in pats]           # h[0] is slot 1
        s = lambda n: h[n - 1]
        print(f"     {t:7} hits per slot: {' '.join(map(str, h))}")
        if len(set(pats)) != 24:
            dup = sorted({i + 1 for i, p in enumerate(pats) if pats.count(p) > 1})
            say("FAIL", t, f"slots repeat: {dup} (all 24 must differ)")
        if s(1) != min(h[:16]):
            say("FAIL", t, f"slot 1 ({s(1)} hits) is not the thinnest of 1-16 (min {min(h[:16])})")
        if s(20) != max(h):
            say("FAIL", t, f"slot 20 ({s(20)} hits) is not the busiest slot ({max(h)})")
        if not (s(18) < s(19) <= s(20)):
            say("FAIL", t, f"18-19-20 don't climb: {s(18)}, {s(19)}, {s(20)}")
        if s(17) >= s(16):
            say("FAIL", t, f"the drop (17, {s(17)} hits) is not thinner than 16 ({s(16)})")
        if s(17) > min(h[17:]):
            say("WARN", t, f"17 ({s(17)}) is not the thinnest of 17-24")
        if t == "HIHAT2" and s(17) > 1 * (4 if len(pats[0]) == 4 else 1):
            say("FAIL", t, f"Hihat 2 has {s(17)} hits at the drop; at most one (Rolls)")
        if t == "HIHAT2" and not set(pats[19][0]) <= E8 and s(20) != 16:
            say("WARN", t, "Hihat 2 at 20 has 16ths; the arc keeps it on 8ths for Rolls")
        c = classic.get(t)
        lo = c if c and c <= 16 else 1
        for i in range(lo + 1, 17):
            if s(i) < s(i - 1):
                say("WARN", t, f"slot {i} ({s(i)}) is thinner than slot {i - 1} ({s(i - 1)})")
        if c and c <= 16:
            for i in range(2, c + 1):
                if s(i) < s(i - 1):
                    say("WARN", t, f"build-up: slot {i} is thinner than {i - 1}")
        if c == 17 and s(17) != 0:
            say("FAIL", t, "classic listed as 17 (silent in the source) but slot 17 isn't empty")
        if c and c <= 16:
            cv = s(c)
            for i in range(21, 25):
                if s(i) < cv - 1:
                    say("WARN", t, f"slot {i} ({s(i)}) is thinner than the classic ({cv}); 21-24 shouldn't thin out")
        if h[20:24] != sorted(h[20:24]):
            say("WARN", t, f"21-24 not in rising order: {h[20:24]}")
        if len(pats[0]) == 4:
            bad = [i + 1 for i, p in enumerate(pats) if p[0] != p[2]]
            if bad:
                say("WARN", t, f"bars 1 and 3 differ in slots {bad}")
        if trip:
            bad = [i + 1 for i, p in enumerate(pats) if any(st % 2 == 0 for b in p for st in b)]
            if bad:
                say("FAIL", t, f"triplet bank: steps 2 or 4 of a beat used in slots {bad}")

    tot = [sum(hits(bank[t][i]) for t in TRACKS) for i in range(24)]
    print(f"     BANK    hits per slot: {' '.join(map(str, tot))}")
    print(f"\n{'FAIL' if fails else 'PASS'}: {fails} fails, {warns} warnings")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
