# Tools

Small Python 3 scripts. No extra packages needed. Run them with `python3 -B` (the `-B` stops Python leaving cache files behind).

Run them from this `tools/` folder, or give the path: `python3 -B tools/validate.py ...` from `AI-Kit/`.

## validate.py: does the file load?

```
python3 -B validate.py PatternBank040.txt
python3 -B validate.py "../../Card Files - Slots 1-32"
```

Checks one file, several files, or every `PatternBank*.txt` in a folder. Prints **PASS** or **FAIL** per file; each failure gives the line number and what's wrong. It checks every rule in `../file-format.md`: six tracks in order, 24 patterns each numbered PTN0 to PTN23, Kick and Snare with four 16-step bars, the other tracks with one, only 0s and 1s, the `;` at the end of each line, the empty lines between tracks, and Windows (CR LF) line endings. All 64 card files pass.

## check_arc.py: does it follow the arc?

```
python3 -B check_arc.py PatternBank040.txt --classic K=8,S=4,H1=8,H2=17,P1=17,P2=17
python3 -B check_arc.py PatternBank030.txt --triplet
```

Run `validate.py` first. Then this checks the shape from `../the-arc.md`, track by track: all 24 slots differ; slot 1 is the thinnest of 1 to 16; 1 to 16 never get thinner; the drop at 17 is thinner than 16; 18 < 19 ≤ 20; 20 is the busiest slot; Hihat 2 has at most one hit at 17 and stays on 8ths at 20; 21 to 24 rise and don't fall below the classic; Kick and Snare bars 1 and 3 match. `--classic` gives each track's classic knob (K, S, H1, H2, P1, P2), so it can check the build-up too. `--triplet` fails any hit on steps 2 or 4 of a beat. It prints hits per slot for every track. FAIL lines must be fixed; WARN lines are allowed if you explain them (the card's bank 03 has two, from its song order).

## The builder: lf_build.py, lf_banks.py, hw.py

These are the scripts that built the card, copied in with only two changes: personal details removed, and `lf_build.py` now writes into `tools/build-output/` instead of the folder above.

- **`lf_banks.py`**: the 32 banks as data. For each track: the sound, the source label, the classic (`C`), the B part (`B`), the vocabulary (`vocab`), the source's own variations (`var`), and any hand-set build-up (`build`, bank 03 only) or drop (`drop`). The header comment explains every field.
- **`lf_build.py`**: the arc as code. For every track it works out the peak, the build-up, the middle, the drop, the climb and the variations, then writes both card folders and `bank-index.json` (every pattern with the source label of every added hit).
- **`hw.py`**: the firmware 163 timing tables (how many ticks each step lasts, per Timing and Shuffle row), plus helpers: `pos` (where each step lands, in beats), `off` (how far off the straight grid), `ms` (beats to milliseconds), `rolls` (how many extra Hihat 2 hits Rolls adds on a step).

Run:

```
python3 -B lf_build.py
```

It rebuilds the 32 banks into `tools/build-output/`, and the result is byte for byte the card files in this package. That's checked: compare with

```
diff -r "build-output/Card Files - Slots 1-32" "../../Card Files - Slots 1-32"
```

(no output means identical).

**Building a new bank with it:** add one more `dict(...)` at the end of the `BANKS` list in `lf_banks.py`, following the others (Blue Monday is a good model, and `../worked-example.md` traces exactly what the builder does with it). Bank numbers come from the position in the list, so a 33rd entry comes out as `build-output/Card Files - Slots 1-32/PatternBank032.txt`. (Its twin in the other folder, `PatternBank064.txt`, is past the card's 64 banks: ignore it.) Run `lf_build.py`. It stops with an `AssertionError` naming the bank and track if it can't fit a rule. Check the result with `validate.py` and `check_arc.py`, and rename the file to the slot the user wants. This was tested with a simple 33rd bank: it built, validated and passed the arc check.

Not included: the build's check, notes and audit scripts. They read research files and reports that aren't part of this package, so they don't run on their own. Everything they reported is in `../banks/` and `../banks.json`.
