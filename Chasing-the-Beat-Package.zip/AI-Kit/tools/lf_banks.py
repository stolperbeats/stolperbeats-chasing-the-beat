"""Lean-forward pack: the 32 banks as data (Build-1, 2026-11-21).
Sources: the build's research files (grids, B parts, track layout, home settings). They are not in this package;
the facts they gave are in ../banks.json and ../banks/.
Kick/Snare patterns are 4 bars, written as a list of 4 step lists. Hats/percs are 1 bar, one step list.
Tags: BOOK, AINSWORTH, MT-40X, ST, ARCHIVE, OWN (see ../the-arc.md, "Source labels"), plus ARTICLES for I Feel Love's kick and hat
(magazine and encyclopedia descriptions, no transcription).
C     = the classic, exactly as the source gives it ([] = the track has no part in the source).
B     = the documented second section for this track, used at slot 18 (Bsrc = its source).
vocab = hits the middle (slots after the classic), the climb and 21-24 add first, in order, before any generic OWN hit.
        Kick/Snare items: (bars, steps, tag); bars '24' = bars 2 and 4 (the answer), '13' = bars 1 and 3, '4' = bar 4 (the pickup).
        Hat/perc items: (steps, tag).
var   = whole patterns from the source, used first for 21-24.
build = explicit slots 1..classic (Killing In The Name only). drop = slot-17 candidates tried first."""
E8 = [1, 3, 5, 7, 9, 11, 13, 15]
Q = [1, 5, 9, 13]
BB = [5, 13]
ALL = list(range(1, 17))
def x4(b): return [list(b) for _ in range(4)]
def alt(a, b): return [list(a), list(b), list(a), list(b)]
def last(a, d): return [list(a), list(a), list(a), list(d)]

def T(sound, src='OWN', C=None, B=None, Bsrc=None, vocab=(), var=(), drop=None, build=None):
    return dict(sound=sound, src=src, C=C, B=B, Bsrc=Bsrc, vocab=list(vocab), var=list(var), drop=drop, build=build)

BANKS = [
dict(name="We Will Rock You", who="Queen, 1977 (Roger Taylor and overdubs)", bpm=81, timing='Shake', row=1, sec=None, res=1,
 tracks=dict(
  K=T("Kick (the stomp)", 'BOOK', x4([1, 3, 9, 11]), vocab=[('4', [15], 'OWN'), ('24', [7], 'OWN')]),
  S=T("Clap", 'BOOK', x4(BB), vocab=[('4', [16], 'OWN'), ('24', [15], 'OWN')]),
  H1=T("Closed hat (not on the record)", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN'), ([5], 'OWN'), ([13], 'OWN')]),
  H2=T("Open hat or crash (not on the record)", 'OWN', [], vocab=[([1], 'OWN')]),
  P1=T("Tambourine (not on the record)", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]),
  P2=T("Floor tom (doubles the stomp)", 'BOOK', [1, 3, 9, 11], vocab=[([15], 'OWN'), ([7], 'OWN')]))),

dict(name="Sleng Teng (MT-40 Rock)", who="Wayne Smith, 'Under Mi Sleng Teng', 1985 (Casio MT-40 'rock' preset)", bpm=82, timing='Shake', row=1, sec=None, res=4,
 tracks=dict(
  K=T("Kick", 'MT-40X', x4([1, 5, 7, 9, 13]), vocab=[('4', [15], 'OWN'), ('24', [11], 'OWN')]),
  S=T("Snare", 'MT-40X', x4(BB), vocab=[('4', [16], 'OWN'), ('24', [15], 'OWN')]),
  H1=T("Closed hat (strong)", 'MT-40X', E8),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Closed hat (soft)", 'MT-40X', [2, 4, 6, 8, 10, 12, 14, 16]),
  P2=T("Rimshot", 'OWN', [], vocab=[([7], 'OWN'), ([15], 'OWN'), ([4], 'OWN'), ([12], 'OWN')]))),

dict(name="Killing In The Name", who="Rage Against The Machine, 1992 (Brad Wilk)", bpm=89, timing='Shake', row=2, row2=4, sec="the 2:01 swung section (BOOK p78)", res=2,
 tracks=dict(
  K=T("Kick", 'BOOK', last([1, 9], [1, 9, 10, 12, 14]), B=x4([1, 2, 4, 8, 12]), Bsrc='BOOK',
      vocab=[('24', [15], 'BOOK'), ('24', [4], 'BOOK'), ('13', [15], 'BOOK'), ('24', [12], 'BOOK'), ('13', [4], 'BOOK')],
      build=[[[1], [], [1], []], x4([1]), [[1, 9], [1], [1, 9], [1]], [[1, 9, 15], [1, 9], [1, 9, 15], [1, 9]],
             [[1, 4, 9, 15], [1, 9, 15], [1, 4, 9, 15], [1, 9, 15]], x4([1, 4, 9, 12, 15]), x4([1, 9]),
             last([1, 9], [1, 9, 12, 14]), last([1, 9], [1, 9, 10, 12, 14])],
      drop=[last([1, 9], [1])]),
  S=T("Snare", 'BOOK', last(BB, [5, 13, 15]), B=x4(BB), Bsrc='BOOK',
      vocab=[('24', [10], 'BOOK'), ('13', [10], 'BOOK')],
      build=[[[5], [], [5], []], x4([5]), [[5, 13], [5], [5, 13], [5]], [[5, 10, 13], [5], [5, 10, 13], [5]],
             [[5, 10, 13], [5, 13], [5, 10, 13], [5, 13]], x4([5, 10, 13]), x4(BB), last(BB, [5, 10, 13]), last(BB, [5, 13, 15])],
      drop=[last(BB, [5])]),
  H1=T("Hi-hat (closed / half-open)", 'BOOK', E8, B=E8, Bsrc='BOOK',
       build=[[1], [1, 9], [1, 5, 9, 13], [1, 3, 5, 9, 13], [1, 3, 5, 9, 11, 13], [1, 3, 5, 7, 9, 13], [1, 3, 5, 7, 9, 11, 13],
              [1, 3, 5, 7, 9, 11, 15], E8],
       drop=[[]]),
  H2=T("Open hat", 'BOOK', [15], drop=[[]]),
  P1=T("Floor tom", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')], drop=[[]]),
  P2=T("Crash", 'OWN', [], vocab=[([1], 'OWN')], drop=[[]]))),

dict(name="Give It Away", who="Red Hot Chili Peppers, 1991 (Chad Smith)", bpm=91, timing='Shake', row=1, sec="Chad's later added snares (BOOK p61 text)", res=3,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 4, 7, 10, 11, 14, 15]), vocab=[('4', [16], 'OWN')]),
  S=T("Snare", 'BOOK', x4(BB), B=x4([5, 7, 10, 13, 16]), Bsrc='BOOK',
      vocab=[('4', [16], 'BOOK'), ('24', [7], 'BOOK'), ('24', [10], 'BOOK')]),
  H1=T("Closed hat (not in the book)", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN'), ([5], 'OWN'), ([13], 'OWN')]),
  H2=T("Open hat", 'BOOK', E8),
  P1=T("Ghost snare (quiet)", 'OWN', [], vocab=[([8], 'OWN'), ([16], 'OWN')]),
  P2=T("Cowbell", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')]))),

dict(name="Go-go (Bustin' Loose)", who="Chuck Brown style (Ricky Wellman; congas Gregory Gerran)", bpm=92, timing='Shake', row=6, sec=None, res=5,
 tracks=dict(
  K=T("Kick", 'ARCHIVE', alt([1, 4, 8, 11], [1, 4, 7, 11, 14]), vocab=[('4', [16], 'OWN'), ('13', [14], 'OWN')]),
  S=T("Snare", 'ARCHIVE', x4(BB), vocab=[('4', [16], 'OWN'), ('24', [8], 'OWN')]),
  H1=T("Closed hat (not in the study)", 'OWN', [], vocab=[([1], 'OWN'), ([5], 'OWN'), ([9], 'OWN'), ([13], 'OWN')]),
  H2=T("Open hat", 'ARCHIVE', [11], vocab=[([15], 'ARCHIVE')]),
  P1=T("Ghost snare (quiet)", 'ARCHIVE', [3, 11, 16]),
  P2=T("Congas", 'OWN', [], vocab=[([7], 'OWN'), ([8], 'OWN'), ([15], 'OWN'), ([16], 'OWN'), ([4], 'OWN'), ([12], 'OWN')]))),

dict(name="Back In Black", who="AC/DC, 1980 (Phil Rudd)", bpm=94, timing='Shake', row=1, sec=None, res=6,
 tracks=dict(
  K=T("Kick", 'BOOK', last([1, 9], [1, 6, 9, 12]), vocab=[('24', [11], 'OWN'), ('13', [11], 'OWN')]),
  S=T("Snare", 'BOOK', last(BB, [5, 8, 11, 14, 15]), vocab=[('24', [15], 'OWN')]),
  H1=T("Closed hat", 'BOOK', E8),
  H2=T("Half-open hat", 'OWN', [], vocab=[([9], 'BOOK'), ([15], 'OWN')]),
  P1=T("Tambourine", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]),
  P2=T("Crash", 'OWN', [], vocab=[([1], 'OWN')]))),

dict(name="Dembow", who="from Shabba Ranks' 'Dem Bow' (1990) and the Poco Man Jam riddim", bpm=96, timing='Shake', row=1, sec=None, res=7,
 tracks=dict(
  K=T("Kick", 'ARCHIVE', x4(Q), vocab=[('4', [15], 'OWN'), ('24', [7], 'OWN')]),
  S=T("Snare / rim", 'ARCHIVE', x4([4, 7, 12, 15]), vocab=[('4', [16], 'OWN'), ('24', [11], 'OWN')]),
  H1=T("Closed hat", 'ARCHIVE', E8),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Shaker", 'ARCHIVE', ALL),
  P2=T("Clap or timbale", 'OWN', [], vocab=[([7], 'OWN'), ([15], 'OWN'), ([4], 'OWN'), ([12], 'OWN')]))),

dict(name="Superstition", who="Stevie Wonder, 1972 (Stevie on drums)", bpm=100, timing='Shake', row=6, sec=None, res=8,
 tracks=dict(
  K=T("Kick", 'BOOK', x4(Q), vocab=[('4', [16], 'OWN'), ('24', [12], 'OWN')]),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [16], 'OWN'), ('24', [8], 'OWN')]),
  H1=T("Closed hat (swung 16ths)", 'BOOK', [1, 3, 5, 7, 8, 9, 10, 11, 13, 15, 16],
       var=[([1, 3, 5, 7, 8, 9, 11, 12, 13, 14, 15], 'BOOK'), ([1, 3, 5, 7, 8, 9, 11, 13, 14, 15, 16], 'BOOK'),
            ([1, 3, 5, 7, 8, 9, 11, 12, 13, 14, 15, 16], 'BOOK')]),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Ghost snare (quiet)", 'OWN', [], vocab=[([8], 'OWN'), ([16], 'OWN'), ([10], 'OWN')]),
  P2=T("Tambourine", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Lust For Life", who="Iggy Pop, 1977 (Hunt Sales)", bpm=102, timing='Shake', row=1, sec="the floor-tom intro rhythm (BOOK p86)", res=9,
 tracks=dict(
  K=T("Kick", 'BOOK', alt([1, 5, 9, 15], [3, 7, 9]), vocab=[('4', [16], 'OWN')]),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [16], 'OWN'), ('24', [15], 'OWN')]),
  H1=T("Half-open hat", 'BOOK', Q),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Tambourine", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]),
  P2=T("Floor toms", 'BOOK', [], B=[1, 5, 9, 15], Bsrc='BOOK', vocab=[([1], 'BOOK'), ([9], 'BOOK'), ([3], 'BOOK'), ([7], 'BOOK')]))),

dict(name="Rock Steady", who="Aretha Franklin, 1971 (Bernard Purdie)", bpm=104, timing='Shake', row=2, sec=None, res=10,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 3, 8, 11]), vocab=[('4', [16], 'OWN'), ('24', [14], 'OWN')]),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'BOOK', [1, 5, 7, 9, 13, 15]),
  H2=T("Open hat", 'BOOK', [3, 11]),
  P1=T("Ghost snare (quiet)", 'BOOK', [2, 6, 8, 10, 14], vocab=[([16], 'OWN'), ([12], 'OWN')]),
  P2=T("Handclap", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Ain't Nobody", who="Rufus & Chaka Khan, 1983 (John 'JR' Robinson)", bpm=104, timing='Shake', row=1, sec="the chorus at 1:23: hats open on 14 and 16 (BOOK p8)", res=11,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 2, 8, 12, 14, 16]), vocab=[('24', [10], 'OWN')]),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [15], 'OWN')]),
  H1=T("Closed hat", 'BOOK', [1, 2, 3, 4, 6, 7, 8, 12, 14, 15, 16], B=[1, 2, 3, 4, 6, 7, 8, 12, 15], Bsrc='BOOK'),
  H2=T("Open hat", 'BOOK', [], B=[14, 16], Bsrc='BOOK', vocab=[([15], 'OWN')]),
  P1=T("Shaker", 'OWN', [], vocab=[([3], 'OWN'), ([11], 'OWN')]),
  P2=T("Clap", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Afrobeats", who="genre grid (archive F8)", bpm=106, timing='Shake', row=2, sec=None, res=12,
 tracks=dict(
  K=T("Kick", 'ARCHIVE', x4([1, 7, 11]), vocab=[('24', [4], 'ARCHIVE'), ('24', [15], 'ARCHIVE'), ('13', [4], 'ARCHIVE'), ('24', [9], 'ARCHIVE')]),
  S=T("Rim", 'ARCHIVE', x4([4, 13]), vocab=[('24', [7], 'ARCHIVE'), ('4', [16], 'OWN')]),
  H1=T("Closed hat", 'ARCHIVE', [1, 3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16]),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Shaker (dense)", 'OWN', [], vocab=[([2], 'OWN'), ([6], 'OWN'), ([10], 'OWN'), ([14], 'OWN')]),
  P2=T("Conga / shaker", 'ARCHIVE', [3, 6, 11, 14], vocab=[([16], 'OWN')]))),

dict(name="New jack swing", who="Teddy Riley style (SuperTime study)", bpm=106, timing='Shake', row=6, sec=None, res=13,
 tracks=dict(
  K=T("Kick", 'ST', alt([1, 4, 7, 11], [1, 4, 10, 12]), vocab=[('13', [14], 'OWN')]),
  S=T("Snare", 'ST', alt(BB, [5, 13, 16]), vocab=[('13', [16], 'OWN')]),
  H1=T("Closed hat (swung 16ths)", 'ST', ALL),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Ghost snare (quiet)", 'ST', [8], vocab=[([16], 'OWN'), ([10], 'OWN')]),
  P2=T("Clap", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Pick Up The Pieces", who="Average White Band, 1974 (Robbie McIntosh)", bpm=107, timing='Shake', row=3, sec="the 0:20 and 0:30 versions (BOOK p99-100)", res=14,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 9, 11]), B=x4([1, 9, 11, 16]), Bsrc='BOOK', vocab=[('4', [16], 'BOOK')]),
  S=T("Snare", 'BOOK', x4(BB), B=alt([5, 8, 13, 16], [5, 8, 13, 14]), Bsrc='BOOK', vocab=[('24', [8], 'BOOK'), ('13', [8], 'BOOK')]),
  H1=T("Closed hat", 'BOOK', [1, 5, 7, 8, 9, 13, 15], B=[5, 7, 8, 9, 13, 15], Bsrc='BOOK'),
  H2=T("Open hat", 'BOOK', [3, 11], B=[3, 11, 16], Bsrc='BOOK'),
  P1=T("Ghost snare (quiet)", 'OWN', [], vocab=[([10], 'OWN'), ([14], 'OWN')]),
  P2=T("Cowbell", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')]))),

dict(name="Sex Machine", who="James Brown, 1970 (Jabo Starks)", bpm=107, timing='Shake', row=6, sec=None, res=15,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 11]), vocab=[('24', [4], 'OWN'), ('4', [16], 'OWN')]),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'BOOK', [1, 5, 7, 8, 9, 13, 15]),
  H2=T("Open hat", 'BOOK', [3, 11]),
  P1=T("Ghost snare (quiet)", 'BOOK', [7, 8, 10, 16]),
  P2=T("Cowbell", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')]))),

dict(name="Soul Man", who="Sam & Dave, 1967 (Al Jackson Jr.)", bpm=112, timing='Shake', row=4, sec="the bridge at 0:34: kick on every 8th (BOOK p124)", res=16,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 8, 9, 11, 16]), B=x4(E8), Bsrc='BOOK'),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('24', [15], 'OWN')]),
  H1=T("Closed hat", 'BOOK', E8),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Ghost snare (quiet)", 'OWN', [], vocab=[([8], 'OWN'), ([16], 'OWN')]),
  P2=T("Tambourine", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Cold Sweat", who="James Brown, 1967 (Clyde Stubblefield)", bpm=112, timing='Shake', row=1, sec=None, res=17,
 tracks=dict(
  K=T("Kick", 'BOOK', alt([1, 11], [3, 11])),
  S=T("Snare", 'BOOK', alt([5, 15], BB)),
  H1=T("Closed hat", 'BOOK', [1, 3, 5, 7, 9, 13, 15]),
  H2=T("Open hat", 'BOOK', [11]),
  P1=T("Ghost snare (quiet)", 'BOOK', [8, 10], vocab=[([2], 'BOOK')], var=[([2, 8, 10], 'BOOK')]),
  P2=T("Cowbell", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')]))),

dict(name="Disco (Philly, Earl Young)", who="Earl Young style (SuperTime study)", bpm=112, timing='Shake', row=1, sec=None, res=18,
 tracks=dict(
  K=T("Kick", 'ST', x4(Q)),
  S=T("Snare", 'ST', alt(BB, [5, 13, 15, 16])),
  H1=T("Pedal / closed hat", 'ST', Q),
  H2=T("Open hat", 'ST', [3, 7, 11, 15]),
  P1=T("Ghost snare (quiet)", 'ST', [8, 16], vocab=[([10], 'ST'), ([14], 'ST')], var=[([10, 14], 'ST')]),
  P2=T("Tambourine", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Like I Love You", who="Justin Timberlake, 2002 (Pharrell Williams)", bpm=115, timing='Shake', row=1, sec="the 0:31 variation, used loosely (BOOK p82)", res=26,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 4, 11, 14]), vocab=[('4', [16], 'OWN')]),
  S=T("Snare", 'BOOK', x4(BB), B=x4([5, 8, 13]), Bsrc='BOOK', vocab=[('24', [8], 'BOOK')]),
  H1=T("Closed hat", 'BOOK', E8),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Ghost snare (quiet)", 'BOOK', [2, 8, 10, 16], B=[2, 16], Bsrc='BOOK'),
  P2=T("Hat accent (the loud beats)", 'OWN', [], vocab=[([1], 'OWN'), ([5], 'OWN'), ([9], 'OWN'), ([13], 'OWN')]))),

dict(name="Word Up", who="Cameo, 1986 (Larry Blackmon)", bpm=116, timing='Shake', row=1, sec="the 2:17 variation (BOOK p158)", res=19,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 7]), B=x4([1, 7, 16]), Bsrc='BOOK', vocab=[('4', [16], 'BOOK')]),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'BOOK', [1, 5, 9, 11, 13], B=Q, Bsrc='BOOK'),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Shaker", 'OWN', [], vocab=[([3], 'OWN'), ([7], 'OWN'), ([15], 'OWN')]),
  P2=T("Clap", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Billie Jean", who="Michael Jackson, 1982 (N'dugu Chancler, LinnDrum)", bpm=117, timing='Shake', row=1, sec="the pre-chorus at 1:22: hats open on 7 and 15 (BOOK p24)", res=20,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 9])),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [16], 'BOOK')]),
  H1=T("Closed hat", 'BOOK', E8, B=[1, 3, 5, 9, 11, 13], Bsrc='BOOK'),
  H2=T("Open hat", 'BOOK', [], B=[7, 15], Bsrc='BOOK', vocab=[([15], 'BOOK')]),
  P1=T("Shaker", 'OWN', [], vocab=[([3], 'OWN'), ([11], 'OWN')]),
  P2=T("Clap", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Smells Like Teen Spirit", who="Nirvana, 1991 (Dave Grohl)", bpm=117, timing='Shake', row=1, sec="the intro figure (BOOK p123)", res=21,
 tracks=dict(
  K=T("Kick", 'BOOK', x4([1, 4, 9, 11, 12, 15]), B=x4([2, 4, 6, 8, 10, 12, 15]), Bsrc='BOOK'),
  S=T("Snare", 'BOOK', x4([5, 8, 10, 13]), B=x4(Q), Bsrc='BOOK'),
  H1=T("Half-open hat", 'BOOK', Q),
  H2=T("Open hat", 'BOOK', [], B=[3, 7, 11], Bsrc='BOOK', vocab=[([3], 'BOOK'), ([11], 'BOOK')]),
  P1=T("Floor tom", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')]),
  P2=T("Crash", 'OWN', [], vocab=[([1], 'OWN')]))),

dict(name="Apache", who="Incredible Bongo Band, 1973 (Jim Gordon; bongos King Errisson)", bpm=118, timing='Shake', row=1, sec=None, res=22,
 tracks=dict(
  K=T("Kick", 'AINSWORTH', alt([1, 3, 11], [1, 3, 7, 11])),
  S=T("Snare", 'AINSWORTH', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'AINSWORTH', E8),
  H2=T("Open hat", 'AINSWORTH', [], vocab=[([7], 'AINSWORTH'), ([15], 'OWN')]),
  P1=T("Ghost snare (quiet)", 'AINSWORTH', [10, 16]),
  P2=T("Bongos", 'OWN', [], vocab=[([1], 'OWN'), ([3], 'OWN'), ([8], 'OWN'), ([10], 'OWN'), ([12], 'OWN')]))),

dict(name="Chicago house", who="Chicago jack house (SuperTime study)", bpm=124, timing='Shake', row=2, sec=None, res=23,
 tracks=dict(
  K=T("Kick", 'ST', x4(Q)),
  S=T("Clap", 'ST', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'ST', [1, 2, 4, 5, 6, 8, 9, 10, 12, 13, 14, 16]),
  H2=T("Open hat", 'ST', [3, 7, 11, 15]),
  P1=T("Shaker", 'OWN', [], vocab=[([4], 'OWN'), ([8], 'OWN'), ([12], 'OWN'), ([16], 'OWN')]),
  P2=T("Rim / cowbell", 'OWN', [], vocab=[([7], 'OWN'), ([15], 'OWN')]))),

dict(name="I Feel Love", who="Donna Summer / Giorgio Moroder, 1977 (kick: Keith Forsey)", bpm=126.5, timing='Shake', row=1, sec=None, res=24,
 tracks=dict(
  K=T("Kick", 'ARTICLES', x4(Q)),
  S=T("Snare / clap (not sourced)", 'OWN', x4([]), vocab=[('24', [13], 'OWN'), ('13', [13], 'OWN'), ('24', [5], 'OWN'), ('13', [5], 'OWN')]),
  H1=T("Offbeat hat (filtered noise)", 'ARTICLES', [3, 7, 11, 15]),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("16th hat / noise tick", 'OWN', [], vocab=[([2], 'OWN'), ([10], 'OWN')]),
  P2=T("Clap", 'OWN', [], vocab=[([13], 'OWN'), ([5], 'OWN')]))),

dict(name="Planet Rock / electro", who="electro hip-hop study (the Planet Rock family, 1982)", bpm=127, timing='Shake', row=1, sec=None, res=25,
 tracks=dict(
  K=T("Kick", 'ST', alt([1, 7, 11], [1, 4, 7, 11])),
  S=T("Snare / clap", 'ST', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'ST', ALL),
  H2=T("Open hat", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Clap (doubles)", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]),
  P2=T("Cowbell", 'ST', [3, 8, 11], vocab=[([15], 'ST')], var=[([3, 8, 11, 15], 'ST')]))),

dict(name="Blue Monday", who="New Order, 1983 (Oberheim DMX)", bpm=130, timing='Shake', row=1, sec="the 1:04 house beat (BOOK p27)", res=27,
 tracks=dict(
  K=T("Kick", 'BOOK', alt([1, 5, 9, 10, 11, 12, 13, 14, 15, 16], Q), B=x4(Q), Bsrc='BOOK'),
  S=T("Snare", 'BOOK', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'BOOK', [3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16], var=[([1, 3, 4, 5, 7, 8, 11, 12, 13, 15, 16], 'BOOK')]),
  H2=T("Open hat", 'BOOK', [], B=[3, 7, 11, 15], Bsrc='BOOK', vocab=[([3], 'BOOK'), ([11], 'BOOK')]),
  P1=T("Shaker", 'OWN', [], vocab=[([2], 'OWN'), ([10], 'OWN')]),
  P2=T("Clap", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Detroit techno", who="techno study (archive; programming by CrimethInc.)", bpm=134, timing='Shake', row=1, sec=None, res=28,
 tracks=dict(
  K=T("Kick", 'ARCHIVE', x4(Q)),
  S=T("Clap", 'ARCHIVE', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat (offbeat)", 'ARCHIVE', [3, 7, 11, 15]),
  H2=T("Open hat", 'ARCHIVE', [15], vocab=[([7], 'OWN')]),
  P1=T("Tight hat (quiet)", 'ARCHIVE', [4, 8, 12, 16]),
  P2=T("Ride", 'ARCHIVE', E8))),

dict(name="Motorik", who="Neu!, 'Hallogallo' style (Klaus Dinger; SuperTime study)", bpm=136, timing='Shake', row=1, sec=None, res=29,
 tracks=dict(
  K=T("Kick", 'ST', x4([1, 9, 11])),
  S=T("Snare", 'ST', x4(BB), vocab=[('4', [16], 'OWN')]),
  H1=T("Closed hat", 'ST', E8),
  H2=T("Open hat", 'ST', [], vocab=[([15], 'ST')]),
  P1=T("Tambourine", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]),
  P2=T("Floor tom", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')]))),

dict(name="Jungle (Think break)", who="Lyn Collins, 'Think (About It)', 1972 (Jabo Starks), chopped jungle-style", bpm=165, timing='Shake', row=2, sec=None, res=30,
 tracks=dict(
  K=T("Kick", 'AINSWORTH', x4([1]), vocab=[('24', [11], 'OWN'), ('13', [11], 'OWN'), ('24', [3], 'OWN'), ('4', [14], 'OWN')]),
  S=T("Snare", 'AINSWORTH', x4(BB), vocab=[('24', [16], 'OWN'), ('4', [15], 'OWN'), ('24', [8], 'OWN'), ('13', [16], 'OWN')]),
  H1=T("Closed hat", 'AINSWORTH', [1, 3, 5, 7, 9, 11, 13]),
  H2=T("Open hat", 'AINSWORTH', [15], vocab=[([11], 'AINSWORTH')]),
  P1=T("Tambourine", 'AINSWORTH', ALL),
  P2=T("Ghost snare (quiet)", 'AINSWORTH', [8, 10, 11], vocab=[([16], 'AINSWORTH')]))),

dict(name="Rock Around The Clock", who="Bill Haley & His Comets, 1954 (Billy Gussak)", bpm=178, timing='Trip', row=5, trip=True, sec="the 4th verse at 1:15: the backbeat arrives (BOOK p108)", res=31,
 tracks=dict(
  K=T("Kick (soft, feathered)", 'BOOK', x4(Q)),
  S=T("Snare (rimshot)", 'BOOK', alt([], [11, 13]), B=x4(BB), Bsrc='BOOK', vocab=[('24', [15], 'BOOK')]),
  H1=T("Snare on the hoop / shuffle", 'BOOK', E8),
  H2=T("Crash or open hat", 'OWN', [], vocab=[([1], 'OWN'), ([9], 'OWN')]),
  P1=T("Brush / shaker", 'OWN', [], vocab=[([3], 'OWN'), ([11], 'OWN')]),
  P2=T("Woodblock / rim", 'OWN', [], vocab=[([5], 'OWN'), ([13], 'OWN')]))),

dict(name="Sing, Sing, Sing", who="Benny Goodman, 1937 (Gene Krupa)", bpm=216, timing='Trip', row=5, trip=True, sec=None, res=32,
 tracks=dict(
  K=T("Kick (soft, feathered)", 'BOOK', x4(Q)),
  S=T("Snare (not in the classic)", 'OWN', x4([]), vocab=[('24', [13], 'OWN'), ('13', [13], 'OWN'), ('24', [5], 'OWN')]),
  H1=T("Hi-hat foot", 'BOOK', [5, 13]),
  H2=T("Snare press roll (for Rolls)", 'OWN', [], vocab=[([15], 'OWN'), ([7], 'OWN')]),
  P1=T("Floor tom", 'BOOK', E8),
  P2=T("Tom accents", 'BOOK', [1, 5, 9, 11], vocab=[([7], 'BOOK')], var=[([1, 5, 7, 11], 'BOOK')]))),
]
for i, b in enumerate(BANKS):
    b['n'] = i + 1
    b.setdefault('trip', False)
