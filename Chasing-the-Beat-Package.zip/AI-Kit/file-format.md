# The PatternBank file format

Every rule here is read from the 64 card files in this package and from the script that wrote them (`tools/lf_build.py`, function `write_bank`). `tools/validate.py` checks all of them.

## A real example

The first lines of bank 27, Blue Monday (`PatternBank026.txt`). Kick, slots 1 to 4, then the first Hihat 1 lines:

```
KICK > PTN0: 1000000000000000, 0000000000000000, 1000000000000000, 0000000000000000;
KICK > PTN1: 1000000000000000, 1000000000000000, 1000000000000000, 1000000000000000;
KICK > PTN2: 1000000010000000, 1000000010000000, 1000000010000000, 1000000010000000;
KICK > PTN3: 1000100010000000, 1000100010000000, 1000100010000000, 1000100010000000;
...
HIHAT1 > PTN0: 0000000010000000;
```

Read the first line like this: Kick, slot 1. Four bars. Bar 1 has a hit on step 1 only. Bar 2 is empty. Bar 3 hits step 1. Bar 4 is empty. The last line: Hihat 1, slot 1, one bar, a hit on step 9 (beat 3), every bar.

## The rules

A file loads (and matches the card) when all of these hold:

1. **File name:** `PatternBank000.txt` to `PatternBank063.txt`, three digits. File N is bank N+1.
2. **Plain ASCII text.**
3. **Six tracks, in this order:** `KICK`, `SNARE`, `HIHAT1`, `HIHAT2`, `PERC1`, `PERC2`. No space inside `HIHAT1`, `PERC1` and so on.
4. **24 patterns per track**, numbered `PTN0` to `PTN23`, in order. `PTN0` is knob slot 1.
5. **Each line is:** track name, space, `>`, space, `PTN` and the number, colon, space, the steps, then `;`.
   Example: `SNARE > PTN4: 0000100000001000, 0000100000001000, 0000100000001000, 0000100000001001;`
6. **KICK and SNARE have four bars.** Each bar is 16 characters. Bars are separated by a comma and one space (`, `).
7. **HIHAT1, HIHAT2, PERC1 and PERC2 have one bar** of 16 characters.
8. **Steps are only `0` (off) or `1` (on).** Nothing else: no spaces inside a bar, no other digits.
9. **One empty line between tracks** (5 in all). No empty line at the top or the end.
10. **Windows line endings (CR LF) on every line, including the last.**

That makes every good file exactly **149 lines** (144 pattern lines and 5 empty ones) and **7,462 bytes**. If your file has another size, something is off.

Rules 9 and 10 are how every card file is written. Whether the module would also load a file without them hasn't been tested. Match the card exactly and it isn't a question.

## Things the format can't say

- No tempo, swing, Feel, Linear or mutes: they are global settings on the module (see `module.md`). Put the home setting in your note to the user.
- No loud or soft hits, no names, no comments. A line that isn't a pattern breaks the file.
- No triplet grid. Triplet banks use steps 1 and 3 of each beat (see `module.md`, "Triplets").

## Writing a file safely

Write the patterns as data first (lists of step numbers per bar), then turn them into lines with code, then run the validator. Typing 144 lines of 0s and 1s by hand goes wrong.

A Python sketch that writes the exact format:

```python
TRACKS = ["KICK", "SNARE", "HIHAT1", "HIHAT2", "PERC1", "PERC2"]

def bar(steps):                      # steps: list of step numbers 1-16
    return "".join("1" if s in steps else "0" for s in range(1, 17))

def write_bank(path, bank):          # bank: {track: [24 patterns]}, pattern = list of bars
    lines = []
    for t in TRACKS:
        pats = bank[t]
        assert len(pats) == 24
        for i, p in enumerate(pats):
            assert len(p) == (4 if t in ("KICK", "SNARE") else 1)
            lines.append(f"{t} > PTN{i}: " + ", ".join(bar(b) for b in p) + ";")
        lines.append("")
    text = "\r\n".join(lines[:-1]) + "\r\n"
    with open(path, "w", newline="") as fh:
        fh.write(text)
```

Then check it:

```
python3 -B tools/validate.py PatternBank040.txt
```
