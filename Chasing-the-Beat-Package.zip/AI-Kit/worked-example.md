# Worked example: bank 27, Blue Monday

This file follows one bank from its source grid to all 24 slots on all six tracks, slot by slot, and names the rule from `the-arc.md` behind every change. Read `the-arc.md` first. Then read this until you could have written the bank yourself.

Why this bank: it has a documented second section (a B part), a classic with a different bar 1 and bar 2, three tracks the record leaves silent, and a straight home setting. That covers most of the method. Every pattern below is read from the card file `PatternBank026.txt`. Every label comes from the build's per-hit source index.

How to read the tables:
- **Steps** are the steps that play (1 to 16). For Kick and Snare, the four bars are separated by `/`, and `-` is an empty bar.
- **(beat)**, **(e)**, **(+)**, **(a)** name where in the beat a step sits (`module.md`).
- **[OWN]** means the builder invented the hit. **[BOOK]** means it's in the book. Build-up hits are the classic's own and carry its label.

## Step 0: the source

From the book *The Greatest Drum Beats*, page 27 (BOOK p27). Two bars:

```
         1 e + a 2 e + a 3 e + a 4 e + a
Kick b1  x . . . x . . . x x x x x x x x     the 16th run on beats 3 and 4
Kick b2  x . . . x . . . x . . . x . . .
Snare    . . . . x . . . . . . . x . . .     both bars
Hats b1  x . x x x . x x . . x x x . x x     no hat on beat 3
Hats b2  . . x x x . x x x . x x x . x x     no hat on beat 1
```

The book says the hats leave beat 3 (bar 1) and beat 1 (bar 2) bare so the kick punches through.

**B part:** the beat at 1:04, the plain dance beat: kick on every beat, snare on 2 and 4, open hat on every + (3, 7, 11, 15). Also BOOK p27.

**Tempo:** 130 BPM. **Home setting:** Shake 1, Tight (straight: a drum machine).

## Laying out the six tracks

| Track | Sound | Classic | Why |
|---|---|---|---|
| Kick | Kick | the book's 2 bars, as bars 1-2 and 3-4 | Kick runs 4 bars, so the 2-bar figure repeats: bars 1 and 3 have the run, bars 2 and 4 don't. |
| Snare | Snare | 5, 13 every bar | The backbeat. |
| Hihat 1 | Closed hat | **bar 2's hats** | Hats loop 1 bar, so only one bar can be the classic. Bar 2 is chosen; bar 1 becomes a variation (slot 21). |
| Hihat 2 | Open hat | **silence** | No open hat in the main groove. The B part's open hats (3, 7, 11, 15) are its vocabulary. |
| Perc 1 | Shaker | **silence** | Not on the record. All OWN. The dense part, so it's on Perc 1. |
| Perc 2 | Clap | **silence** | Not on the record. All OWN. |

Vocabulary written down before building:
- Snare: one OWN pickup on 16 in bar 4.
- Hihat 2: the B part's 3 and 11 first.
- Perc 1: OWN 2 and 10 (shaker on the e). Perc 2: OWN 5 and 13 (clap on the backbeat).

## Step 1: the peaks (slot 20)

Worked out first, because the middle climbs a set share of the way to them.

| Track | Peak | How |
|---|---|---|
| Kick | 1,3,5,7,9,10-16 / every 8th / same as bar 1 / every 8th + 14, 16 (42 hits) | Every 8th, plus the classic's 16th run in bars 1 and 3 (the classic is always inside the peak), plus the bar-4 pickup 14, 16. |
| Snare | 5,7,13,15 / 3,5,7,11,13,15 / 5,7,13,15 / 3,5,7,11,13,14,15,16 (22 hits) | Backbeat plus the 8th offbeats around it; bars 2 and 4 add 3 and 11; bar 4 the pickup. |
| Hihat 1 | every 16th (16) | |
| Hihat 2 | every 8th (8) | 8ths only, so Rolls has room. |
| Perc 1, Perc 2 | every 16th (16 each) | |

Bank total at 20: **120 hits**.

## Kick

The classic has 28 hits, so it arrives over 8 slots (the most allowed). Order: beats (1, then 9, 5, 13), then the + of the run (11, 15), then the a (12, 16), then the e (10, 14). Bars 1 and 3 before 2 and 4: that's why slot 1 is the downbeat in bars 1 and 3 only.

The middle (9 to 16) climbs toward 60% of the way to the peak: from 28 to 36 hits. There's no vocabulary on this track, so every added hit is OWN, and since the bank is straight they go on 8ths (the +) first, bars 2 and 4 first. When a slot's target count is already met, the slot keeps the count and moves one added hit instead (slots 10, 12, 14), so no two slots repeat. Slots 15 and 16 build bar 4's pickup.

At 17 the drop is beat 1 in bars 1 to 3 and nothing in bar 4: the plain "1 every bar" is already slot 2, and "1 in bars 1 and 3" is slot 1, so the next drop shape is used. At 18 the B part (kick on every beat) would repeat slot 5, so it takes one hit more. 21 to 24 are the classic plus one OWN pair each, all 30 hits.

| Slot | Steps (bar 1 / 2 / 3 / 4) | Hits | What changed, and the rule |
|---|---|---|---|
| 1 | 1 / - / 1 / - | 2 | Build-up starts with the classic's strongest hit: 1 (beat) bars 1+3. |
| 2 | 1 / 1 / 1 / 1 | 4 | Build-up: the classic's next hits arrive: 1 (beat) bars 2+4. |
| 3 | 1,9 / 1,9 / 1,9 / 1,9 | 8 | Build-up: the classic's next hits arrive: 9 (beat) all bars. |
| 4 | 1,5,9 / 1,5,9 / 1,5,9 / 1,5,9 | 12 | Build-up: the classic's next hits arrive: 5 (beat) all bars. |
| 5 | 1,5,9,13 / 1,5,9,13 / 1,5,9,13 / 1,5,9,13 | 16 | Build-up: the classic's next hits arrive: 13 (beat) all bars. |
| 6 | 1,5,9,11,13,15 / 1,5,9,13 / 1,5,9,11,13,15 / 1,5,9,13 | 20 | Build-up: the classic's next hits arrive: 11 (+) bars 1+3; 15 (+) bars 1+3. |
| 7 | 1,5,9,11,12,13,15,16 / 1,5,9,13 / 1,5,9,11,12,13,15,16 / 1,5,9,13 | 24 | Build-up: the classic's next hits arrive: 12 (a) bars 1+3; 16 (a) bars 1+3. |
| 8 | 1,5,9,10,11,12,13,14,15,16 / 1,5,9,13 / 1,5,9,10,11,12,13,14,15,16 / 1,5,9,13 | 28 | Build-up: the classic's next hits arrive: 10 (e) bars 1+3; 14 (e) bars 1+3. Classic complete. |
| 9 | 1,5,9,10,11,12,13,14,15,16 / 1,3,5,9,13 / 1,5,9,10,11,12,13,14,15,16 / 1,3,5,9,13 | 30 | Middle: add 3 (+) bars 2+4 [OWN]. |
| 10 | 1,3,5,9,10,11,12,13,14,15,16 / 1,5,9,13 / 1,3,5,9,10,11,12,13,14,15,16 / 1,5,9,13 | 30 | Middle, keep the count: move a hit from 3 (+) bars 2+4 to 3 (+) bars 1+3 [OWN]. |
| 11 | 1,3,5,9,10,11,12,13,14,15,16 / 1,5,7,9,13 / 1,3,5,9,10,11,12,13,14,15,16 / 1,5,7,9,13 | 32 | Middle: add 7 (+) bars 2+4 [OWN]. |
| 12 | 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13 / 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13 | 32 | Middle, keep the count: move a hit from 7 (+) bars 2+4 to 7 (+) bars 1+3 [OWN]. |
| 13 | 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,11,13 / 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,11,13 | 34 | Middle: add 11 (+) bars 2+4 [OWN]. |
| 14 | 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13,15 / 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13,15 | 34 | Middle, keep the count: move a hit from 11 (+) bars 2+4 to 15 (+) bars 2+4 [OWN]. |
| 15 | 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13,15 / 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13,15,16 | 35 | Middle: add 16 (a) bar 4 [OWN]. |
| 16 | 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13,15 / 1,3,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13,14,15,16 | 36 | Middle: add 14 (e) bar 4 [OWN]. |
| 17 | 1 / 1 / 1 / - | 3 | Drop. |
| 18 | 1,5,9,13 / 1,3,5,9,13 / 1,5,9,13 / 1,3,5,9,13 | 18 | B part (1,5,9,13 / 1,5,9,13 / 1,5,9,13 / 1,5,9,13) plus 3 (+) bars 2+4 [OWN]: the plain B part is already slot 5, so it gets a hit to stay new. |
| 19 | 1,3,5,7,9,11,13 / 1,3,5,7,9,11,13,15 / 1,3,5,7,9,11,13 / 1,3,5,7,9,11,13,15 | 30 | Climb: half the remaining way to the peak (adds 3 (+) bars 1+3; 7 (+) all bars; 11 (+) all bars; 15 (+) bars 2+4). |
| 20 | 1,3,5,7,9,10,11,12,13,14,15,16 / 1,3,5,7,9,11,13,15 / 1,3,5,7,9,10,11,12,13,14,15,16 / 1,3,5,7,9,11,13,14,15,16 | 42 | Peak (adds 10 (e) bars 1+3; 12 (a) bars 1+3; 14 (e) bar 1+3+4; 15 (+) bars 1+3; 16 (a) bar 1+3+4). |
| 21 | 1,5,9,10,11,12,13,14,15,16 / 1,5,7,9,13 / 1,5,9,10,11,12,13,14,15,16 / 1,5,7,9,13 | 30 | Variation: the classic plus 7 (+) bars 2+4 [OWN]. |
| 22 | 1,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13 / 1,5,7,9,10,11,12,13,14,15,16 / 1,5,9,13 | 30 | Variation: the classic plus 7 (+) bars 1+3 [OWN]. |
| 23 | 1,5,9,10,11,12,13,14,15,16 / 1,5,9,11,13 / 1,5,9,10,11,12,13,14,15,16 / 1,5,9,11,13 | 30 | Variation: the classic plus 11 (+) bars 2+4 [OWN]. |
| 24 | 1,5,9,10,11,12,13,14,15,16 / 1,5,9,13,15 / 1,5,9,10,11,12,13,14,15,16 / 1,5,9,13,15 | 30 | Variation: the classic plus 15 (+) bars 2+4 [OWN]. |

## Snare

Eight hits, so the classic is complete at slot 4. The middle starts from the vocabulary: the OWN pickup on 16 in bar 4 (slot 5). Then OWN 8ths, bars 2 and 4 first, with count-keeping moves. The drop keeps the backbeat and thins bar 4 to beat 2 only: the full backbeat would repeat slot 4. The snare has no B part, so 18 is slot 16 plus a third of the way to the peak, and 19 half the rest.

| Slot | Steps (bar 1 / 2 / 3 / 4) | Hits | What changed, and the rule |
|---|---|---|---|
| 1 | 5 / - / 5 / - | 2 | Build-up starts with the classic's strongest hit: 5 (beat) bars 1+3. |
| 2 | 5 / 5 / 5 / 5 | 4 | Build-up: the classic's next hits arrive: 5 (beat) bars 2+4. |
| 3 | 5,13 / 5 / 5,13 / 5 | 6 | Build-up: the classic's next hits arrive: 13 (beat) bars 1+3. |
| 4 | 5,13 / 5,13 / 5,13 / 5,13 | 8 | Build-up: the classic's next hits arrive: 13 (beat) bars 2+4. Classic complete. |
| 5 | 5,13 / 5,13 / 5,13 / 5,13,16 | 9 | Middle: add 16 (a) bar 4 [OWN]. |
| 6 | 5,13 / 5,13 / 5,13 / 5,13,14 | 9 | Middle, keep the count: move a hit from 16 (a) bar 4 to 14 (e) bar 4 [OWN]. |
| 7 | 5,13 / 3,5,13 / 5,13 / 3,5,13,14 | 11 | Middle: add 3 (+) bars 2+4 [OWN]. |
| 8 | 5,13 / 5,7,13 / 5,13 / 5,7,13,14 | 11 | Middle, keep the count: move a hit from 3 (+) bars 2+4 to 7 (+) bars 2+4 [OWN]. |
| 9 | 5,7,13 / 5,13 / 5,7,13 / 5,13,14 | 11 | Middle, keep the count: move a hit from 7 (+) bars 2+4 to 7 (+) bars 1+3 [OWN]. |
| 10 | 5,7,13 / 5,11,13 / 5,7,13 / 5,11,13,14 | 13 | Middle: add 11 (+) bars 2+4 [OWN]. |
| 11 | 5,7,13 / 5,13,15 / 5,7,13 / 5,13,14,15 | 13 | Middle, keep the count: move a hit from 11 (+) bars 2+4 to 15 (+) bars 2+4 [OWN]. |
| 12 | 5,7,13,15 / 5,13 / 5,7,13,15 / 5,13,14 | 13 | Middle, keep the count: move a hit from 15 (+) bars 2+4 to 15 (+) bars 1+3 [OWN]. |
| 13 | 5,7,13,15 / 5,13 / 5,7,13,15 / 5,13,14,16 | 14 | Middle: add 16 (a) bar 4 [OWN]. |
| 14 | 5,7,13,15 / 3,5,13 / 5,7,13,15 / 3,5,13,14,16 | 16 | Middle: add 3 (+) bars 2+4 [OWN]. |
| 15 | 5,7,13,15 / 5,7,13 / 5,7,13,15 / 5,7,13,14,16 | 16 | Middle, keep the count: move a hit from 3 (+) bars 2+4 to 7 (+) bars 2+4 [OWN]. |
| 16 | 5,7,13,15 / 5,11,13 / 5,7,13,15 / 5,11,13,14,16 | 16 | Middle, keep the count: move a hit from 7 (+) bars 2+4 to 11 (+) bars 2+4 [OWN]. |
| 17 | 5,13 / 5,13 / 5,13 / 5 | 7 | Drop. |
| 18 | 5,7,13,15 / 3,5,11,13 / 5,7,13,15 / 3,5,11,13,14,16 | 18 | Climb, no B part for this track: slot 16 plus about a third of the way to the peak (adds 3 (+) bars 2+4). |
| 19 | 5,7,13,15 / 3,5,7,11,13 / 5,7,13,15 / 3,5,7,11,13,14,16 | 20 | Climb: half the remaining way to the peak (adds 7 (+) bars 2+4). |
| 20 | 5,7,13,15 / 3,5,7,11,13,15 / 5,7,13,15 / 3,5,7,11,13,14,15,16 | 22 | Peak (adds 15 (+) bars 2+4). |
| 21 | 5,13 / 3,5,13 / 5,13 / 3,5,13 | 10 | Variation: the classic plus 3 (+) bars 2+4 [OWN]. |
| 22 | 5,13 / 5,7,13 / 5,13 / 5,7,13 | 10 | Variation: the classic plus 7 (+) bars 2+4 [OWN]. |
| 23 | 5,7,13 / 5,13 / 5,7,13 / 5,13 | 10 | Variation: the classic plus 7 (+) bars 1+3 [OWN]. |
| 24 | 5,13 / 5,11,13 / 5,13 / 5,11,13 | 10 | Variation: the classic plus 11 (+) bars 2+4 [OWN]. |

## Hihat 1

Eleven hits over 8 slots: beats first (9, 5, 13: the classic has no hat on 1), then the + (3, 7, then 11 and 15), then the a. The middle adds OWN hits. Straight bank, so 8ths first, but the only 8th the classic lacks is 1; after that the e's. Most middle slots keep the count and move one hit along the e's: the hats are near full already. The drop is quarter notes. 21 is the source's own other bar (the book's bar 1), which is why it is the one variation that lacks beat 3.

| Slot | Steps | Hits | What changed, and the rule |
|---|---|---|---|
| 1 | 9 | 1 | Build-up starts with the classic's strongest hit: 9 (beat). |
| 2 | 5, 9 | 2 | Build-up: the classic's next hits arrive: 5 (beat). |
| 3 | 5, 9, 13 | 3 | Build-up: the classic's next hits arrive: 13 (beat). |
| 4 | 3, 5, 9, 13 | 4 | Build-up: the classic's next hits arrive: 3 (+). |
| 5 | 3, 5, 7, 9, 13 | 5 | Build-up: the classic's next hits arrive: 7 (+). |
| 6 | 3, 5, 7, 9, 11, 13, 15 | 7 | Build-up: the classic's next hits arrive: 11 (+), 15 (+). |
| 7 | 3, 4, 5, 7, 8, 9, 11, 13, 15 | 9 | Build-up: the classic's next hits arrive: 4 (a), 8 (a). |
| 8 | 3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16 | 11 | Build-up: the classic's next hits arrive: 12 (a), 16 (a). Classic complete. |
| 9 | 1, 3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16 | 12 | Middle: add 1 (beat) [OWN]. |
| 10 | 2, 3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16 | 12 | Middle, keep the count: move a hit from 1 (beat) to 2 (e) [OWN]. |
| 11 | 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 15, 16 | 12 | Middle, keep the count: move a hit from 2 (e) to 6 (e) [OWN]. |
| 12 | 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 15, 16 | 12 | Middle, keep the count: move a hit from 6 (e) to 10 (e) [OWN]. |
| 13 | 3, 4, 5, 7, 8, 9, 11, 12, 13, 14, 15, 16 | 12 | Middle, keep the count: move a hit from 10 (e) to 14 (e) [OWN]. |
| 14 | 1, 3, 4, 5, 7, 8, 9, 11, 12, 13, 14, 15, 16 | 13 | Middle: add 1 (beat) [OWN]. |
| 15 | 2, 3, 4, 5, 7, 8, 9, 11, 12, 13, 14, 15, 16 | 13 | Middle, keep the count: move a hit from 1 (beat) to 2 (e) [OWN]. |
| 16 | 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16 | 13 | Middle, keep the count: move a hit from 2 (e) to 6 (e) [OWN]. |
| 17 | 1, 5, 9, 13 | 4 | Drop. |
| 18 | 1, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16 | 14 | Climb, no B part for this track: slot 16 plus about a third of the way to the peak (adds 1 (beat)). |
| 19 | 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16 | 15 | Climb: half the remaining way to the peak (adds 2 (e)). |
| 20 | 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 | 16 | Peak (adds 10 (e)). |
| 21 | 1, 3, 4, 5, 7, 8, 11, 12, 13, 15, 16 | 11 | Variation: the source's own other bar first. The book's bar-1 hats (1, 3, 4, 5, 7, 8, 11, 12, 13, 15, 16: no hat on beat 3) [BOOK]. |
| 22 | 1, 2, 3, 4, 5, 7, 8, 9, 11, 12, 13, 15, 16 | 13 | Variation: the classic plus 1 (beat), 2 (e) [OWN]. |
| 23 | 1, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 15, 16 | 13 | Variation: the classic plus 1 (beat), 6 (e) [OWN]. |
| 24 | 1, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 15, 16 | 13 | Variation: the classic plus 1 (beat), 10 (e) [OWN]. |

## Hihat 2

The record has no open hat in the main groove, so the classic is silence and its knob is 17. Slot 1 is one hit: the first vocabulary hit, the B part's 3 (labelled BOOK). The middle climbs gently (40% of the way: to 4 hits by 16). The B part's other hits are held back for 18, so the middle moves a second hit around the beats first and only then uses the B part's 7, 11 and 15. The drop is empty: that's the record, and it keeps Rolls from filling the drop. 18 is the B part exactly. 20 is every 8th, for Rolls.

| Slot | Steps | Hits | What changed, and the rule |
|---|---|---|---|
| 1 | 3 | 1 | Start: the record has no part here, so slot 1 is one BOOK hit. |
| 2 | 1, 3 | 2 | Middle: add 1 (beat) [OWN]. |
| 3 | 3, 9 | 2 | Middle, keep the count: move a hit from 1 (beat) to 9 (beat) [OWN]. |
| 4 | 3, 5 | 2 | Middle, keep the count: move a hit from 9 (beat) to 5 (beat) [OWN]. |
| 5 | 3, 13 | 2 | Middle, keep the count: move a hit from 5 (beat) to 13 (beat) [OWN]. |
| 6 | 3, 11 | 2 | Middle, keep the count: move a hit from 13 (beat) to 11 (+) [BOOK]. |
| 7 | 3, 7 | 2 | Middle, keep the count: move a hit from 11 (+) to 7 (+) [BOOK]. |
| 8 | 3, 15 | 2 | Middle, keep the count: move a hit from 7 (+) to 15 (+) [BOOK]. |
| 9 | 3, 11, 15 | 3 | Middle: add 11 (+) [BOOK]. |
| 10 | 1, 3, 15 | 3 | Middle, keep the count: move a hit from 11 (+) to 1 (beat) [OWN]. |
| 11 | 3, 9, 15 | 3 | Middle, keep the count: move a hit from 1 (beat) to 9 (beat) [OWN]. |
| 12 | 3, 5, 15 | 3 | Middle, keep the count: move a hit from 9 (beat) to 5 (beat) [OWN]. |
| 13 | 3, 13, 15 | 3 | Middle, keep the count: move a hit from 5 (beat) to 13 (beat) [OWN]. |
| 14 | 3, 11, 13, 15 | 4 | Middle: add 11 (+) [BOOK]. |
| 15 | 3, 7, 13, 15 | 4 | Middle, keep the count: move a hit from 11 (+) to 7 (+) [BOOK]. |
| 16 | 1, 3, 13, 15 | 4 | Middle, keep the count: move a hit from 7 (+) to 1 (beat) [OWN]. |
| 17 | (empty) | 0 | Drop. |
| 18 | 3, 7, 11, 15 | 4 | B part, exactly as the source gives it: 3, 7, 11, 15 [BOOK]. |
| 19 | 1, 3, 7, 9, 11, 15 | 6 | Climb: half the remaining way to the peak (adds 1 (beat), 9 (beat)). |
| 20 | 1, 3, 5, 7, 9, 11, 13, 15 | 8 | Peak (adds 5 (beat), 13 (beat)). |
| 21 | 3, 7, 11 | 3 | Variation on slot 1 (the track's first hit, 3 (+)): plus 7 (+), 11 (+) [BOOK]. Silent tracks have nothing to vary, so 21-24 stay light. |
| 22 | 1, 3, 11 | 3 | Variation on slot 1 (the track's first hit, 3 (+)): plus 1 (beat), 11 (+) [BOOK/OWN]. |
| 23 | 3, 9, 11 | 3 | Variation on slot 1 (the track's first hit, 3 (+)): plus 9 (beat), 11 (+) [BOOK/OWN]. |
| 24 | 3, 5, 11 | 3 | Variation on slot 1 (the track's first hit, 3 (+)): plus 5 (beat), 11 (+) [BOOK/OWN]. |

## Perc 1 (shaker)

All OWN. Slot 1 is the first vocabulary hit (2, a shaker on the e). Then the second (10). After that the climb follows the timing order for a straight bank: beats, then the +, then the a, then the e, with count-keeping moves. Silent at 17. 18 and 19 are big jumps (7 to 10 to 13), 20 is every 16th. 21 to 24 are slot 1 plus one hit each: light, because the track's "classic" is silence.

| Slot | Steps | Hits | What changed, and the rule |
|---|---|---|---|
| 1 | 2 | 1 | Start: the record has no part here, so slot 1 is one OWN hit. |
| 2 | 2, 10 | 2 | Middle: add 10 (e) [OWN]. |
| 3 | 1, 2 | 2 | Middle, keep the count: move a hit from 10 (e) to 1 (beat) [OWN]. |
| 4 | 2, 9 | 2 | Middle, keep the count: move a hit from 1 (beat) to 9 (beat) [OWN]. |
| 5 | 2, 5, 9 | 3 | Middle: add 5 (beat) [OWN]. |
| 6 | 2, 9, 13 | 3 | Middle, keep the count: move a hit from 5 (beat) to 13 (beat) [OWN]. |
| 7 | 2, 3, 9 | 3 | Middle, keep the count: move a hit from 13 (beat) to 3 (+) [OWN]. |
| 8 | 2, 3, 7, 9 | 4 | Middle: add 7 (+) [OWN]. |
| 9 | 2, 3, 9, 11 | 4 | Middle, keep the count: move a hit from 7 (+) to 11 (+) [OWN]. |
| 10 | 2, 3, 9, 11, 15 | 5 | Middle: add 15 (+) [OWN]. |
| 11 | 2, 3, 4, 9, 11 | 5 | Middle, keep the count: move a hit from 15 (+) to 4 (a) [OWN]. |
| 12 | 2, 3, 8, 9, 11 | 5 | Middle, keep the count: move a hit from 4 (a) to 8 (a) [OWN]. |
| 13 | 2, 3, 8, 9, 11, 12 | 6 | Middle: add 12 (a) [OWN]. |
| 14 | 2, 3, 8, 9, 11, 16 | 6 | Middle, keep the count: move a hit from 12 (a) to 16 (a) [OWN]. |
| 15 | 2, 3, 6, 8, 9, 11, 16 | 7 | Middle: add 6 (e) [OWN]. |
| 16 | 2, 3, 8, 9, 10, 11, 16 | 7 | Middle, keep the count: move a hit from 6 (e) to 10 (e) [OWN]. |
| 17 | (empty) | 0 | Drop. |
| 18 | 1, 2, 3, 5, 8, 9, 10, 11, 13, 16 | 10 | Climb, no B part for this track: slot 16 plus about a third of the way to the peak (adds 1 (beat), 5 (beat), 13 (beat)). |
| 19 | 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 13, 15, 16 | 13 | Climb: half the remaining way to the peak (adds 4 (a), 7 (+), 15 (+)). |
| 20 | 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 | 16 | Peak (adds 6 (e), 12 (a), 14 (e)). |
| 21 | 2, 5 | 2 | Variation on slot 1 (the track's first hit, 2 (e)): plus 5 (beat) [OWN]. Silent tracks have nothing to vary, so 21-24 stay light. |
| 22 | 2, 13 | 2 | Variation on slot 1 (the track's first hit, 2 (e)): plus 13 (beat) [OWN]. |
| 23 | 2, 3 | 2 | Variation on slot 1 (the track's first hit, 2 (e)): plus 3 (+) [OWN]. |
| 24 | 2, 7 | 2 | Variation on slot 1 (the track's first hit, 2 (e)): plus 7 (+) [OWN]. |

## Perc 2 (clap)

Same method as Perc 1, starting from its vocabulary (5, then 13: the clap doubling the backbeat).

| Slot | Steps | Hits | What changed, and the rule |
|---|---|---|---|
| 1 | 5 | 1 | Start: the record has no part here, so slot 1 is one OWN hit. |
| 2 | 5, 13 | 2 | Middle: add 13 (beat) [OWN]. |
| 3 | 1, 5 | 2 | Middle, keep the count: move a hit from 13 (beat) to 1 (beat) [OWN]. |
| 4 | 5, 9 | 2 | Middle, keep the count: move a hit from 1 (beat) to 9 (beat) [OWN]. |
| 5 | 5, 9, 13 | 3 | Middle: add 13 (beat) [OWN]. |
| 6 | 3, 5, 9 | 3 | Middle, keep the count: move a hit from 13 (beat) to 3 (+) [OWN]. |
| 7 | 5, 7, 9 | 3 | Middle, keep the count: move a hit from 3 (+) to 7 (+) [OWN]. |
| 8 | 5, 7, 9, 11 | 4 | Middle: add 11 (+) [OWN]. |
| 9 | 5, 7, 9, 15 | 4 | Middle, keep the count: move a hit from 11 (+) to 15 (+) [OWN]. |
| 10 | 4, 5, 7, 9, 15 | 5 | Middle: add 4 (a) [OWN]. |
| 11 | 5, 7, 8, 9, 15 | 5 | Middle, keep the count: move a hit from 4 (a) to 8 (a) [OWN]. |
| 12 | 5, 7, 9, 12, 15 | 5 | Middle, keep the count: move a hit from 8 (a) to 12 (a) [OWN]. |
| 13 | 5, 7, 9, 12, 15, 16 | 6 | Middle: add 16 (a) [OWN]. |
| 14 | 2, 5, 7, 9, 12, 15 | 6 | Middle, keep the count: move a hit from 16 (a) to 2 (e) [OWN]. |
| 15 | 2, 5, 6, 7, 9, 12, 15 | 7 | Middle: add 6 (e) [OWN]. |
| 16 | 2, 5, 7, 9, 10, 12, 15 | 7 | Middle, keep the count: move a hit from 6 (e) to 10 (e) [OWN]. |
| 17 | (empty) | 0 | Drop. |
| 18 | 1, 2, 3, 5, 7, 9, 10, 12, 13, 15 | 10 | Climb, no B part for this track: slot 16 plus about a third of the way to the peak (adds 1 (beat), 3 (+), 13 (beat)). |
| 19 | 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 13, 15 | 13 | Climb: half the remaining way to the peak (adds 4 (a), 8 (a), 11 (+)). |
| 20 | 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 | 16 | Peak (adds 6 (e), 14 (e), 16 (a)). |
| 21 | 3, 5 | 2 | Variation on slot 1 (the track's first hit, 5 (beat)): plus 3 (+) [OWN]. Silent tracks have nothing to vary, so 21-24 stay light. |
| 22 | 5, 7 | 2 | Variation on slot 1 (the track's first hit, 5 (beat)): plus 7 (+) [OWN]. |
| 23 | 5, 11 | 2 | Variation on slot 1 (the track's first hit, 5 (beat)): plus 11 (+) [OWN]. |
| 24 | 5, 15 | 2 | Variation on slot 1 (the track's first hit, 5 (beat)): plus 15 (+) [OWN]. |

## The whole bank

| Slot | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Hits | 8 | 16 | 23 | 30 | 38 | 44 | 52 | 60 | 64 | 68 | 70 | 70 | 75 | 79 | 82 | 83 | 14 | 74 | 97 | 120 | 58 | 60 | 60 | 60 |

That's the shape: thin at 1, the classic in place by 8, a slow climb to 83, the drop to 14, a lift through 74 and 97 to 120 at the peak, then variations around the classic (the classic slots together are 47 hits).

**OWN share:** 32% of all hits across the 24 slots are the builder's own. Every one of them is labelled above.

## What to take from this

1. Write the source down first, per track, with its labels.
2. Work out the peaks.
3. The build-up is only the record's hits, in the beat / + / a / e order.
4. The middle uses the source's vocabulary before inventing anything, and invents in timing order.
5. Hold the B part back for 18.
6. Keep all 24 slots different; when the count shouldn't rise, move a hit.
7. Label everything you invent.

To build a bank like this with code, see `tools/README.md`: `tools/lf_banks.py` holds Blue Monday as data (search for `name="Blue Monday"`), and `tools/lf_build.py` turns it into exactly the patterns above.
